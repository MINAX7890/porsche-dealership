<?php
/**
 * Database Connection Handler
 * 
 * Provides functions for database connectivity and operations.
 */

require_once 'config.php';

/**
 * Establishes database connection using mysqli
 * @return mysqli|false Returns a mysqli connection object or false on failure
 */
function connectDB() {
    global $DB_CONFIG;
    
    // Create connection
    $conn = new mysqli(
        $DB_CONFIG['host'], 
        $DB_CONFIG['username'], 
        $DB_CONFIG['password'], 
        $DB_CONFIG['dbname']
    );
    
    // Check connection
    if ($conn->connect_error) {
        error_log("Database connection failed: " . $conn->connect_error);
        return false;
    }
    
    // Set charset to ensure proper encoding
    $conn->set_charset("utf8mb4");
    
    return $conn;
}

/**
 * Establishes database connection using PDO
 * @return PDO|false Returns a PDO connection object or false on failure
 */
function connectPDO() {
    global $DB_CONFIG;
    
    try {
        $dsn = "mysql:host={$DB_CONFIG['host']};dbname={$DB_CONFIG['dbname']};charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        
        return new PDO($dsn, $DB_CONFIG['username'], $DB_CONFIG['password'], $options);
    } catch (PDOException $e) {
        error_log("PDO Connection failed: " . $e->getMessage());
        return false;
    }
}

/**
 * Creates the database if it doesn't exist
 * @return bool Returns true if successful, false otherwise
 */
function createDatabase() {
    global $DB_CONFIG;
    
    try {
        // Connect without database selected
        $conn = new mysqli($DB_CONFIG['host'], $DB_CONFIG['username'], $DB_CONFIG['password']);
        
        if ($conn->connect_error) {
            error_log("Database connection failed: " . $conn->connect_error);
            return false;
        }
        
        // Create database
        $sql = "CREATE DATABASE IF NOT EXISTS " . $DB_CONFIG['dbname'];
        $result = $conn->query($sql);
        
        $conn->close();
        
        return $result === TRUE;
    } catch (Exception $e) {
        error_log("Error creating database: " . $e->getMessage());
        return false;
    }
}

/**
 * Execute a query with prepared statements (mysqli)
 * @param string $sql The SQL query with placeholders
 * @param string $types The types of parameters (i: integer, s: string, d: double, b: blob)
 * @param array $params The parameters to bind
 * @return array|bool Query result as array or boolean for success/failure
 */
function executeQuery($sql, $types = "", $params = []) {
    $conn = connectDB();
    
    if (!$conn) {
        return false;
    }
    
    try {
        $stmt = $conn->prepare($sql);
        
        if (!$stmt) {
            error_log("Query preparation failed: " . $conn->error);
            $conn->close();
            return false;
        }
        
        // Bind parameters if any
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        // Execute the query
        if (!$stmt->execute()) {
            error_log("Query execution failed: " . $stmt->error);
            $stmt->close();
            $conn->close();
            return false;
        }
        
        // For SELECT queries
        if (stripos(trim($sql), 'SELECT') === 0) {
            $result = $stmt->get_result();
            $data = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            $conn->close();
            return $data;
        }
        
        // For INSERT, UPDATE, DELETE queries
        $affected_rows = $stmt->affected_rows;
        $insert_id = $conn->insert_id;
        
        $stmt->close();
        $conn->close();
        
        return [
            'success' => true,
            'affected_rows' => $affected_rows,
            'insert_id' => $insert_id
        ];
    } catch (Exception $e) {
        error_log("Query error: " . $e->getMessage());
        if (isset($stmt)) {
            $stmt->close();
        }
        $conn->close();
        return false;
    }
}
?>