<?php
session_start();
require_once 'guest_validation.php';

// Check if user is authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection parameters
$servername = "localhost";
$username = "root";      // Use your actual MySQL username instead of "Guest"
$password = "";          // Use your actual MySQL password 
$dbname = "test1";

/**
 * Establishes database connection
 * @return mysqli|false Returns a mysqli connection object or false on failure
 */
function connectDB() {
    global $servername, $username, $password, $dbname;
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        return false;
    }
    
    return $conn;
}

// Rest of the file remains the same...
// Initialize variables
$user_id = $_SESSION['user_id'];
$owned_cars = [];
$rental_bookings = [];
$sale_listings = [];
$conn_error = '';

// Connect to database
$conn = connectDB();
if (!$conn) {
    $conn_error = 'Database connection failed. Please try again later.';
} else {
    // Create necessary tables if they don't exist
    ensureTablesExist($conn);
    
    // Get user's purchased cars
    try {
        $stmt = $conn->prepare("SELECT * FROM cars WHERE owner_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $row['price_formatted'] = '$' . number_format($row['price'], 2);
                $owned_cars[] = $row;
            }
        }
        $stmt->close();
    } catch (Exception $e) {
        // Table might not exist yet or have the right columns
    }
    
    // Get user's rental bookings
    try {
        $stmt = $conn->prepare("
            SELECT rb.*, rc.model, rc.year, rc.image_url 
            FROM rental_bookings rb
            LEFT JOIN rental_cars rc ON rb.car_id = rc.id
            WHERE rb.user_id = ?
            ORDER BY rb.pickup_date DESC
        ");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $rental_bookings[] = $row;
            }
        }
        $stmt->close();
    } catch (Exception $e) {
        // Table might not exist yet
    }
    
    // Get user's sale listings
    try {
        $stmt = $conn->prepare("SELECT * FROM vehicles WHERE user_id = ? ORDER BY submission_date DESC");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $row['asking_price_formatted'] = '$' . number_format($row['asking_price'], 2);
                $sale_listings[] = $row;
            }
        }
        $stmt->close();
    } catch (Exception $e) {
        // Table might not exist yet
    }
    
    $conn->close();
}

/**
 * Ensure all necessary tables exist
 * @param mysqli $conn Database connection
 */
function ensureTablesExist($conn) {
    // Add owner_id column to cars table if it doesn't exist
    $result = $conn->query("SHOW COLUMNS FROM cars LIKE 'owner_id'");
    if ($result && $result->num_rows == 0) {
        $conn->query("ALTER TABLE cars ADD COLUMN owner_id INT(11) NULL");
    }
    
    // Ensure rental_bookings table has user_id column
    try {
        $conn->query("
            CREATE TABLE IF NOT EXISTS rental_bookings (
                id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                car_id INT(11) NOT NULL,
                user_id INT(11) NULL,
                renter_name VARCHAR(100) NOT NULL,
                renter_email VARCHAR(100) NOT NULL,
                renter_phone VARCHAR(20) NOT NULL,
                pickup_date DATE NOT NULL,
                return_date DATE NOT NULL,
                special_requests TEXT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX (car_id),
                INDEX (user_id)
            )
        ");
        
        // Add user_id column if it doesn't exist
        $result = $conn->query("SHOW COLUMNS FROM rental_bookings LIKE 'user_id'");
        if ($result && $result->num_rows == 0) {
            $conn->query("ALTER TABLE rental_bookings ADD COLUMN user_id INT(11) NULL");
        }
    } catch (Exception $e) {
        // Table might already exist
    }
    
    // Ensure vehicles table exists
    try {
        $conn->query("
            CREATE TABLE IF NOT EXISTS vehicles (
                id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT(6) NULL,
                seller_name VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                phone VARCHAR(20) NOT NULL,
                car_model VARCHAR(100) NOT NULL,
                car_year INT(4) NOT NULL,
                car_color VARCHAR(50) NOT NULL,
                car_mileage INT(10) NOT NULL,
                car_condition VARCHAR(50) NOT NULL,
                asking_price DECIMAL(10,2) NOT NULL,
                additional_info TEXT,
                submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX (user_id)
            )
        ");
    } catch (Exception $e) {
        // Table might already exist
    }
}

// Include header
include 'header.php';
?>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-10 mx-auto">
            <h1 class="mb-4">My Cars</h1>
            
            <?php if ($conn_error): ?>
            <div class="alert alert-danger">
                <?php echo $conn_error; ?>
            </div>
            <?php endif; ?>
            
            <ul class="nav nav-tabs mb-4" id="carsTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="owned-tab" data-bs-toggle="tab" data-bs-target="#owned" type="button" role="tab" aria-controls="owned" aria-selected="true">My Owned Cars</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="rentals-tab" data-bs-toggle="tab" data-bs-target="#rentals" type="button" role="tab" aria-controls="rentals" aria-selected="false">My Rentals</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="listings-tab" data-bs-toggle="tab" data-bs-target="#listings" type="button" role="tab" aria-controls="listings" aria-selected="false">My Sale Listings</button>
                </li>
            </ul>
            
            <div class="tab-content" id="carsTabsContent">
                <!-- Owned Cars Tab -->
                <div class="tab-pane fade show active" id="owned" role="tabpanel" aria-labelledby="owned-tab">
                    <?php if (empty($owned_cars)): ?>
                        <div class="alert alert-info">
                            You don't have any cars in your collection yet. 
                            <a href="buy.php" class="alert-link">Browse our inventory</a> to find your perfect car.
                        </div>
                    <?php else: ?>
                        <div class="row row-cols-1 row-cols-md-2 g-4">
                            <?php foreach ($owned_cars as $car): ?>
                                <div class="col">
                                    <div class="card h-100">
                                        <?php if (!empty($car['image_url'])): ?>
                                            <img src="<?php echo htmlspecialchars($car['image_url']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($car['model']); ?>">
                                        <?php else: ?>
                                            <div class="ratio ratio-16x9 bg-secondary">
                                                <div class="d-flex align-items-center justify-content-center text-white">
                                                    <span>No Image Available</span>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo htmlspecialchars($car['year'] . ' ' . $car['model']); ?></h5>
                                            <p class="card-text">
                                                <strong>Color:</strong> <?php echo htmlspecialchars($car['color']); ?><br>
                                                <strong>Price:</strong> <?php echo htmlspecialchars($car['price_formatted']); ?><br>
                                                <?php if (isset($car['mileage'])): ?>
                                                    <strong>Mileage:</strong> <?php echo number_format($car['mileage']); ?> miles<br>
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                        <div class="card-footer">
                                            <a href="car_details.php?id=<?php echo $car['id']; ?>" class="btn btn-outline-primary">View Details</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mt-4">
                        <a href="buy.php" class="btn btn-primary">Browse Cars to Buy</a>
                    </div>
                </div>
                
                <!-- Rental Bookings Tab -->
                <div class="tab-pane fade" id="rentals" role="tabpanel" aria-labelledby="rentals-tab">
                    <?php if (empty($rental_bookings)): ?>
                        <div class="alert alert-info">
                            You don't have any rental bookings yet. 
                            <a href="rent.php" class="alert-link">Browse our rental inventory</a> to find a car to rent.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Car</th>
                                        <th>Pickup Date</th>
                                        <th>Return Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($rental_bookings as $booking): ?>
                                        <tr>
                                            <td>
                                                <?php if (isset($booking['model']) && isset($booking['year'])): ?>
                                                    <?php echo htmlspecialchars($booking['year'] . ' ' . $booking['model']); ?>
                                                <?php else: ?>
                                                    <em>Car details not available</em>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo htmlspecialchars(date('M d, Y', strtotime($booking['pickup_date']))); ?></td>
                                            <td><?php echo htmlspecialchars(date('M d, Y', strtotime($booking['return_date']))); ?></td>
                                            <td>
                                                <?php
                                                $status_class = 'secondary';
                                                if ($booking['status'] == 'confirmed') {
                                                    $status_class = 'success';
                                                } elseif ($booking['status'] == 'cancelled') {
                                                    $status_class = 'danger';
                                                } elseif ($booking['status'] == 'pending') {
                                                    $status_class = 'warning';
                                                }
                                                ?>
                                                <span class="badge bg-<?php echo $status_class; ?>">
                                                    <?php echo ucfirst(htmlspecialchars($booking['status'])); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($booking['status'] == 'pending'): ?>
                                                    <form method="post" action="cancel_booking.php" style="display: inline-block;">
                                                        <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                                        <button type="submit" class="btn btn-sm btn-outline-danger">Cancel</button>
                                                    </form>
                                                <?php endif; ?>
                                                
                                                <?php if (isset($booking['car_id'])): ?>
                                                    <a href="rent.php?id=<?php echo $booking['car_id']; ?>" class="btn btn-sm btn-outline-primary">View Car</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mt-4">
                        <a href="rent.php" class="btn btn-primary">Browse Cars to Rent</a>
                    </div>
                </div>
                
                <!-- Sale Listings Tab -->
                <div class="tab-pane fade" id="listings" role="tabpanel" aria-labelledby="listings-tab">
                    <?php if (empty($sale_listings)): ?>
                        <div class="alert alert-info">
                            You haven't listed any cars for sale yet. 
                            <a href="sell.php" class="alert-link">List your car for sale</a> today!
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Car Details</th>
                                        <th>Asking Price</th>
                                        <th>Listed On</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($sale_listings as $listing): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars($listing['car_year'] . ' ' . $listing['car_model']); ?></strong><br>
                                                Color: <?php echo htmlspecialchars($listing['car_color']); ?><br>
                                                Mileage: <?php echo number_format($listing['car_mileage']); ?> miles
                                            </td>
                                            <td><?php echo htmlspecialchars($listing['asking_price_formatted']); ?></td>
                                            <td><?php echo htmlspecialchars(date('M d, Y', strtotime($listing['submission_date']))); ?></td>
                                            <td>
                                                <span class="badge bg-info">Listed</span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mt-4">
                        <a href="sell.php" class="btn btn-primary">List a Car for Sale</a>
                    </div>
                </div>
            </div>
            
            <div class="mt-4">
                <a href="my_profile.php" class="btn btn-secondary">Back to My Profile</a>
                <a href="index.php" class="btn btn-outline-secondary ms-2">Back to Home</a>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include 'footer.php';
?>