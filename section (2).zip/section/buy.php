<?php
session_start();
// Include database connection functions
// First, check if the cars table exists and create it if it doesn't
createCarsTableIfNotExists();

// Check if user is authenticated or a guest
$is_logged_in = isset($_SESSION['user_id']);
$is_guest = isset($_SESSION['guest']) && $_SESSION['guest'] === true;

// Check for guest parameter in URL and set guest session if needed
if (isset($_GET['guest']) && $_GET['guest'] === 'true') {
    $_SESSION['guest'] = true;
    $is_guest = true;
}

if (!$is_logged_in && !$is_guest) {
    header("Location: index.php");
    exit();
}

/**
 * Establishes database connection
 * @return mysqli|false Returns a mysqli connection object or false on failure
 */
function connectDB() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "test1";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        return false;
    }
    
    return $conn;
}

/**
 * Creates the cars table if it doesn't exist
 */
function createCarsTableIfNotExists() {
    $conn = connectDB();
    if (!$conn) {
        die("Database connection failed.");
    }
    
    // SQL to create the cars table
    $sql = "CREATE TABLE IF NOT EXISTS cars (
        id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        model VARCHAR(100) NOT NULL,
        year INT(4) NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        engine VARCHAR(100) NOT NULL,
        transmission VARCHAR(50) NOT NULL,
        mileage INT(11) NOT NULL DEFAULT 0,
        color VARCHAR(50) NOT NULL,
        image_url VARCHAR(255) DEFAULT NULL,
        description TEXT,
        short_description VARCHAR(255),
        features TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if (!$conn->query($sql)) {
        die("Error creating cars table: " . $conn->error);
    }
    
    // Check if the table is empty, and if so, add some sample data
    $result = $conn->query("SELECT COUNT(*) as count FROM cars");
    $row = $result->fetch_assoc();
    
    if ($row['count'] == 0) {
        // Insert sample car data
        $sample_cars = [
            [
                'model' => 'Porsche 911 Carrera S',
                'year' => 2023,
                'price' => 112000.00,
                'engine' => '3.0L Twin-Turbo Flat-Six',
                'transmission' => '8-Speed PDK',
                'mileage' => 1500,
                'color' => 'GT Silver Metallic',
                'image_url' => 'images/cars/porsche-911.jpg',
                'description' => 'The iconic Porsche 911 Carrera S represents the pinnacle of sports car engineering. This model features the latest Porsche technology including Porsche Dynamic Chassis Control, rear-axle steering, and Sport Chrono Package as standard. The refined interior offers a perfect blend of luxury and sportiness with full leather trim and the latest PCM infotainment system with Apple CarPlay and Android Auto integration.',
                'short_description' => 'Iconic sports car with unmatched handling and precision engineering',
                'features' => json_encode(['Sport Chrono Package', 'Premium Leather Interior', 'Bose Surround Sound System', 'LED Matrix Headlights', 'Adaptive Sport Seats Plus', '20/21-inch Carrera Classic Wheels'])
            ],
            // Adding 5 new car entries below
            [
                'model' => 'Porsche Taycan Turbo S',
                'year' => 2024,
                'price' => 187500.00,
                'engine' => 'Dual Electric Motors (750 hp)',
                'transmission' => '2-Speed Automatic',
                'mileage' => 250,
                'color' => 'Frozen Blue Metallic',
                'image_url' => 'images/cars/porsche-taycan.jpg',
                'description' => 'The Porsche Taycan Turbo S represents the future of electric performance. With its innovative 800-volt architecture and dual electric motors producing up to 750 horsepower with overboost, the Taycan Turbo S accelerates from 0 to 60 mph in just 2.6 seconds. The interior features the curved digital display and Porsche Advanced Cockpit with touchscreen control for climate and infotainment. Performance Battery Plus provides exceptional range and charging capabilities.',
                'short_description' => 'The ultimate electric sports car with breathtaking acceleration and Porsche DNA',
                'features' => json_encode(['Porsche Electric Sport Sound', 'Passenger Display', 'Performance Battery Plus', 'Porsche Dynamic Chassis Control', 'Adaptive Air Suspension', 'Night Vision Assist', 'Head-up Display'])
            ],
            [
                'model' => 'Porsche Macan GTS',
                'year' => 2023,
                'price' => 79900.00,
                'engine' => '2.9L Twin-Turbo V6',
                'transmission' => '7-Speed PDK',
                'mileage' => 3200,
                'color' => 'Carmine Red',
                'image_url' => 'images/cars/porsche-macan.jpg',
                'description' => 'The Porsche Macan GTS combines the versatility of an SUV with the soul of a sports car. With its twin-turbocharged V6 engine producing 375 horsepower, sport-tuned adaptive air suspension, and sport exhaust system, the Macan GTS delivers an exhilarating driving experience. The interior features GTS-specific Alcantara trim, sport seats with additional bolstering, and the latest Porsche Communication Management system with 10.9-inch touchscreen.',
                'short_description' => 'The sports car among compact SUVs with thrilling performance',
                'features' => json_encode(['Sport Chrono Package', 'GTS Sport Package', 'BOSE® Surround Sound System', '21-inch RS Spyder Design Wheels', 'Adaptive Air Suspension', 'LED Headlights with PDLS Plus'])
            ],
            [
                'model' => 'Porsche 718 Cayman GT4 RS',
                'year' => 2023,
                'price' => 149200.00,
                'engine' => '4.0L Naturally Aspirated Flat-Six',
                'transmission' => '7-Speed PDK',
                'mileage' => 800,
                'color' => 'Shark Blue',
                'image_url' => 'images/cars/porsche-cayman.jpg',
                'description' => 'The Porsche 718 Cayman GT4 RS represents the pinnacle of mid-engine sports car engineering. Featuring the 4.0-liter naturally aspirated flat-six engine from the 911 GT3, producing 493 horsepower with a 9,000 rpm redline, the GT4 RS delivers incredible performance with a 0-60 time of just 3.2 seconds. Extensive weight reduction measures, including carbon fiber hood and fenders, along with aerodynamic improvements, make this the most track-focused Cayman ever produced.',
                'short_description' => 'Track-focused mid-engine masterpiece with motorsport DNA',
                'features' => json_encode(['Fixed Carbon Fiber Rear Wing', 'Full Bucket Seats', 'Clubsport Package', 'Michelin Pilot Sport Cup 2 R Tires', 'Weissach Package', 'Carbon Ceramic Brakes'])
            ],
            [
                'model' => 'Porsche Panamera Turbo S E-Hybrid',
                'year' => 2024,
                'price' => 192700.00,
                'engine' => '4.0L Twin-Turbo V8 + Electric Motor',
                'transmission' => '8-Speed PDK',
                'mileage' => 450,
                'color' => 'Truffle Brown Metallic',
                'image_url' => 'images/cars/porsche-panamera.jpg',
                'description' => 'The Porsche Panamera Turbo S E-Hybrid represents the pinnacle of luxury performance sedans, combining a twin-turbocharged V8 engine with an electric motor for a total system output of 690 horsepower. This plug-in hybrid offers exceptional performance with a 0-60 time of 3.0 seconds, while also providing an all-electric range of up to 30 miles. The luxurious interior features four individual sport seats, a high-resolution 12.3-inch touchscreen, and a premium Burmester® 3D High-End Surround Sound system.',
                'short_description' => 'The ultimate luxury performance sedan with hybrid technology',
                'features' => json_encode(['Porsche Dynamic Chassis Control Sport', 'Rear-Axle Steering', 'Ceramic Composite Brakes', 'Four-Zone Climate Control', 'Massage Seats', 'Night Vision Assist', 'Head-Up Display'])
            ],
            [
                'model' => 'Porsche Cayenne Turbo GT',
                'year' => 2023,
                'price' => 188700.00,
                'engine' => '4.0L Twin-Turbo V8',
                'transmission' => '8-Speed Tiptronic S',
                'mileage' => 1800,
                'color' => 'Arctic Grey',
                'image_url' => 'images/cars/porsche-cayenne.jpg',
                'description' => 'The Porsche Cayenne Turbo GT is the most powerful and track-capable Cayenne ever produced. With its specially tuned 4.0-liter twin-turbo V8 producing 631 horsepower, the Cayenne Turbo GT accelerates from 0-60 mph in just 3.1 seconds and set a new SUV lap record at the Nürburgring. The model-specific suspension is lowered by 17mm, with retuned Porsche Active Suspension Management and Porsche Dynamic Chassis Control systems. Carbon ceramic brakes, rear-axle steering, and a titanium sports exhaust system complete the performance package.',
                'short_description' => 'The ultimate performance SUV with supercar capabilities',
                'features' => json_encode(['Lightweight Carbon Fiber Roof', 'Carbon Fiber Diffuser', 'Alcantara Interior Trim', '22-inch GT Design Wheels', 'Sport Chronograph', 'Carbon Interior Package', 'Adaptive Sports Seats'])
            ],
            // ... other sample cars data remain the same
        ];
        
        foreach ($sample_cars as $car) {
            $sql = "INSERT INTO cars (model, year, price, engine, transmission, mileage, color, image_url, description, short_description, features) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            
            if ($stmt) {
                $stmt->bind_param(
                    "sidssisssss", 
                    $car['model'], 
                    $car['year'], 
                    $car['price'], 
                    $car['engine'], 
                    $car['transmission'], 
                    $car['mileage'], 
                    $car['color'], 
                    $car['image_url'], 
                    $car['description'], 
                    $car['short_description'], 
                    $car['features']
                );
                $stmt->execute();
                $stmt->close();
            }
        }
    }
    
    $conn->close();
}

/**
 * Get all cars for sale from database
 * @return array Array of car data
 */
function getCarsForSale() {
    $conn = connectDB();
    if (!$conn) {
        return array();
    }
    
    $cars = array();
    $sql = "SELECT * FROM cars";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Format price for display
            $row['price_formatted'] = '$' . number_format($row['price'], 2);
            
            // Convert features from JSON string to array
            if (isset($row['features'])) {
                $row['features'] = json_decode($row['features'], true);
            } else {
                $row['features'] = array();
            }
            
            $cars[] = $row;
        }
    }
    
    $conn->close();
    return $cars;
}

/**
 * Get a specific car by ID
 * @param int $car_id The car ID to retrieve
 * @return array|null Car data or null if not found
 */
function getCarById($car_id) {
    $conn = connectDB();
    if (!$conn) {
        return null;
    }
    
    $stmt = $conn->prepare("SELECT * FROM cars WHERE id = ?");
    $stmt->bind_param("i", $car_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $car = $result->fetch_assoc();
        
        // Format price for display
        $car['price_formatted'] = '$' . number_format($car['price'], 2);
        
        // Convert features from JSON string to array
        if (isset($car['features'])) {
            $car['features'] = json_decode($car['features'], true);
        } else {
            $car['features'] = array();
        }
        
        $stmt->close();
        $conn->close();
        return $car;
    }
    
    $stmt->close();
    $conn->close();
    return null;
}

/**
 * Get filtered cars based on parameters
 */
function getFilteredCars($model_filter, $price_min, $price_max, $year_min, $year_max) {
    $conn = connectDB();
    if (!$conn) {
        return array();
    }
    
    $sql = "SELECT * FROM cars WHERE 1=1";
    $params = array();
    $types = "";
    
    // Add model filter if provided
    if (!empty($model_filter)) {
        $sql .= " AND model LIKE ?";
        $model_param = "%" . $model_filter . "%";
        $params[] = &$model_param;
        $types .= "s";
    }
    
    // Add price range filter
    $sql .= " AND price >= ? AND price <= ?";
    $params[] = &$price_min;
    $params[] = &$price_max;
    $types .= "dd"; // double for price values
    
    // Add year range filter
    $sql .= " AND year >= ? AND year <= ?";
    $params[] = &$year_min;
    $params[] = &$year_max;
    $types .= "ii"; // integer for year values
    
    $stmt = $conn->prepare($sql);
    
    if (!empty($params)) {
        // Only bind parameters if there are parameters to bind
        call_user_func_array(array($stmt, 'bind_param'), array_merge(array($types), $params));
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $cars = array();
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Format price for display
            $row['price_formatted'] = '$' . number_format($row['price'], 2);
            
            // Convert features from JSON string to array
            if (isset($row['features'])) {
                $row['features'] = json_decode($row['features'], true);
            } else {
                $row['features'] = array();
            }
            
            $cars[] = $row;
        }
    }
    
    $stmt->close();
    $conn->close();
    return $cars;
}

/**
 * Get unique car models from database
 * @return array Array of unique car models
 */
function getUniqueModels() {
    $conn = connectDB();
    if (!$conn) {
        return array();
    }
    
    $models = array();
    $sql = "SELECT DISTINCT model FROM cars ORDER BY model";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $models[] = $row['model'];
        }
    }
    
    $conn->close();
    return $models;
}

// Get filter parameters
$model_filter = isset($_GET['model']) ? $_GET['model'] : '';
$price_min = isset($_GET['price_min']) ? (int)$_GET['price_min'] : 0;
$price_max = isset($_GET['price_max']) ? (int)$_GET['price_max'] : 1000000;
$year_min = isset($_GET['year_min']) ? (int)$_GET['year_min'] : 0;
$year_max = isset($_GET['year_max']) ? (int)$_GET['year_max'] : 3000;

// Check if viewing a specific car
$viewing_car = null;
if (isset($_GET['id'])) {
    $viewing_car = getCarById($_GET['id']);
}

// Get filtered cars
$filtered_cars = getFilteredCars($model_filter, $price_min, $price_max, $year_min, $year_max);

// Get unique models for filter dropdown
$models = getUniqueModels();

?>
<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Porsche Dealership - Buy Your Dream Car</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <style>
        /* Global luxury styling */
        body {
            font-family: 'Roboto', 'Helvetica Neue', sans-serif;
            color: #212121;
            background-color: #f8f8f8;
        }
        
        .btn-porsche {
            background-color: #d5001c;
            border-color: #d5001c;
            color: white;
            border-radius: 0;
            padding: 12px 24px;
            text-transform: uppercase;
            font-weight: 500;
            letter-spacing: 1px;
            transition: all 0.3s;
        }
        
        .btn-porsche:hover {
            background-color: #940014;
            border-color: #940014;
            color: white;
        }
        
        .btn-porsche-outline {
            background-color: transparent;
            border: 1px solid #d5001c;
            color: #d5001c;
            border-radius: 0;
            padding: 12px 24px;
            text-transform: uppercase;
            font-weight: 500;
            letter-spacing: 1px;
            transition: all 0.3s;
        }
        
        .btn-porsche-outline:hover {
            background-color: #d5001c;
            color: white;
        }
        
        /* Header styling */
        .section-header {
            position: relative;
            padding-bottom: 20px;
            margin-bottom: 40px;
        }
        
        .section-header:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 3px;
            background-color: #d5001c;
        }
        
        /* Car cards styling */
        .car-card {
            border: none;
            border-radius: 0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            overflow: hidden;
        }
        
        .car-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        
        .car-img-top {
            height: 240px;
            background-size: cover;
            background-position: center;
            position: relative;
            overflow: hidden;
        }
        
        .car-img-top:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(to bottom, rgba(0,0,0,0) 70%, rgba(0,0,0,0.7) 100%);
        }
        
        .car-card .card-body {
            padding: 24px;
        }
        
        .car-card .card-footer {
            border-top: none;
            padding: 0 24px 24px;
        }
        
        /* Single car view styling */
        .car-img-large {
            height: 450px;
            background-size: cover;
            background-position: center;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .sticky-offset {
            top: 100px;
        }
        
        .car-specs .spec-label {
            display: block;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .car-specs .spec-value {
            font-size: 15px;
        }
        
        .feature-item {
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        /* Filter styling */
        .filter-card {
            border: none;
            border-radius: 0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .form-control, .form-select {
            border-radius: 0;
            padding: 10px 16px;
            border: 1px solid #e0e0e0;
        }
        
        /* Luxury badges */
        .luxury-badge {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: rgba(213, 0, 28, 0.9);
            color: white;
            padding: 8px 16px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-size: 12px;
        }
        
        /* Responsive tweaks */
        @media (max-width: 768px) {
            .car-img-large {
                height: 300px;
            }
        }
    </style>
</head>
<body>
    <main>
        <?php if ($viewing_car): ?>
        <!-- Single Car View -->
        <section class="py-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="car-img-large mb-4" style="background-image: url('<?php echo $viewing_car['image_url']; ?>')"></div>
                        <h1 class="fw-bold mb-2"><?php echo $viewing_car['model']; ?></h1>
                        <p class="text-muted"><?php echo $viewing_car['year']; ?> · <?php echo number_format($viewing_car['mileage']); ?> km · <?php echo $viewing_car['color']; ?></p>
                        <h3 class="text-danger fw-bold mb-4"><?php echo $viewing_car['price_formatted']; ?></h3>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="car-specs p-4 bg-light mb-4">
                                    <h4 class="fw-bold mb-3">Technical Specifications</h4>
                                    <div class="row g-3">
                                        <div class="col-6">
                                            <span class="spec-label">Engine</span>
                                            <span class="spec-value"><?php echo $viewing_car['engine']; ?></span>
                                        </div>
                                        <div class="col-6">
                                            <span class="spec-label">Transmission</span>
                                            <span class="spec-value"><?php echo $viewing_car['transmission']; ?></span>
                                        </div>
                                        <div class="col-6">
                                            <span class="spec-label">Mileage</span>
                                            <span class="spec-value"><?php echo number_format($viewing_car['mileage']); ?> km</span>
                                        </div>
                                        <div class="col-6">
                                            <span class="spec-label">Color</span>
                                            <span class="spec-value"><?php echo $viewing_car['color']; ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="p-4 bg-light mb-4">
                                    <h4 class="fw-bold mb-3">Features</h4>
                                    <?php foreach ($viewing_car['features'] as $feature): ?>
                                    <div class="feature-item">
                                        <i class="fas fa-check text-success me-2"></i> <?php echo $feature; ?>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-5">
                            <h4 class="fw-bold mb-3">Vehicle Description</h4>
                            <p><?php echo $viewing_car['description']; ?></p>
                        </div>
                        
                        <div class="d-flex gap-3 mb-5">
                            <a href="contact.php?inquiry=purchase&car_id=<?php echo $viewing_car['id']; ?>" class="btn btn-porsche">Inquire About Purchase</a>
                            <a href="contact.php?inquiry=test_drive&car_id=<?php echo $viewing_car['id']; ?>" class="btn btn-porsche-outline">Schedule Test Drive</a>
                        </div>
                        
                        <a href="buy.php" class="btn btn-link text-muted mb-5">
                            <i class="fas fa-arrow-left me-2"></i> Back to All Vehicles
                        </a>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="position-sticky sticky-offset">
                            <div class="card border-0 shadow-sm mb-4">
                                <div class="card-body p-4">
                                    <h4 class="fw-bold mb-3">Request Information</h4>
                                    <form action="contact.php" method="POST">
                                        <input type="hidden" name="car_id" value="<?php echo $viewing_car['id']; ?>">
                                        <input type="hidden" name="inquiry_type" value="info">
                                        
                                        <div class="mb-3">
                                            <input type="text" class="form-control" name="name" placeholder="Your Name" required>
                                        </div>
                                        <div class="mb-3">
                                            <input type="email" class="form-control" name="email" placeholder="Your Email" required>
                                        </div>
                                        <div class="mb-3">
                                            <input type="tel" class="form-control" name="phone" placeholder="Phone Number" required>
                                        </div>
                                        <div class="mb-3">
                                            <textarea class="form-control" name="message" rows="4" placeholder="I'm interested in the <?php echo $viewing_car['model']; ?> and would like more information." required></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-porsche w-100">Send Request</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php else: ?>
        <!-- Car Listing View -->
        <section class="car-list-section py-5">
            <div class="container">
                <div class="section-header mb-5">
                    <h1 class="fw-bold">Porsche Vehicle Inventory</h1>
                    <p class="lead">Discover the perfect expression of engineering excellence</p>
                </div>
                
                <!-- Results count -->
                <div class="mb-4">
                    <p class="text-muted"><?php echo count($filtered_cars); ?> vehicles available</p>
                </div>
                
                <!-- Car listings -->
                <div class="row g-4">
                    <?php foreach ($filtered_cars as $car): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="car-card card h-100">
                            <div class="car-img-top" style="background-image: url('<?php echo $car['image_url']; ?>')">
                                <div class="luxury-badge">Porsche Approved</div>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title fw-bold mb-1"><?php echo $car['model']; ?></h5>
                                <p class="text-muted"><?php echo $car['year']; ?> · <?php echo number_format($car['mileage']); ?> km</p>
                                <h4 class="fw-bold text-danger mb-3"><?php echo $car['price_formatted']; ?></h4>
                                <p class="card-text"><?php echo $car['short_description']; ?></p>
                            </div>
                            <div class="card-footer bg-white">
                                <div class="row g-2">
                                    <div class="col-6">
                                        <a href="buy.php?id=<?php echo $car['id']; ?>" class="btn btn-porsche w-100">View Details</a>
                                    </div>
                                    <div class="col-6">
                                        <a href="contact.php?inquiry=test_drive&car_id=<?php echo $car['id']; ?>" class="btn btn-porsche-outline w-100">Test Drive</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>
    </main>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php include 'footer.php'; ?>