<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test1";

// Start session for admin authentication
session_start();

// Check if the user is logged in, if not redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to get all tables from the database
function getTables($conn) {
    $tables = array();
    $result = $conn->query("SHOW TABLES");
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_row()) {
            $tables[] = $row[0];
        }
    }
    
    return $tables;
}

// Function to get the structure of a table
function getTableStructure($conn, $table) {
    $structure = array();
    $result = $conn->query("DESCRIBE $table");
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $structure[] = $row;
        }
    }
    
    return $structure;
}

// Function to get data from a table
function getTableData($conn, $table, $limit = 100, $offset = 0) {
    $data = array();
    $result = $conn->query("SELECT * FROM $table LIMIT $limit OFFSET $offset");
    
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    
    return $data;
}

// Function to count records in a table
function countRecords($conn, $table) {
    $result = $conn->query("SELECT COUNT(*) as count FROM $table");
    $row = $result->fetch_assoc();
    return $row['count'];
}

// Handle actions like delete, add, edit
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Delete record
    if (isset($_POST['delete'])) {
        $table = $_POST['table'];
        $id_column = $_POST['id_column'];
        $id = $_POST['id'];
        
        $stmt = $conn->prepare("DELETE FROM $table WHERE $id_column = ?");
        $stmt->bind_param('s', $id);
        
        if ($stmt->execute()) {
            $message = "Record deleted successfully";
        } else {
            $message = "Error deleting record: " . $conn->error;
        }
        $stmt->close();
    }
    
    // Add record
    if (isset($_POST['add'])) {
        $table = $_POST['table'];
        $columns = $_POST['columns'];
        $values = $_POST['values'];
        
        $columns_str = implode(", ", $columns);
        $placeholders = implode(", ", array_fill(0, count($values), "?"));
        
        $stmt = $conn->prepare("INSERT INTO $table ($columns_str) VALUES ($placeholders)");
        
        $types = str_repeat('s', count($values));
        $stmt->bind_param($types, ...$values);
        
        if ($stmt->execute()) {
            $message = "Record added successfully";
        } else {
            $message = "Error adding record: " . $conn->error;
        }
        $stmt->close();
    }
    
    // Edit record
    if (isset($_POST['edit'])) {
        $table = $_POST['table'];
        $id_column = $_POST['id_column'];
        $id = $_POST['id'];
        $columns = $_POST['columns'];
        $values = $_POST['values'];
        
        $set_clause = "";
        for ($i = 0; $i < count($columns); $i++) {
            $set_clause .= $columns[$i] . " = ?, ";
        }
        $set_clause = rtrim($set_clause, ", ");
        
        $stmt = $conn->prepare("UPDATE $table SET $set_clause WHERE $id_column = ?");
        
        $types = str_repeat('s', count($values) + 1);
        $values[] = $id;
        $stmt->bind_param($types, ...$values);
        
        if ($stmt->execute()) {
            $message = "Record updated successfully";
        } else {
            $message = "Error updating record: " . $conn->error;
        }
        $stmt->close();
    }
}

// Get current table to display
$current_table = isset($_GET['table']) ? $_GET['table'] : null;
$tables = getTables($conn);

// Pagination settings
$records_per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $records_per_page;

// Get table data if a table is selected
$table_structure = null;
$table_data = null;
$total_records = 0;
$total_pages = 0;

if ($current_table) {
    $table_structure = getTableStructure($conn, $current_table);
    $table_data = getTableData($conn, $current_table, $records_per_page, $offset);
    $total_records = countRecords($conn, $current_table);
    $total_pages = ceil($total_records / $records_per_page);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css">
    <style>
        .sidebar {
            background-color: #f8f9fa;
            height: 100vh;
            position: sticky;
            top: 0;
        }
        .main-content {
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar py-3">
                <h4 class="text-center">Admin Panel</h4>
                <hr>
                <ul class="nav flex-column">
                    <?php foreach ($tables as $table): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_table == $table) ? 'active fw-bold' : ''; ?>" 
                           href="?table=<?php echo $table; ?>">
                            <?php echo ucfirst($table); ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <hr>
                <div class="d-grid gap-2 px-3">
                    <a href="logout.php" class="btn btn-danger">Logout</a>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-10 main-content">
                <?php if (!empty($message)): ?>
                <div class="alert alert-info alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                
                <?php if ($current_table): ?>
                <div class="mb-4">
                    <h2>Table: <?php echo ucfirst($current_table); ?></h2>
                    
                    <!-- Add New Record Button -->
                    <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addRecordModal">
                        Add New Record
                    </button>
                    
                    <!-- Table Data -->
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-light">
                                <tr>
                                    <?php foreach ($table_structure as $column): ?>
                                    <th><?php echo $column['Field']; ?></th>
                                    <?php endforeach; ?>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($table_data)): ?>
                                <tr>
                                    <td colspan="<?php echo count($table_structure) + 1; ?>" class="text-center">No records found</td>
                                </tr>
                                <?php else: ?>
                                <?php foreach ($table_data as $row): ?>
                                <tr>
                                    <?php foreach ($table_structure as $column): ?>
                                    <td><?php echo htmlspecialchars($row[$column['Field']] ?? ''); ?></td>
                                    <?php endforeach; ?>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-warning edit-record" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editRecordModal"
                                                data-record='<?php echo json_encode($row); ?>'>
                                            Edit
                                        </button>
                                        <button type="button" class="btn btn-sm btn-danger delete-record" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#deleteConfirmModal"
                                                data-id="<?php echo $row[$table_structure[0]['Field']]; ?>"
                                                data-id-column="<?php echo $table_structure[0]['Field']; ?>">
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                    <nav>
                        <ul class="pagination">
                            <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?table=<?php echo $current_table; ?>&page=<?php echo $page-1; ?>">Previous</a>
                            </li>
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?php echo ($page == $i) ? 'active' : ''; ?>">
                                <a class="page-link" href="?table=<?php echo $current_table; ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?table=<?php echo $current_table; ?>&page=<?php echo $page+1; ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                    <?php endif; ?>
                </div>
                
                <!-- Add Record Modal -->
                <div class="modal fade" id="addRecordModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Add New Record</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="addRecordForm" method="post" action="">
                                    <input type="hidden" name="table" value="<?php echo $current_table; ?>">
                                    <input type="hidden" name="add" value="1">
                                    
                                    <?php foreach ($table_structure as $column): ?>
                                    <?php if ($column['Extra'] != 'auto_increment'): ?>
                                    <div class="mb-3">
                                        <label for="add_<?php echo $column['Field']; ?>" class="form-label"><?php echo $column['Field']; ?></label>
                                        <input type="text" class="form-control" id="add_<?php echo $column['Field']; ?>" 
                                               name="columns[]" value="<?php echo $column['Field']; ?>" hidden>
                                        <input type="text" class="form-control" name="values[]" 
                                               <?php echo ($column['Null'] === 'NO') ? 'required' : ''; ?>>
                                    </div>
                                    <?php endif; ?>
                                    <?php endforeach; ?>
                                    
                                    <div class="d-grid">
                                        <button type="submit" class="btn btn-primary">Add Record</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Edit Record Modal -->
                <div class="modal fade" id="editRecordModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Edit Record</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="editRecordForm" method="post" action="">
                                    <input type="hidden" name="table" value="<?php echo $current_table; ?>">
                                    <input type="hidden" name="edit" value="1">
                                    <input type="hidden" id="edit_id_column" name="id_column" value="">
                                    <input type="hidden" id="edit_id" name="id" value="">
                                    
                                    <div id="editFieldsContainer">
                                        <!-- Fields will be populated dynamically with JavaScript -->
                                    </div>
                                    
                                    <div class="d-grid">
                                        <button type="submit" class="btn btn-warning">Update Record</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Delete Confirmation Modal -->
                <div class="modal fade" id="deleteConfirmModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Confirm Delete</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p>Are you sure you want to delete this record? This action cannot be undone.</p>
                                <form id="deleteRecordForm" method="post" action="">
                                    <input type="hidden" name="table" value="<?php echo $current_table; ?>">
                                    <input type="hidden" name="delete" value="1">
                                    <input type="hidden" id="delete_id_column" name="id_column" value="">
                                    <input type="hidden" id="delete_id" name="id" value="">
                                    
                                    <div class="d-grid">
                                        <button type="submit" class="btn btn-danger">Delete Record</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="jumbotron">
                    <h1>Admin Dashboard</h1>
                    <p class="lead">Welcome to the admin dashboard. Please select a table from the sidebar to manage data.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script>
        // Handle edit record modal
        document.addEventListener('DOMContentLoaded', function() {
            const editButtons = document.querySelectorAll('.edit-record');
            const editFieldsContainer = document.getElementById('editFieldsContainer');
            const tableStructure = <?php echo json_encode($table_structure); ?>;
            const primaryKeyField = tableStructure ? tableStructure[0]['Field'] : '';
            
            editButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const record = JSON.parse(this.getAttribute('data-record'));
                    document.getElementById('edit_id_column').value = primaryKeyField;
                    document.getElementById('edit_id').value = record[primaryKeyField];
                    
                    // Clear previous fields
                    editFieldsContainer.innerHTML = '';
                    
                    // Add fields for each column
                    tableStructure.forEach(column => {
                        const fieldName = column['Field'];
                        if (fieldName !== primaryKeyField) {
                            const div = document.createElement('div');
                            div.className = 'mb-3';
                            
                            const label = document.createElement('label');
                            label.className = 'form-label';
                            label.textContent = fieldName;
                            
                            const hiddenInput = document.createElement('input');
                            hiddenInput.type = 'hidden';
                            hiddenInput.name = 'columns[]';
                            hiddenInput.value = fieldName;
                            
                            const input = document.createElement('input');
                            input.type = 'text';
                            input.className = 'form-control';
                            input.name = 'values[]';
                            input.value = record[fieldName] || '';
                            if (column['Null'] === 'NO') {
                                input.required = true;
                            }
                            
                            div.appendChild(label);
                            div.appendChild(hiddenInput);
                            div.appendChild(input);
                            editFieldsContainer.appendChild(div);
                        }
                    });
                });
            });
            
            // Handle delete confirmation
            const deleteButtons = document.querySelectorAll('.delete-record');
            
            deleteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    document.getElementById('delete_id_column').value = this.getAttribute('data-id-column');
                    document.getElementById('delete_id').value = this.getAttribute('data-id');
                });
            });
        });
    </script>
</body>
</html>