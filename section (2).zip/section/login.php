<?php
// Place this code at the top of your login.php file, before the HTML section

session_start();
require_once 'auth.php';

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: home.php");
    exit();
}

// Initialize error variable
$error = '';

// Process login form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        $error = 'Please enter both email and password';
    } else {
        // First try to authenticate against the users table with hashed passwords
        $conn = new mysqli("localhost", "root", "", "test1");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        
        $stmt = $conn->prepare("SELECT id, username, email, password FROM users WHERE email = ?");
        if ($stmt) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                
                // Verify the password
                if (password_verify($password, $user['password'])) {
                    // Password is correct, set session variables
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    
                    // Redirect to home page
                    header("Location: home.php");
                    exit();
                } else {
                    $error = 'Invalid email or password';
                }
            } else {
                // No user found in users table, check myguests1 table
                $stmt->close();
                
                $stmt = $conn->prepare("SELECT id, firstname, lastname, email FROM myguests1 WHERE email = ?");
                if ($stmt) {
                    $stmt->bind_param("s", $email);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($result->num_rows > 0) {
                        $guest = $result->fetch_assoc();
                        
                        /* IMPORTANT: myguests1 table doesn't have a password field
                           For this example, we'll assume if the user exists in myguests1
                           and not in users, we'll create a new entry in users table */
                           
                        // Set session variables from myguests1
                        $_SESSION['user_id'] = $guest['id'];
                        $_SESSION['username'] = $guest['firstname'] . ' ' . $guest['lastname'];
                        $_SESSION['email'] = $guest['email'];
                        
                        // Now create an entry in the users table for future logins
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        $fullname = $guest['firstname'] . ' ' . $guest['lastname'];
                        
                        $insert_stmt = $conn->prepare("INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, NOW())");
                        if ($insert_stmt) {
                            $insert_stmt->bind_param("sss", $fullname, $email, $hashed_password);
                            $insert_stmt->execute();
                            $insert_stmt->close();
                        }
                        
                        // Redirect to home page
                        header("Location: home.php");
                        exit();
                    } else {
                        $error = 'Invalid email or password';
                    }
                }
            }
            $stmt->close();
        }
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Porsche Experience</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --porsche-red: #d00;
            --porsche-dark: #1d1d1d;
            --porsche-silver: #e4e4e4;
            --porsche-light: #f8f8f8;
        }
        
        body, html {
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: 'Helvetica Neue', Arial, sans-serif;
            background-color: var(--porsche-dark);
            overflow-x: hidden;
        }
        
        .login-container {
            min-height: 100vh;
            display: flex;
            position: relative;
        }
        
        .background-diagonal {
            position: absolute;
            width: 150%;
            height: 100%;
            background: var(--porsche-light);
            transform: skewX(-20deg);
            right: 40%;
            z-index: 0;
        }
        
        .content-container {
            position: relative;
            z-index: 1;
            width: 100%;
            padding: 2rem;
            display: flex;
        }
        
        .left-panel {
            flex: 1;
            padding: 2rem;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: flex-start;
        }
        
        .right-panel {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 0 3rem;
        }
        
        .branding {
            margin-bottom: 4rem;
        }
        
        .branding img {
            height: 60px;
        }
        
        .welcome-heading {
            font-size: 3.2rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            letter-spacing: -0.5px;
            line-height: 1.2;
            color: black;
        }
        
        .welcome-text {
            font-size: 1.1rem;
            opacity: 0.85;
            margin-bottom: 2rem;
            max-width: 500px;
            color: black;
        }
        
        .slideshow {
            margin-top: 3rem;
            width: 100%;
            position: relative;
            height: 200px;
            overflow: hidden;
            border-radius: 8px;
        }
        
        .slideshow img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .feature-tag {
            display: inline-block;
            background: rgba(210, 0, 0, 0.15);
            color: var(--porsche-red);
            padding: 8px 16px;
            border-radius: 4px;
            font-weight: 500;
            font-size: 0.9rem;
            margin-right: 10px;
            margin-bottom: 10px;
            transition: transform 0.3s ease, background 0.3s ease;
        }
        
        .feature-tag:hover {
            transform: translateY(-3px);
            background: rgba(210, 0, 0, 0.25);
        }
        
        .login-form {
            background: white;
            padding: 3rem;
            border-radius: 10px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 450px;
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 0.8s forwards;
        }
        
        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .form-heading {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--porsche-dark);
        }
        
        .form-subheading {
            color: #777;
            margin-bottom: 2rem;
        }
        
        .form-floating {
            margin-bottom: 1.5rem;
        }
        
        .form-floating > label {
            padding-left: 1rem;
        }
        
        .form-control {
            border: none;
            border-bottom: 2px solid #e0e0e0;
            border-radius: 0;
            padding: 1rem 1rem;
            height: auto;
            background-color: transparent;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--porsche-red);
            box-shadow: none;
            background-color: rgba(210, 0, 0, 0.03);
        }
        
        .btn-porsche {
            background: var(--porsche-red);
            color: white;
            border: none;
            padding: 0.8rem 2rem;
            font-weight: 600;
            letter-spacing: 0.5px;
            border-radius: 4px;
            transition: all 0.3s;
            width: 100%;
            margin-top: 1rem;
        }
        
        .btn-porsche:hover {
            background: #b00;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(210, 0, 0, 0.3);
        }
        
        .auth-links {
            display: flex;
            justify-content: space-between;
            margin-top: 2rem;
            font-size: 0.95rem;
        }
        
        .auth-link {
            color: var(--porsche-red);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s;
        }
        
        .auth-link:hover {
            color: #b00;
            text-decoration: underline;
        }
        
        .footer {
            margin-top: 3rem;
            display: flex;
            align-items: center;
            color: rgba(255,255,255,0.7);
            font-size: 0.9rem;
        }
        
        .footer-divider {
            display: inline-block;
            width: 1px;
            height: 16px;
            background: rgba(255,255,255,0.3);
            margin: 0 15px;
        }
        
        .footer a {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            transition: all 0.2s;
        }
        
        .footer a:hover {
            color: white;
        }
        
        .social-icons {
            margin-left: auto;
        }
        
        .social-icons a {
            color: rgba(255,255,255,0.7);
            font-size: 1.1rem;
            margin-left: 15px;
            transition: all 0.2s;
        }
        
        .social-icons a:hover {
            color: white;
            transform: translateY(-3px);
        }
        
        .alert {
            border-radius: 4px;
            padding: 12px;
            margin-bottom: 1.5rem;
            border: none;
        }
        
        .alert-danger {
            background-color: rgba(210, 0, 0, 0.1);
            color: var(--porsche-red);
        }
        
        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #777;
            z-index: 10;
        }
        
        .password-field-wrapper {
            position: relative;
        }
        
        .remember-me {
            display: flex;
            align-items: center;
            margin-top: 1rem;
        }
        
        .remember-me input {
            margin-right: 0.5rem;
        }
        
        .form-feedback {
            font-size: 0.85rem;
            margin-top: 0.25rem;
            display: none;
        }
        
        .form-feedback.error {
            color: var(--porsche-red);
        }
        
        .form-feedback.success {
            color: #28a745;
        }
        
        .shake-animation {
            animation: shake 0.5s;
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        
        @media (max-width: 992px) {
            .content-container {
                flex-direction: column;
            }
            
            .background-diagonal {
                display: none;
            }
            
            .left-panel {
                color: var(--porsche-dark);
                padding: 1rem;
                align-items: center;
                text-align: center;
            }
            
            .right-panel {
                padding: 1rem;
                align-items: center;
                margin-top: 2rem;
            }
            
            .welcome-text {
                max-width: 100%;
            }
            
            .login-form {
                max-width: 100%;
                padding: 2rem;
            }
            
            .footer {
                flex-direction: column;
                gap: 15px;
            }
            
            .footer-divider {
                display: none;
            }
            
            .social-icons {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="background-diagonal"></div>
        
        <div class="content-container">
            <div class="left-panel">
                <div class="branding">
                    <img src="1720107822porsche-car-logo-png.png" alt="Porsche Logo">
                </div>
                
                <h1 class="welcome-heading">Drive Beyond<br>Expectations</h1>
                <p class="welcome-text">
                    Access your premium Porsche account to unlock exclusive services, event invitations, and personalized experiences tailored to your driving passion.
                </p>
                
                <div id="feature-tags">
                    <span class="feature-tag"><i class="fas fa-car-alt me-2"></i>Premium Selection</span>
                    <span class="feature-tag"><i class="fas fa-shield-alt me-2"></i>Certified Service</span>
                    <span class="feature-tag"><i class="fas fa-stopwatch me-2"></i>Track Events</span>
                </div>
                
                <div class="footer">
                    <a href="#">Privacy Policy</a>
                    <span class="footer-divider"></span>
                    <a href="#">Terms & Conditions</a>
                    <span class="footer-divider"></span>
                    <a href="#">Support</a>
                    
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>
            
            <div class="right-panel">
                <div class="login-form">
                    <h2 class="form-heading">Welcome Back</h2>
                    <p class="form-subheading">Continue your Porsche journey</p>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" id="loginForm">
                        <div class="form-floating mb-3">
                            <input type="email" class="form-control" id="email" name="email" placeholder="Email Address" required>
                            <label for="email">Email Address</label>
                            <div class="form-feedback" id="email-feedback"></div>
                        </div>
                        
                        <div class="form-floating mb-3 password-field-wrapper">
                            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                            <label for="password">Password</label>
                            <span class="password-toggle" id="passwordToggle">
                                <i class="far fa-eye"></i>
                            </span>
                            <div class="form-feedback" id="password-feedback"></div>
                        </div>
                        
                        <div class="remember-me">
                            <input type="checkbox" id="remember" name="remember">
                            <label for="remember">Remember me</label>
                        </div>
                        
                        <button type="submit" class="btn btn-porsche" id="loginButton">Sign In</button>
                        
                        <div class="auth-links">
                            <a href="register.php" class="auth-link">Create Account</a>
                        
							<a href="adminlogin.php"> Admin Login</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Password visibility toggle
            const passwordToggle = document.getElementById('passwordToggle');
            const passwordField = document.getElementById('password');
            
            passwordToggle.addEventListener('click', function() {
                const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordField.setAttribute('type', type);
                
                // Toggle eye icon
                this.querySelector('i').classList.toggle('fa-eye');
                this.querySelector('i').classList.toggle('fa-eye-slash');
            });
            
            // Form validation
            const loginForm = document.getElementById('loginForm');
            const emailInput = document.getElementById('email');
            const emailFeedback = document.getElementById('email-feedback');
            const passwordInput = document.getElementById('password');
            const passwordFeedback = document.getElementById('password-feedback');
            const loginButton = document.getElementById('loginButton');
            
            // Email validation
            emailInput.addEventListener('blur', function() {
                validateEmail();
            });
            
            // Password validation
            passwordInput.addEventListener('blur', function() {
                validatePassword();
            });
            
            function validateEmail() {
                const email = emailInput.value.trim();
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                
                if (email === '') {
                    emailFeedback.textContent = 'Email is required';
                    emailFeedback.className = 'form-feedback error';
                    emailFeedback.style.display = 'block';
                    emailInput.style.borderColor = 'var(--porsche-red)';
                    return false;
                } else if (!emailRegex.test(email)) {
                    emailFeedback.textContent = 'Please enter a valid email address';
                    emailFeedback.className = 'form-feedback error';
                    emailFeedback.style.display = 'block';
                    emailInput.style.borderColor = 'var(--porsche-red)';
                    return false;
                } else {
                    emailFeedback.textContent = 'Looks good!';
                    emailFeedback.className = 'form-feedback success';
                    emailFeedback.style.display = 'block';
                    emailInput.style.borderColor = '#28a745';
                    return true;
                }
            }
            
            function validatePassword() {
                const password = passwordInput.value.trim();
                
                if (password === '') {
                    passwordFeedback.textContent = 'Password is required';
                    passwordFeedback.className = 'form-feedback error';
                    passwordFeedback.style.display = 'block';
                    passwordInput.style.borderColor = 'var(--porsche-red)';
                    return false;
                } else if (password.length < 6) {
                    passwordFeedback.textContent = 'Password must be at least 6 characters';
                    passwordFeedback.className = 'form-feedback error';
                    passwordFeedback.style.display = 'block';
                    passwordInput.style.borderColor = 'var(--porsche-red)';
                    return false;
                } else {
                    passwordFeedback.textContent = 'Looks good!';
                    passwordFeedback.className = 'form-feedback success';
                    passwordFeedback.style.display = 'block';
                    passwordInput.style.borderColor = '#28a745';
                    return true;
                }
            }
            
            // Form submission
            loginForm.addEventListener('submit', function(event) {
                event.preventDefault();
                
                const isEmailValid = validateEmail();
                const isPasswordValid = validatePassword();
                
                if (isEmailValid && isPasswordValid) {
                    // Show loading state on button
                    loginButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Signing In...';
                    loginButton.disabled = true;
                    
                    // Normally we would submit the form here, but for demo purposes we'll simulate a delay
                    setTimeout(() => {
                        // Submit the form programmatically
                        this.submit();
                    }, 1000);
                } else {
                    // Add shake animation if form is invalid
                    loginForm.classList.add('shake-animation');
                    setTimeout(() => {
                        loginForm.classList.remove('shake-animation');
                    }, 500);
                }
            });
            
            // Forgot password
            const forgotPassword = document.getElementById('forgotPassword');
            forgotPassword.addEventListener('click', function(e) {
                e.preventDefault();
                
                const email = emailInput.value.trim();
                if (email && validateEmail()) {
                    alert(`Password reset instructions have been sent to ${email}`);
                } else {
                    alert('Please enter a valid email address to reset your password');
                    emailInput.focus();
                }
            });
            
            // Feature tags hover effect
            const featureTags = document.querySelectorAll('.feature-tag');
            featureTags.forEach(tag => {
                tag.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-3px)';
                    this.style.background = 'rgba(210, 0, 0, 0.25)';
                });
                
                tag.addEventListener('mouseleave', function() {
                    this.style.transform = '';
                    this.style.background = '';
                });
            });
            
            // Animated background for feature tags section
            const featureTagsContainer = document.getElementById('feature-tags');
            
            function animateFeatureTags() {
                featureTags.forEach((tag, index) => {
                    setTimeout(() => {
                        tag.classList.add('animated');
                        tag.style.transform = 'translateY(-3px)';
                        tag.style.background = 'rgba(210, 0, 0, 0.25)';
                        
                        setTimeout(() => {
                            tag.style.transform = '';
                            tag.style.background = '';
                        }, 500);
                    }, index * 300);
                });
            }
            
            // Run the animation once on page load
            setTimeout(animateFeatureTags, 1000);
            
            // And then every 5 seconds
            setInterval(animateFeatureTags, 5000);
        });
    </script>
</body>
</html>