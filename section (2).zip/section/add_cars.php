<?php
session_start();

// Include database connection function
function connectDB() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "test1";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        return false;
    }
    
    return $conn;
}

// Function to add a new car
function addCar($car_data) {
    $conn = connectDB();
    if (!$conn) {
        return false;
    }
    
    $sql = "INSERT INTO cars (model, year, price, engine, transmission, mileage, color, image_url, description, short_description, features) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        // Convert features array to JSON string
        $features_json = json_encode($car_data['features']);
        
        $stmt->bind_param(
            "sidssisssss", 
            $car_data['model'], 
            $car_data['year'], 
            $car_data['price'], 
            $car_data['engine'], 
            $car_data['transmission'], 
            $car_data['mileage'], 
            $car_data['color'], 
            $car_data['image_url'], 
            $car_data['description'], 
            $car_data['short_description'], 
            $features_json
        );
        
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $result;
    }
    
    $conn->close();
    return false;
}

// Check if form was submitted
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_car'])) {
    $new_car = [
        'model' => $_POST['model'],
        'year' => (int)$_POST['year'],
        'price' => (float)$_POST['price'],
        'engine' => $_POST['engine'],
        'transmission' => $_POST['transmission'],
        'mileage' => (int)$_POST['mileage'],
        'color' => $_POST['color'],
        'image_url' => $_POST['image_url'],
        'description' => $_POST['description'],
        'short_description' => $_POST['short_description'],
        'features' => explode(',', $_POST['features']) // Convert comma-separated string to array
    ];
    
    // Trim whitespace from features
    $new_car['features'] = array_map('trim', $new_car['features']);
    
    if (addCar($new_car)) {
        $message = '<div class="alert alert-success">Car added successfully!</div>';
    } else {
        $message = '<div class="alert alert-danger">Error adding car to database.</div>';
    }
}

// Function to add multiple sample cars
function addSampleCars() {
    $sample_cars = [
        [
            'model' => 'Porsche 718 Boxster',
            'year' => 2023,
            'price' => 65500.00,
            'engine' => '2.0L Turbocharged Flat-Four',
            'transmission' => '6-Speed Manual',
            'mileage' => 950,
            'color' => 'Racing Yellow',
            'image_url' => 'images/cars/porsche-boxster.jpg',
            'description' => 'The Porsche 718 Boxster delivers mid-engine thrills with its potent turbocharged flat-four engine. Featuring perfect balance and responsive handling, this convertible sports car offers an exhilarating open-top driving experience with the quality and refinement expected from Porsche.',
            'short_description' => 'Mid-engine convertible with exceptional balance and driving dynamics',
            'features' => ['Sport Exhaust System', 'Sport Chrono Package', '20-inch Carrera S Wheels', 'BOSE Surround Sound System', 'Two-zone Automatic Climate Control']
        ],
        [
            'model' => 'Porsche 911 GT3',
            'year' => 2023,
            'price' => 175900.00,
            'engine' => '4.0L Naturally Aspirated Flat-Six',
            'transmission' => '7-Speed PDK',
            'mileage' => 350,
            'color' => 'Guards Red',
            'image_url' => 'images/cars/porsche-gt3.jpg',
            'description' => 'The Porsche 911 GT3 represents the pinnacle of naturally aspirated 911 performance. With its motorsport-derived 4.0L flat-six engine producing 502 horsepower and capable of revving to 9,000 rpm, the GT3 delivers a visceral driving experience. Featuring aerodynamic enhancements including a swan-neck rear wing, front diffuser, and rear diffuser, the GT3 generates significant downforce for track performance.',
            'short_description' => 'Track-focused 911 with motorsport technology and incredible performance',
            'features' => ['Carbon Ceramic Brakes', 'Full Bucket Seats', 'Clubsport Package', '20/21-inch GT3 Wheels', 'Front Axle Lift System', 'LED Headlights with PDLS Plus']
        ],
        [
            'model' => 'Porsche Cayenne GTS Coupe',
            'year' => 2023,
            'price' => 115000.00,
            'engine' => '4.0L Twin-Turbo V8',
            'transmission' => '8-Speed Tiptronic S',
            'mileage' => 2100,
            'color' => 'Carmine Red',
            'image_url' => 'images/cars/porsche-cayenne-coupe.jpg',
            'description' => 'The Porsche Cayenne GTS Coupe combines sporty styling with exceptional performance. Featuring a twin-turbocharged V8 engine producing 453 horsepower, sport-tuned suspension lowered by 30mm, and standard Sport Exhaust system, the GTS Coupe delivers an engaging driving experience. The coupe roofline enhances the sporty character while maintaining practicality.',
            'short_description' => 'Performance-focused SUV coupe with distinctive styling and V8 power',
            'features' => ['Adaptive Air Suspension', 'Sport Chrono Package', '21-inch RS Spyder Design Wheels', 'Sport Design Package', 'BOSE Surround Sound System', 'Four-zone Climate Control']
        ],
    ];
    
    $success_count = 0;
    foreach ($sample_cars as $car) {
        if (addCar($car)) {
            $success_count++;
        }
    }
    
    return $success_count;
}

// Check if sample cars button was pressed
if (isset($_POST['add_sample_cars'])) {
    $added_count = addSampleCars();
    $message = "<div class='alert alert-success'>Successfully added $added_count sample cars!</div>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Cars</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 900px;
            background-color: #fff;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            margin-bottom: 30px;
            color: #212529;
        }
        .btn-primary {
            background-color: #0d6efd;
        }
        .btn-success {
            margin-top: 20px;
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Add New Car</h1>
        
        <?php echo $message; ?>
        
        <form method="post" action="">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="model" class="form-label">Model</label>
                    <input type="text" class="form-control" id="model" name="model" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label for="year" class="form-label">Year</label>
                    <input type="number" class="form-control" id="year" name="year" min="1900" max="2030" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label for="price" class="form-label">Price</label>
                    <input type="number" class="form-control" id="price" name="price" min="0" step="0.01" required>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="engine" class="form-label">Engine</label>
                    <input type="text" class="form-control" id="engine" name="engine" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="transmission" class="form-label">Transmission</label>
                    <input type="text" class="form-control" id="transmission" name="transmission" required>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="mileage" class="form-label">Mileage</label>
                    <input type="number" class="form-control" id="mileage" name="mileage" min="0" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="color" class="form-label">Color</label>
                    <input type="text" class="form-control" id="color" name="color" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="image_url" class="form-label">Image URL</label>
                    <input type="text" class="form-control" id="image_url" name="image_url" value="images/cars/porsche-default.jpg">
                </div>
            </div>
            
            <div class="mb-3">
                <label for="short_description" class="form-label">Short Description</label>
                <input type="text" class="form-control" id="short_description" name="short_description" required>
            </div>
            
            <div class="mb-3">
                <label for="description" class="form-label">Full Description</label>
                <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
            </div>
            
            <div class="mb-3">
                <label for="features" class="form-label">Features (comma-separated)</label>
                <textarea class="form-control" id="features" name="features" rows="3" required></textarea>
                <div class="form-text">Enter features separated by commas (e.g., Sport Package, Leather Interior, Navigation)</div>
            </div>
            
            <button type="submit" name="add_car" class="btn btn-primary">Add Car</button>
        </form>
        
        <hr class="my-4">
        
        <h2>Add Sample Cars</h2>
        <p>Click the button below to add predefined sample cars to the database.</p>
        <form method="post" action="">
            <button type="submit" name="add_sample_cars" class="btn btn-success">Add Sample Cars</button>
        </form>
        
        <div class="mt-4">
            <a href="buy.php" class="btn btn-secondary">Back to Cars List</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>