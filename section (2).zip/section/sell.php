<?php
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test1";

// Check if user is authenticated or a guest
$is_logged_in = isset($_SESSION['user_id']);
$is_guest = isset($_SESSION['guest']) && $_SESSION['guest'] === true;

// Redirect if not logged in or guest
if (!$is_logged_in && !$is_guest) {
    header("Location: login.php");
    exit();
}

$submission_success = false;
$submission_error = '';
$form_data = []; // To preserve form data on validation failure

/**
 * Establishes database connection
 * @return mysqli|false Returns a mysqli connection object or false on failure
 */
function connectDB() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "test1";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        return false;
    }
    
    return $conn;
}

/**
 * Sanitizes input data to prevent XSS attacks
 * @param string $data Data to sanitize
 * @return string Sanitized data
 */
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Validates form data
 * @param array $data Form data to validate
 * @return array Array with validation status and error messages
 */
function validateFormData($data) {
    $errors = [];
    
    // Validate required fields
    $required_fields = ['seller_name', 'email', 'phone', 'car_model', 'car_year', 'car_color', 'car_mileage', 'asking_price'];
    foreach ($required_fields as $field) {
        if (empty($data[$field])) {
            $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required';
        }
    }
    
    // Validate email
    if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address';
    }
    
    // Validate phone (simple validation for demonstration)
    if (!empty($data['phone']) && !preg_match('/^[0-9+() -]{6,20}$/', $data['phone'])) {
        $errors[] = 'Please enter a valid phone number';
    }
    
    // Validate year
    if (!empty($data['car_year'])) {
        $year = (int)$data['car_year'];
        $current_year = (int)date('Y');
        if ($year < 1950 || $year > $current_year) {
            $errors[] = 'Please enter a valid year between 1950 and ' . $current_year;
        }
    }
    
    // Validate mileage
    if (!empty($data['car_mileage']) && ((int)$data['car_mileage'] < 0)) {
        $errors[] = 'Mileage cannot be negative';
    }
    
    // Validate price
    if (!empty($data['asking_price']) && ((float)$data['asking_price'] <= 0)) {
        $errors[] = 'Please enter a valid asking price';
    }
    
    return [
        'valid' => empty($errors),
        'errors' => $errors
    ];
}

/**
 * Create vehicles table if it doesn't exist
 * @param mysqli $conn Database connection
 * @return bool Success status
 */
function ensureVehiclesTableExists($conn) {
    $create_table_sql = "CREATE TABLE IF NOT EXISTS vehicles (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT(6) NULL,
        seller_name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        car_model VARCHAR(100) NOT NULL,
        car_year INT(4) NOT NULL,
        car_color VARCHAR(50) NOT NULL,
        car_mileage INT(10) NOT NULL,
        car_condition VARCHAR(50) NOT NULL,
        asking_price DECIMAL(10,2) NOT NULL,
        additional_info TEXT,
        submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (user_id)
    )";
    
    return $conn->query($create_table_sql);
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize all input data
    foreach ($_POST as $key => $value) {
        $form_data[$key] = sanitizeInput($value);
    }
    
    // Validate form data
    $validation = validateFormData($form_data);
    
    if (!$validation['valid']) {
        $submission_error = implode('<br>', $validation['errors']);
    } else {
        // Connect to database
        $conn = connectDB();
        
        if (!$conn) {
            $submission_error = 'Database connection failed. Please try again later.';
        } else {
            // Ensure vehicles table exists
            if (!ensureVehiclesTableExists($conn)) {
                $submission_error = "Error creating table: " . $conn->error;
            } else {
                // Prepare data for insertion
                $user_id = $is_logged_in ? $_SESSION['user_id'] : null;
                $seller_name = $conn->real_escape_string($form_data['seller_name']);
                $email = $conn->real_escape_string($form_data['email']);
                $phone = $conn->real_escape_string($form_data['phone']);
                $car_model = $conn->real_escape_string($form_data['car_model']);
                $car_year = (int)$form_data['car_year'];
                $car_color = $conn->real_escape_string($form_data['car_color']);
                $car_mileage = (int)$form_data['car_mileage'];
                $car_condition = $conn->real_escape_string($form_data['car_condition']);
                $asking_price = (float)$form_data['asking_price'];
                $additional_info = $conn->real_escape_string($form_data['additional_info'] ?? '');
                
                // Insert vehicle data using prepared statement
                $insert_sql = "INSERT INTO vehicles (user_id, seller_name, email, phone, car_model, car_year, car_color, car_mileage, car_condition, asking_price, additional_info) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                $stmt = $conn->prepare($insert_sql);
                if (!$stmt) {
                    $submission_error = "Preparation failed: " . $conn->error;
                } else {
                    $stmt->bind_param("issssisisds", $user_id, $seller_name, $email, $phone, $car_model, $car_year, $car_color, $car_mileage, $car_condition, $asking_price, $additional_info);
                    
                    if ($stmt->execute()) {
                        $submission_success = true;
                        // Clear form data on successful submission
                        $form_data = [];
                    } else {
                        $submission_error = "Error: " . $stmt->error;
                    }
                    
                    $stmt->close();
                }
            }
            
            $conn->close();
        }
    }
}

// Pre-fill form data for logged-in users if first visit
if ($is_logged_in && empty($form_data)) {
    $form_data['seller_name'] = $_SESSION['username'] ?? '';
    $form_data['email'] = $_SESSION['email'] ?? '';
}

// Get the current year for the year input max value
$current_year = date('Y');
?>

<?php include 'header.php'; ?>

<main>
    <section class="sell-section py-5">
        <div class="container">
            <div class="section-header text-center mb-5">
                <h1 class="fw-bold">Sell Your Porsche</h1>
                <p class="lead">Get the best value for your premium vehicle</p>
            </div>
            
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <?php if ($submission_success): ?>
                    <!-- Success message -->
                    <div class="card mb-4">
                        <div class="card-body text-center p-5">
                            <div class="mb-4">
                                <i class="fas fa-check-circle text-success" style="font-size: 3.5rem;"></i>
                            </div>
                            <h2 class="fw-bold mb-3">Thank You for Your Submission</h2>
                            <p class="lead mb-4">We've received your Porsche details and our team will review your information promptly. You can expect to hear from one of our specialists within 24-48 hours.</p>
                            <div class="d-flex justify-content-center gap-3">
                                <a href="home.php" class="btn btn-primary">Return to Home</a>
                                <a href="sell.php" class="btn btn-outline-secondary">Submit Another Vehicle</a>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <!-- Form card -->
                    <div class="card mb-4 shadow-sm">
                        <div class="card-body p-4">
                            <h3 class="fw-bold mb-4">Vehicle Details Form</h3>
                            
                            <?php if ($submission_error): ?>
                            <div class="alert alert-danger mb-4">
                                <?php echo $submission_error; ?>
                            </div>
                            <?php endif; ?>
                            
                            <form method="POST" action="sell.php" novalidate>
                                <!-- Contact Information -->
                                <div class="mb-4">
                                    <h5 class="fw-bold mb-3">Contact Information</h5>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="seller_name" class="form-label">Your Name*</label>
                                            <input type="text" class="form-control" id="seller_name" name="seller_name" value="<?php echo htmlspecialchars($form_data['seller_name'] ?? ''); ?>" required>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label for="email" class="form-label">Email Address*</label>
                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($form_data['email'] ?? ''); ?>" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="phone" class="form-label">Phone Number*</label>
                                        <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($form_data['phone'] ?? ''); ?>" placeholder="+1 (123) 456-7890" required>
                                    </div>
                                </div>
                                
                                <hr class="my-4">
                                
                                <!-- Car Information -->
                                <div class="mb-4">
                                    <h5 class="fw-bold mb-3">Porsche Details</h5>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="car_model" class="form-label">Porsche Model*</label>
                                            <input type="text" class="form-control" id="car_model" name="car_model" value="<?php echo htmlspecialchars($form_data['car_model'] ?? ''); ?>" placeholder="e.g. 911 Carrera, Cayenne, Panamera" required>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label for="car_year" class="form-label">Year*</label>
                                            <input type="number" class="form-control" id="car_year" name="car_year" value="<?php echo htmlspecialchars($form_data['car_year'] ?? ''); ?>" min="1950" max="<?php echo $current_year; ?>" required>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="car_color" class="form-label">Color*</label>
                                            <input type="text" class="form-control" id="car_color" name="car_color" value="<?php echo htmlspecialchars($form_data['car_color'] ?? ''); ?>" required>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label for="car_mileage" class="form-label">Mileage (km)*</label>
                                            <input type="number" class="form-control" id="car_mileage" name="car_mileage" value="<?php echo htmlspecialchars($form_data['car_mileage'] ?? ''); ?>" min="0" step = '100' required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="car_condition" class="form-label">Vehicle Condition*</label>
                                        <select class="form-select" id="car_condition" name="car_condition" required>
                                            <option value="">-- Select Condition --</option>
                                            <option value="Excellent" <?php echo (isset($form_data['car_condition']) && $form_data['car_condition'] == 'Excellent') ? 'selected' : ''; ?>>Excellent - Like new condition</option>
                                            <option value="Very Good" <?php echo (isset($form_data['car_condition']) && $form_data['car_condition'] == 'Very Good') ? 'selected' : ''; ?>>Very Good - Minor wear, well maintained</option>
                                            <option value="Good" <?php echo (isset($form_data['car_condition']) && $form_data['car_condition'] == 'Good') ? 'selected' : ''; ?>>Good - Normal wear for age and mileage</option>
                                            <option value="Fair" <?php echo (isset($form_data['car_condition']) && $form_data['car_condition'] == 'Fair') ? 'selected' : ''; ?>>Fair - Some mechanical or cosmetic issues</option>
                                            <option value="Poor" <?php echo (isset($form_data['car_condition']) && $form_data['car_condition'] == 'Poor') ? 'selected' : ''; ?>>Poor - Significant mechanical or cosmetic issues</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="asking_price" class="form-label">Asking Price (€)*</label>
                                        <div class="input-group">
                                            <span class="input-group-text">€</span>
                                            <input type="number" class="form-control" id="asking_price" name="asking_price" value="<?php echo htmlspecialchars($form_data['asking_price'] ?? ''); ?>" min="0" step="1000" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="additional_info" class="form-label">Additional Information</label>
                                        <textarea class="form-control" id="additional_info" name="additional_info" rows="4" placeholder="Please include any additional details about your vehicle, such as options, modifications, service history, or any issues."><?php echo htmlspecialchars($form_data['additional_info'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                                
                                <!-- Terms and Submit -->
                                <div class="form-check mb-4">
                                    <input class="form-check-input" type="checkbox" id="terms_agreement" name="terms_agreement" required>
                                    <label class="form-check-label" for="terms_agreement">
                                        I agree to be contacted about my vehicle and I confirm that the information provided is accurate.
                                    </label>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary btn-lg">Submit Vehicle Information</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <!-- How it works section -->
                    <div class="sell-process mt-5">
                        <div class="section-header text-center mb-4">
                            <h3 class="fw-bold">The Porsche Selling Process</h3>
                            <p>Three simple steps to sell your vehicle</p>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <div class="card h-100 process-card text-center shadow-sm">
                                    <div class="card-body p-4">
                                        <div class="process-icon mb-3">
                                            <i class="fas fa-clipboard-list fa-3x text-primary"></i>
                                        </div>
                                        <h5 class="card-title fw-bold">1. Submit Details</h5>
                                        <p class="card-text">Complete our form with comprehensive information about your Porsche.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-4 mb-4">
                                <div class="card h-100 process-card text-center shadow-sm">
                                    <div class="card-body p-4">
                                        <div class="process-icon mb-3">
                                            <i class="fas fa-search-dollar fa-3x text-primary"></i>
                                        </div>
                                        <h5 class="card-title fw-bold">2. Get Evaluated</h5>
                                        <p class="card-text">Our certified Porsche specialists will evaluate your vehicle and provide a competitive offer.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-4 mb-4">
                                <div class="card h-100 process-card text-center shadow-sm">
                                    <div class="card-body p-4">
                                        <div class="process-icon mb-3">
                                            <i class="fas fa-handshake fa-3x text-primary"></i>
                                        </div>
                                        <h5 class="card-title fw-bold">3. Close the Deal</h5>
                                        <p class="card-text">Accept our offer and complete the sale with secure payment and hassle-free paperwork.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Customer testimonial -->
                        <div class="card mt-4 border-0 bg-light">
                            <div class="card-body p-4">
                                <div class="d-flex">
                                    <div class="testimonial-quote pe-4">
                                        <i class="fas fa-quote-left fa-3x text-secondary opacity-25"></i>
                                    </div>
                                    <div>
                                        <p class="lead mb-3">
                                            "I was amazed at how simple the process was to sell my 911. The team offered me a fair price and handled all the paperwork. I would definitely recommend this service to any Porsche owner looking to sell."
                                        </p>
                                        <div class="d-flex align-items-center">
                                            <strong class="me-2">Michael S.</strong>
                                            <small class="text-muted">Sold a 2018 Porsche 911 Carrera</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include 'footer.php'; ?>

<script>
// Client-side validation
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    
    if (form) {
        form.addEventListener('submit', function(event) {
            let isValid = true;
            
            // Required fields validation
            const requiredFields = ['seller_name', 'email', 'phone', 'car_model', 'car_year', 'car_color', 'car_mileage', 'asking_price', 'car_condition'];
            
            requiredFields.forEach(field => {
                const input = document.getElementById(field);
                if (!input.value.trim()) {
                    input.classList.add('is-invalid');
                    isValid = false;
                } else {
                    input.classList.remove('is-invalid');
                }
            });
            
            // Email validation
            const emailInput = document.getElementById('email');
            if (emailInput.value.trim() && !isValidEmail(emailInput.value.trim())) {
                emailInput.classList.add('is-invalid');
                isValid = false;
            }
            
            // Terms checkbox validation
            const termsCheckbox = document.getElementById('terms_agreement');
            if (!termsCheckbox.checked) {
                termsCheckbox.classList.add('is-invalid');
                isValid = false;
            } else {
                termsCheckbox.classList.remove('is-invalid');
            }
            
            if (!isValid) {
                event.preventDefault();
                // Scroll to the first invalid field
                const firstInvalid = document.querySelector('.is-invalid');
                if (firstInvalid) {
                    firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }
        });
        
        // Add input event listeners to clear invalid state
        document.querySelectorAll('input, select, textarea').forEach(element => {
            element.addEventListener('input', function() {
                this.classList.remove('is-invalid');
            });
        });
    }
    
    // Email validation helper
    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
});
</script>

<?php
// Close database connection if still open
if (isset($conn) && $conn instanceof mysqli) {
    $conn->close();
}
?>