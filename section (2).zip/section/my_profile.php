<?php
session_start();

// Check if user is authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test1";

/**
 * Establishes database connection
 * @return mysqli|false Returns a mysqli connection object or false on failure
 */
function connectDB() {
    global $servername, $username, $password, $dbname;
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        return false;
    }
    
    return $conn;
}

/**
 * Sanitizes input data to prevent XSS attacks
 * @param string $data Data to sanitize
 * @return string Sanitized data
 */
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Initialize variables
$user_id = $_SESSION['user_id'];
$user_details = [];
$update_success = false;
$update_error = '';

// Connect to database
$conn = connectDB();
if (!$conn) {
    $update_error = 'Database connection failed. Please try again later.';
} else {
    // Create users table if not exists (for safety)
    $create_users_table = "CREATE TABLE IF NOT EXISTS users (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone VARCHAR(20),
        address TEXT,
        registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->query($create_users_table);

    // Check if the phone column exists
    $check_column = "SHOW COLUMNS FROM users LIKE 'phone'";
    $column_result = $conn->query($check_column);
    
    if ($column_result->num_rows == 0) {
        // Add phone column if it doesn't exist
        $add_column = "ALTER TABLE users ADD COLUMN phone VARCHAR(20) AFTER email";
        $conn->query($add_column);
    }
    
    // Check if the address column exists
    $check_column = "SHOW COLUMNS FROM users LIKE 'address'";
    $column_result = $conn->query($check_column);
    
    if ($column_result->num_rows == 0) {
        // Add address column if it doesn't exist
        $add_column = "ALTER TABLE users ADD COLUMN address TEXT AFTER phone";
        $conn->query($add_column);
    }

    // Get user details
    $stmt = $conn->prepare("SELECT username, email, phone, address FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $user_details = $result->fetch_assoc();
    } else {
        $update_error = 'User not found.';
    }
    
    $stmt->close();
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    // Get and sanitize form data
    $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone'] ?? '');
    $address = sanitizeInput($_POST['address'] ?? '');
    
    // Validate email
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $update_error = 'Please enter a valid email address.';
    } else {
        // Connect to database if not already connected
        if (!$conn) {
            $conn = connectDB();
        }
        
        if (!$conn) {
            $update_error = 'Database connection failed. Please try again later.';
        } else {
            // Update user details
            $stmt = $conn->prepare("UPDATE users SET email = ?, phone = ?, address = ? WHERE id = ?");
            $stmt->bind_param("sssi", $email, $phone, $address, $user_id);
            
            if ($stmt->execute()) {
                $update_success = true;
                
                // Update session data
                $_SESSION['email'] = $email;
                
                // Refresh user details
                $user_details['email'] = $email;
                $user_details['phone'] = $phone;
                $user_details['address'] = $address;
            } else {
                $update_error = 'Error updating profile: ' . $stmt->error;
            }
            
            $stmt->close();
        }
    }
}

// Close connection
if ($conn) {
    $conn->close();
}

// Include header
include 'header.php';
?>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-10 mx-auto">
            <h1 class="mb-4">My Profile</h1>
            
            <?php if ($update_success): ?>
            <div class="alert alert-success">
                Profile updated successfully.
            </div>
            <?php endif; ?>
            
            <?php if ($update_error): ?>
            <div class="alert alert-danger">
                <?php echo $update_error; ?>
            </div>
            <?php endif; ?>
            
            <div class="card shadow">
                <div class="card-body">
                    <h2 class="card-title mb-4">Personal Information</h2>
                    
                    <form method="post" action="">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" value="<?php echo htmlspecialchars($user_details['username'] ?? ''); ?>" disabled>
                            <div class="form-text">Username cannot be changed.</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user_details['email'] ?? ''); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($user_details['phone'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <textarea class="form-control" id="address" name="address" rows="3"><?php echo htmlspecialchars($user_details['address'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="mt-4">
                <a href="index.php" class="btn btn-outline-secondary ms-2">Back to Home</a>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include 'footer.php';
?>