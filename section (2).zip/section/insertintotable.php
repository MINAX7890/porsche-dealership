
<?php

$servername = "localhost";
$username = "root";
$password = "";/* Put your password here */
$db="test1";
        /* Create connection */
$conn = new mysqli($servername, $username, $password,$db);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
echo $_POST['stDept']."<br>";
$fn=$_POST['FirstName'];
if(isset($_POST['FirstName'])&& isset($_POST['LastName']))
{
    $sql = "INSERT INTO MyGuests (firstname, lastname, email)
    VALUES ('$fn', '".$_POST['LastName']."', '".$_POST['mail']."')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }   
}
 else {
    echo"please write first name or last name";
    #header("Location: form.html");
}
/*
session_start();
$_SESSION['FirstName'] = $_POST['FirstName'];
$_SESSION['LastName'] = $_POST['LastName'];
$_SESSION['mail']=$_POST['Email'];
header("Location: displaysession.php");
*/