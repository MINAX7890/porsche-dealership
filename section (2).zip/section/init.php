<?php
/**
 * Application Initialization
 * 
 * Initialize the database, create necessary tables, and start session
 */

require_once 'config.php';
require_once 'database.php';
require_once 'tables.php';

// Start session with secure settings
session_start();

// Initialize database if needed
if (!defined('DATABASE_INITIALIZED')) {
    $initialized = initializeDatabase();
    if ($initialized) {
        define('DATABASE_INITIALIZED', true);
    } else {
        error_log("Database initialization failed");
    }
}

/**
 * Utility function to redirect with a message
 * @param string $url URL to redirect to
 * @param string $message Message to display after redirect
 * @param string $type Type of message (success, error, info)
 * @return void
 */
function redirectWith($url, $message = '', $type = 'info') {
    if (!empty($message)) {
        // Store message in session for display after redirect
        $_SESSION['flash_message'] = $message;
        $_SESSION['flash_type'] = $type;
    }
    
    header("Location: $url");
    exit;
}

/**
 * Display flash message if exists
 * @return string HTML for the flash message
 */
function displayFlashMessage() {
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        $type = isset($_SESSION['flash_type']) ? $_SESSION['flash_type'] : 'info';
        
        // Clear the message
        unset($_SESSION['flash_message']);
        unset($_SESSION['flash_type']);
        
        // Define CSS classes for different message types
        $class = 'alert ';
        switch ($type) {
            case 'success':
                $class .= 'alert-success';
                break;
            case 'error':
                $class .= 'alert-danger';
                break;
            default:
                $class .= 'alert-info';
        }
        
        return "<div class=\"$class\" role=\"alert\">$message</div>";
    }
    
    return '';
}
?>