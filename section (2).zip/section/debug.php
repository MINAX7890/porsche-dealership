<?php
// db_debug.php - Test database connection
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test1";

echo "<h2>PHP Database Connection Test</h2>";

// Test server connection without database
echo "<p>Testing connection to MySQL server...</p>";
try {
    $conn = new mysqli($servername, $username, $password);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    echo "<p style='color:green'>MySQL server connection successful!</p>";
    
    // Test database existence or creation
    echo "<p>Testing database...</p>";
    $sql = "CREATE DATABASE IF NOT EXISTS `$dbname`";
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green'>Database check/creation successful.</p>";
    } else {
        echo "<p style='color:red'>Error creating database: " . $conn->error . "</p>";
    }
    
    // Test database connection
    echo "<p>Testing connection to the database...</p>";
    $conn->select_db($dbname);
    echo "<p style='color:green'>Database connection successful!</p>";
    
    $conn->close();
} catch (Exception $e) {
    echo "<p style='color:red'>Error: " . $e->getMessage() . "</p>";
}

// Check PHP and extension info
echo "<h3>PHP Information</h3>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>MySQLi extension loaded: " . (extension_loaded('mysqli') ? 'Yes' : 'No') . "</p>";

// Check permissions
echo "<h3>File Permissions</h3>";
$script_directory = __DIR__;
echo "<p>Script directory: " . $script_directory . "</p>";
echo "<p>Is writable: " . (is_writable($script_directory) ? 'Yes' : 'No') . "</p>";

// Check for PHP configuration issues
echo "<h3>PHP Configuration</h3>";
$memory_limit = ini_get('memory_limit');
$max_execution_time = ini_get('max_execution_time');
echo "<p>Memory limit: " . $memory_limit . "</p>";
echo "<p>Max execution time: " . $max_execution_time . " seconds</p>";
?>