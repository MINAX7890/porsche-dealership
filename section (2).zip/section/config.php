<?php
/**
 * Database Connection Configuration
 * 
 * This file contains the configuration for connecting to the PostgreSQL database.
 */

// Database connection details from environment variables
$host = getenv('PGHOST');
$port = getenv('PGPORT');
$dbname = getenv('PGDATABASE');
$user = getenv('PGUSER');
$password = getenv('PGPASSWORD');

// Create connection string
$db_connection_string = "host=$host port=$port dbname=$dbname user=$user password=$password";

// Connect to the database
function getDBConnection() {
    global $db_connection_string;
    
    $conn = pg_connect($db_connection_string);
    
    if (!$conn) {
        error_log("Database connection failed: " . pg_last_error());
        return false;
    }
    
    return $conn;
}

// Close database connection
function closeDBConnection($conn) {
    if ($conn) {
        pg_close($conn);
    }
}

// Execute a query and return all results
function executeQuery($query, $params = []) {
    $conn = getDBConnection();
    
    if (!$conn) {
        return false;
    }
    
    $result = pg_query_params($conn, $query, $params);
    
    if (!$result) {
        error_log("Query failed: " . pg_last_error($conn));
        closeDBConnection($conn);
        return false;
    }
    
    $data = pg_fetch_all($result);
    
    closeDBConnection($conn);
    
    return $data ?: [];
}

// Execute a query and return a single row
function executeQuerySingle($query, $params = []) {
    $conn = getDBConnection();
    
    if (!$conn) {
        return false;
    }
    
    $result = pg_query_params($conn, $query, $params);
    
    if (!$result) {
        error_log("Query failed: " . pg_last_error($conn));
        closeDBConnection($conn);
        return false;
    }
    
    $row = pg_fetch_assoc($result);
    
    closeDBConnection($conn);
    
    return $row ?: null;
}

// Execute a query and return the ID of the inserted row
function executeInsert($query, $params = []) {
    $conn = getDBConnection();
    
    if (!$conn) {
        return false;
    }
    
    $result = pg_query_params($conn, $query, $params);
    
    if (!$result) {
        error_log("Insert failed: " . pg_last_error($conn));
        closeDBConnection($conn);
        return false;
    }
    
    $insertedRow = pg_fetch_assoc($result);
    $insertedId = $insertedRow ? $insertedRow['id'] : null;
    
    closeDBConnection($conn);
    
    return $insertedId;
}

// Execute an update or delete query and return number of affected rows
function executeUpdate($query, $params = []) {
    $conn = getDBConnection();
    
    if (!$conn) {
        return false;
    }
    
    $result = pg_query_params($conn, $query, $params);
    
    if (!$result) {
        error_log("Update failed: " . pg_last_error($conn));
        closeDBConnection($conn);
        return false;
    }
    
    $affectedRows = pg_affected_rows($result);
    
    closeDBConnection($conn);
    
    return $affectedRows;
}
?>