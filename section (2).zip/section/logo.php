<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 207.9 56.9">
  <path d="M41.3,56.9c-0.4-0.1-0.8-0.2-1.1-0.3c-3.5-1.1-6.9-2.1-10.4-3.2c-1.2-0.4-2.3-0.8-3.5-1c-1.4-0.2-2.8-0.2-4.2-0.3
    c-0.2,0-0.4,0-0.7,0L21,52c-0.4,0-0.8,0-1.2,0c-1.6,0-3.2,0.1-4.8,0.3c-0.7,0.1-1.4,0.3-2.1,0.5c-3.8,1.2-7.7,2.4-11.5,3.5
    c-0.4,0.1-0.9,0.2-1.3,0.4v0.3h1.4c2,0,4,0,6-0.2c1.8-0.1,3.6-0.3,5.3-0.6c3.3-0.6,6.6-1.3,9.9-1.9c0.1,0,0.2,0,0,0l0,0
    c0.5-0.1,1-0.2,1.5-0.2c0.8-0.1,1.7-0.1,2.5-0.1c0.8,0,1.7,0,2.5,0.1c0.5,0,1,0.1,1.5,0.2c3.3,0.6,6.6,1.3,9.9,1.9
    c1.8,0.3,3.5,0.5,5.3,0.6c2,0.1,4,0.1,6,0.2h1.5v-0.3C41.6,56.8,41.4,56.9,41.3,56.9z"/>
  <path d="M28,28<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 300" width="100%" height="100%" preserveAspectRatio="xMidYMid meet">
  <!-- Porsche Shield Emblem -->
  <g fill="#000">
    <!-- Shield outline -->
    <path d="M400 50c-110 0-200 40-200 100v50c0 30 90 50 200 50s200-20 200-50v-50c0-60-90-100-200-100zm0 10c100 0 180 35 180 90v40c0 20-80 40-180 40s-180-20-180-40v-40c0-55 80-90 180-90z"/>
    
    <!-- Stuttgart text at top -->
    <g transform="translate(400, 90)" text-anchor="middle">
      <text font-family="Arial, sans-serif" font-size="16" font-weight="bold">STUTTGART</text>
    </g>
    
    <!-- Porsche text -->
    <g transform="translate(400, 150)" text-anchor="middle">
      <text font-family="Arial, sans-serif" font-size="32" font-weight="bold">PORSCHE</text>
    </g>
    
    <!-- Coat of arms in center (simplified) -->
    <g transform="translate(400, 180)">
      <path d="M0 -25 L25 25 L-25 25 Z" fill="#D5001C" stroke="#000" stroke-width="2"/>
      <path d="M-10 -5 L10 -5 L10 15 L-10 15 Z" fill="#000" stroke="none"/>
    </g>
    
    <!-- Bottom text -->
    <g transform="translate(400, 220)" text-anchor="middle">
      <text font-family="Arial, sans-serif" font-size="16" font-weight="bold">EXCELLENCE</text>
    </g>
  </g>
</svg>
