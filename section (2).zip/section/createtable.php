<?php

$servername = "localhost";
$username = "root";
$password = "";/* Put your password here */
$db="test1";
$conn = new mysqli($servername, $username, $password,$db);
if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
}
$sql = "CREATE TABLE IF NOT EXISTS Myguests1 (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50)),
password VARCHAR(50) NoT NULL";
if (mysqli_query($conn, $sql)) {
  echo "Table myguests1 created successfully or already exists";
} else {
  echo "Error creating table: " . $conn->error;
}
$conn->close();
?>