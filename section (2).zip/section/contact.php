<?php
session_start();

// Include database functionality
require_once 'contact_db_functions.php';

// Check if user is authenticated or a guest
$is_logged_in = isset($_SESSION['user_id']);
$is_guest = isset($_SESSION['guest']) && $_SESSION['guest'] === true;

if (!$is_logged_in && !$is_guest) {
    header("Location: index.php");
    exit();
}

// Get inquiry type from parameters
$inquiry_type = isset($_GET['inquiry']) ? $_GET['inquiry'] : 'general';
$car_id = isset($_GET['car_id']) ? $_GET['car_id'] : '';

$form_submitted = false;
$form_success = false;
$form_message = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate form data
    $validation = validateContactForm($_POST);
    
    if (!$validation['valid']) {
        $form_message = 'Please fix the following errors: <br>' . implode('<br>', $validation['errors']);
    } else {
        // Create submission array
        $submission = [
            'name' => $_POST['name'],
            'email' => $_POST['email'],
            'phone' => $_POST['phone'],
            'inquiry_type' => $_POST['inquiry_type'],
            'message' => $_POST['message']
        ];
        
        // Add car_id if it exists
        if (!empty($_POST['car_id'])) {
            $submission['car_id'] = $_POST['car_id'];
        }
        
        // Save to database
        $result = saveContactSubmission($submission);
        $form_submitted = true;
        $form_success = $result['success'];
        $form_message = $result['message'];
    }
}

?>

<?php include 'header.php'; ?>

<main>
    <section class="contact-section py-5">
        <div class="container">
            <div class="section-header text-center mb-5">
                <h1 class="fw-bold">Contact Us</h1>
                <p class="lead">We're here to answer your questions</p>
            </div>
            
            <div class="row">
                <div class="col-lg-6 mb-4 mb-lg-0">
                    <?php if ($form_submitted && $form_success): ?>
                    <div class="card mb-4">
                        <div class="card-body text-center p-5">
                            <div class="mb-4">
                                <i class="fas fa-check-circle text-success" style="font-size: 3rem;"></i>
                            </div>
                            <h2 class="fw-bold mb-3">Thank You!</h2>
                            <p class="lead mb-4"><?php echo htmlspecialchars($form_message); ?> We'll respond to your inquiry as soon as possible.</p>
                            <a href="home.php" class="btn btn-primary">Return to Home</a>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="card">
                        <div class="card-body p-4">
                            <h3 class="fw-bold mb-4">Send us a Message</h3>
                            
                            <?php if ($form_message): ?>
                            <div class="alert <?php echo $form_success ? 'alert-success' : 'alert-danger'; ?> mb-4">
                                <?php echo $form_message; ?>
                            </div>
                            <?php endif; ?>
                            
                            <form method="POST" action="contact.php<?php echo $inquiry_type ? '?inquiry=' . htmlspecialchars($inquiry_type) . ($car_id ? '&car_id=' . htmlspecialchars($car_id) : '') : ''; ?>">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Your Name*</label>
                                    <input type="text" class="form-control" id="name" name="name" value="<?php echo $is_logged_in ? htmlspecialchars($_SESSION['username']) : ''; ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email Address*</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo $is_logged_in ? htmlspecialchars($_SESSION['email']) : ''; ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Phone Number*</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="inquiry_type" class="form-label">Inquiry Type</label>
                                    <select class="form-select" id="inquiry_type" name="inquiry_type">
                                        <option value="general" <?php echo $inquiry_type == '' || $inquiry_type == 'general' ? 'selected' : ''; ?>>General Inquiry</option>
                                        <option value="buy" <?php echo $inquiry_type == 'buy' ? 'selected' : ''; ?>>Purchase Inquiry</option>
                                        <option value="sell" <?php echo $inquiry_type == 'sell' ? 'selected' : ''; ?>>Selling Inquiry</option>
                                        <option value="rent" <?php echo $inquiry_type == 'rent' ? 'selected' : ''; ?>>Rental Inquiry</option>
                                        <option value="service" <?php echo $inquiry_type == 'service' ? 'selected' : ''; ?>>Service Inquiry</option>
                                    </select>
                                </div>
                                
                                <?php if ($car_id): ?>
                                <input type="hidden" name="car_id" value="<?php echo htmlspecialchars($car_id); ?>">
                                <?php endif; ?>
                                
                                <div class="mb-4">
                                    <label for="message" class="form-label">Your Message*</label>
                                    <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary btn-lg">Send Message</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="col-lg-6">
                    <div class="contact-info mb-4">
                        <div class="card mb-4">
                            <div class="card-body p-4">
                                <h3 class="fw-bold mb-4">Contact Information</h3>
                                
                                <div class="contact-item mb-4">
                                    <div class="d-flex">
                                        <div class="contact-icon me-3">
                                            <i class="fas fa-map-marker-alt"></i>
                                        </div>
                                        <div>
                                            <h5 class="fw-bold">Address</h5>
                                            <p>123 Performance Drive<br>Stuttgart Business Park<br>Munich, Germany 80335</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="contact-item mb-4">
                                    <div class="d-flex">
                                        <div class="contact-icon me-3">
                                            <i class="fas fa-phone-alt"></i>
                                        </div>
                                        <div>
                                            <h5 class="fw-bold">Phone</h5>
                                            <p>+49 (0) 89 1234 5678</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="contact-item mb-4">
                                    <div class="d-flex">
                                        <div class="contact-icon me-3">
                                            <i class="fas fa-envelope"></i>
                                        </div>
                                        <div>
                                            <h5 class="fw-bold">Email</h5>
                                            <p>info@porschedealership.com</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="contact-item">
                                    <div class="d-flex">
                                        <div class="contact-icon me-3">
                                            <i class="fas fa-clock"></i>
                                        </div>
                                        <div>
                                            <h5 class="fw-bold">Opening Hours</h5>
                                            <p>Monday - Friday: 9:00 AM - 7:00 PM<br>
                                            Saturday: 10:00 AM - 6:00 PM<br>
                                            Sunday: Closed</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="map-container">
                        <div class="card">
                            <div class="card-body p-0">
                                <div class="map-placeholder">
                                    <!-- In a real application, this would be a Google Map or similar -->
                                    <div class="map-overlay d-flex align-items-center justify-content-center">
                                        <div class="text-center p-4">
                                            <i class="fas fa-map-marked-alt fa-3x mb-3"></i>
                                            <h5 class="fw-bold">Find Us on the Map</h5>
                                            <p class="mb-0">Interactive map would appear here in a real application</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include 'footer.php'; ?>