<?php
/**
 * Data Storage Functions
 * 
 * This file provides functions for accessing car and testimonial data.
 * In a real application, these would likely come from a database.
 * For this example, we'll use static arrays.
 */

/**
 * Get featured cars for the homepage
 * 
 * @return array Array of featured cars
 */
function getFeaturedCars() {
    $cars = getCarsForSale();
    
    // For simplicity, just return the first 3 cars
    return array_slice($cars, 0, 3);
}

/**
 * Get all cars available for sale
 * 
 * @return array Array of cars for sale
 */
function getCarsForSale() {
    // In a real application, this would come from a database
    // Using static data for this example
    return [
        [
            'id' => 1,
            'model' => 'Porsche 911 Carrera S',
            'year' => 2023,
            'price' => 130000,
            'price_formatted' => '€130,000',
            'color' => 'GT Silver Metallic',
            'mileage' => 0,
            'engine' => '3.0L Twin-Turbo Flat-6',
            'transmission' => '8-Speed PDK',
            'image_url' => 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'short_description' => 'Brand new Porsche 911 Carrera S with premium package and sport chrono.',
            'description' => 'Experience the iconic Porsche 911 in its latest iteration. This brand new Carrera S model features the premium package, sport chrono, and various comfort and performance enhancements. The 3.0L Twin-Turbo Flat-6 engine delivers exhilarating performance with sophisticated handling.',
            'features' => [
                'Sport Chrono Package',
                'Premium Package',
                'BOSE Surround Sound System',
                'Adaptive Sports Seats Plus (18-way)',
                'LED Matrix Headlights',
                'Sport Exhaust System',
                'Porsche Dynamic Chassis Control',
                'Rear Axle Steering',
                'Lane Change Assist',
                'Surround View Camera'
            ]
        ],
        [
            'id' => 2,
            'model' => 'Porsche Taycan Turbo S',
            'year' => 2023,
            'price' => 185000,
            'price_formatted' => '€185,000',
            'color' => 'Gentian Blue Metallic',
            'mileage' => 1500,
            'engine' => 'Dual Electric Motors',
            'transmission' => '2-Speed Automatic',
            'image_url' => 'https://images.unsplash.com/photo-1617037711236-47857bcdf8e9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'short_description' => 'Nearly new Porsche Taycan Turbo S with all available options.',
            'description' => 'This nearly new Porsche Taycan Turbo S represents the pinnacle of electric performance. With dual electric motors producing up to 750 hp with overboost, this vehicle accelerates from 0-100 km/h in just 2.8 seconds. Features include Porsche Electric Sport Sound, performance battery plus, and a full suite of driver assistance systems.',
            'features' => [
                'Performance Battery Plus (93.4 kWh)',
                'Porsche Electric Sport Sound',
                'Adaptive Air Suspension',
                'Porsche Ceramic Composite Brakes',
                'Head-Up Display',
                'Burmester High-End Surround Sound',
                'Night Vision Assist',
                'Passenger Display',
                'Four-Zone Climate Control',
                'Massage Seats'
            ]
        ],
        [
            'id' => 3,
            'model' => 'Porsche Macan GTS',
            'year' => 2022,
            'price' => 85000,
            'price_formatted' => '€85,000',
            'color' => 'Carmine Red',
            'mileage' => 8500,
            'engine' => '2.9L Twin-Turbo V6',
            'transmission' => '7-Speed PDK',
            'image_url' => 'https://images.unsplash.com/photo-1580274455191-1c62238fa333?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'short_description' => 'Porsche Macan GTS with premium options and low mileage.',
            'description' => 'This Porsche Macan GTS combines sports car performance with SUV practicality. The 2.9L Twin-Turbo V6 delivers 375 hp, while the adaptive air suspension with GTS-specific tuning provides exceptional handling characteristics. Finished in striking Carmine Red with black accents and featuring a plethora of optional extras.',
            'features' => [
                'GTS Sport Package',
                'Adaptive Air Suspension',
                'Sport Chrono Package',
                'Premium Package Plus',
                '21-inch RS Spyder Design Wheels',
                'Heated and Ventilated Front Seats',
                'BOSE Surround Sound System',
                'LED Headlights with PDLS Plus',
                'Panoramic Roof System',
                'Adaptive Cruise Control'
            ]
        ],
        [
            'id' => 4,
            'model' => 'Porsche 718 Cayman GT4',
            'year' => 2021,
            'price' => 115000,
            'price_formatted' => '€115,000',
            'color' => 'Racing Yellow',
            'mileage' => 12000,
            'engine' => '4.0L Flat-6',
            'transmission' => '6-Speed Manual',
            'image_url' => 'https://images.unsplash.com/photo-1611651338412-8403fa6e3599?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'short_description' => 'Porsche 718 Cayman GT4 with manual transmission and track-focused setup.',
            'description' => 'This Porsche 718 Cayman GT4 represents the purist\'s choice with its naturally aspirated 4.0L flat-six engine and engaging 6-speed manual transmission. Track-focused yet completely road legal, this GT4 delivers an incredible driving experience with its aerodynamic package producing 50% more downforce than the previous generation.',
            'features' => [
                'Clubsport Package',
                'Carbon Ceramic Brakes',
                'Full Bucket Seats',
                'Fire Extinguisher',
                'Sport Chrono Package',
                'BOSE Surround Sound',
                'Carbon Fiber Interior Package',
                'LED Headlights with PDLS',
                '20-inch GT4 Wheels',
                'Smoking Package'
            ]
        ],
        [
            'id' => 5,
            'model' => 'Porsche Panamera Turbo S E-Hybrid',
            'year' => 2022,
            'price' => 175000,
            'price_formatted' => '€175,000',
            'color' => 'Volcano Grey Metallic',
            'mileage' => 9500,
            'engine' => '4.0L Twin-Turbo V8 + Electric Motor',
            'transmission' => '8-Speed PDK',
            'image_url' => 'https://images.unsplash.com/photo-1618093500185-c950512af479?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'short_description' => 'Porsche Panamera Turbo S E-Hybrid with Executive package and premium options.',
            'description' => 'This Porsche Panamera Turbo S E-Hybrid combines ultimate luxury with staggering performance. The hybrid powertrain produces a combined 690 hp, launching this four-door sports car from 0-100 km/h in just 3.2 seconds. The Executive package adds extended wheelbase for increased rear passenger comfort.',
            'features' => [
                'Executive Package (Extended Wheelbase)',
                'Porsche Dynamic Chassis Control',
                'Burmester High-End 3D Surround Sound',
                'Rear Seat Entertainment',
                'Night Vision Assist',
                'Four-Zone Climate Control',
                'Massage Function (All Seats)',
                'Panoramic Roof',
                'Ambient Lighting Package',
                'Porsche InnoDrive with Adaptive Cruise Control'
            ]
        ],
        [
            'id' => 6,
            'model' => 'Porsche Cayenne Turbo GT',
            'year' => 2023,
            'price' => 195000,
            'price_formatted' => '€195,000',
            'color' => 'Arctic Grey',
            'mileage' => 3200,
            'engine' => '4.0L Twin-Turbo V8',
            'transmission' => '8-Speed Tiptronic S',
            'image_url' => 'https://images.unsplash.com/photo-1519245642385-b5ae0a14860a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'short_description' => 'Porsche Cayenne Turbo GT with lightweight package and full ceramic brakes.',
            'description' => 'The Porsche Cayenne Turbo GT is the pinnacle of performance SUVs. With 631 hp from its specially tuned 4.0L twin-turbo V8, it conquered the Nürburgring in record time. This example features the lightweight package, ceramic composite brakes, and a full range of premium options for both performance and luxury.',
            'features' => [
                'Lightweight Package',
                'Porsche Ceramic Composite Brakes',
                'Carbon Fiber Roof',
                'Adaptive Sports Seats with Memory',
                'Rear-Axle Steering',
                'Porsche Torque Vectoring Plus',
                'Carbon Fiber Interior Package',
                'BOSE Surround Sound System',
                'Head-Up Display',
                'Adaptive Cruise Control'
            ]
        ],
        // New cars added from the second file
        [
            'id' => 7,
            'model' => 'Porsche 718 Cayman GT4 RS',
            'year' => 2023,
            'price' => 149100,
            'price_formatted' => '€149,100',
            'color' => 'Python Green',
            'mileage' => 1200,
            'engine' => '4.0L Naturally Aspirated Flat-Six',
            'transmission' => '7-Speed PDK',
            'image_url' => 'images/cars/porsche-cayman.jpg',
            'short_description' => 'Track-focused mid-engine sports car with motorsport technology',
            'description' => 'The all-electric Porsche Taycan Turbo S delivers breathtaking performance with zero emissions. Featuring 750 hp overboost power, the Taycan accelerates from 0-60 mph in just 2.6 seconds. This particular model includes the Performance Battery Plus, Porsche Electric Sport Sound, and the complete Premium Package. The interior showcases sustainable materials and cutting-edge technology with the curved driver display.',
            'features' => [
                'Performance Battery Plus',
                'Porsche Torque Vectoring Plus',
                'Porsche Ceramic Composite Brakes',
                'Burmester® 3D High-End Surround Sound',
                'Passenger Display',
                '21-inch Mission E Design Wheels'
            ]
        ],
        [
            'id' => 8,
            'model' => 'Porsche 911 GT3 RS',
            'year' => 2023,
            'price' => 235200,
            'price_formatted' => '€235,200',
            'color' => 'Shark Blue',
            'mileage' => 900,
            'engine' => '4.0L Naturally Aspirated Flat-Six',
            'transmission' => '7-Speed PDK',
            'image_url' => 'images/cars/porsche-gt3rs.jpg',
            'short_description' => 'Track-focused 911 with racing aerodynamics and motorsport technology',
            'description' => 'The 911 GT3 RS is the ultimate track-focused 911. With F1-inspired aerodynamics including the imposing rear wing and DRS system, this model generates more downforce than any previous production Porsche. The naturally aspirated 4.0-liter engine produces 518 hp and revs to 9,000 rpm. Every aspect of this car has been optimized for maximum track performance while maintaining road legality.',
            'features' => [
                'Clubsport Package',
                'Weissach Package',
                'Magnesium Wheels',
                'Carbon Ceramic Brakes',
                'Carbon Fiber Full Bucket Seats',
                'Carbon Fiber Interior Package'
            ]
        ],
        [
            'id' => 9,
            'model' => 'Porsche Boxster Spyder',
            'year' => 2023,
            'price' => 106800,
            'price_formatted' => '€106,800',
            'color' => 'Guards Red',
            'mileage' => 1800,
            'engine' => '4.0L Naturally Aspirated Flat-Six',
            'transmission' => '6-Speed Manual',
            'image_url' => 'images/cars/porsche-boxster.jpg',
            'short_description' => 'Purist roadster with mid-engine layout and naturally aspirated power',
            'description' => 'The Porsche Boxster Spyder represents the purest open-top driving experience in the 718 lineup. With its naturally aspirated 4.0L flat-six engine, manual transmission, and lightweight construction, it delivers an authentic sports car experience. The distinctive appearance with the streamlined silhouette and manual soft top emphasizes its motorsport heritage and driver-focused philosophy.',
            'features' => [
                'Sports Exhaust System',
                'Sport Chrono Package',
                'PASM Sport Suspension',
                'Carbon Fiber Bucket Seats',
                'Bose Surround Sound System',
                '20-inch GT Silver Wheels'
            ]
        ],
        [
            'id' => 10,
            'model' => 'Porsche 911 Targa 4 GTS',
            'year' => 2023,
            'price' => 168200,
            'price_formatted' => '€168,200',
            'color' => 'Agate Grey Metallic',
            'mileage' => 2400,
            'engine' => '3.0L Twin-Turbo Flat-Six',
            'transmission' => '8-Speed PDK',
            'image_url' => 'images/cars/porsche-targa.jpg',
            'short_description' => 'Open-top 911 with iconic Targa bar and enhanced GTS performance',
            'description' => 'The Porsche 911 Targa 4 GTS combines the unique Targa roof concept with enhanced GTS performance. The power-operated glass roof offers an open-air experience while maintaining the distinctive 911 silhouette. This model features all-wheel drive, PASM sport suspension, and the powerful GTS-tuned engine for outstanding performance. The interior showcases Race-Tex upholstery, carbon fiber trim, and the latest PCM system.',
            'features' => [
                'GTS Power Kit',
                'All-Wheel Drive',
                'Sport Chrono Package',
                'PASM Sport Suspension',
                'Front Axle Lift System',
                'Bose Surround Sound System'
            ]
        ],
        [
            'id' => 11,
            'model' => 'Porsche Taycan Cross Turismo 4S',
            'year' => 2023,
            'price' => 125600,
            'price_formatted' => '€125,600',
            'color' => 'Mamba Green Metallic',
            'mileage' => 3800,
            'engine' => 'Dual Electric Motors (482 hp)',
            'transmission' => '2-Speed Automatic',
            'image_url' => 'images/cars/porsche-cross-turismo.jpg',
            'short_description' => 'All-electric cross utility vehicle with enhanced practicality',
            'description' => 'The Taycan Cross Turismo 4S combines electric performance with versatile practicality. This wagon-style variant of the Taycan features increased ground clearance, roof rails, and unique body cladding for light off-road capability. With all-wheel drive, air suspension, and the Performance Battery Plus, it delivers impressive range and performance. The panoramic glass roof and spacious interior make it ideal for both daily use and adventure travel.',
            'features' => [
                'Performance Battery Plus',
                'Adaptive Air Suspension',
                'Panoramic Glass Roof',
                'Off-Road Design Package',
                'Premium Package Plus',
                '20-inch Taycan Turbo Aero Wheels'
            ]
        ],
        [
            'id' => 12,
            'model' => 'Porsche 918 Spyder',
            'year' => 2015,
            'price' => 1850000,
            'price_formatted' => '€1,850,000',
            'color' => 'Liquid Metal Chrome Blue',
            'mileage' => 2100,
            'engine' => '4.6L V8 + Dual Electric Motors (887 hp)',
            'transmission' => '7-Speed PDK',
            'image_url' => 'images/cars/porsche-918.jpg',
            'short_description' => 'Limited-production hybrid hypercar with Weissach Package',
            'description' => 'The legendary Porsche 918 Spyder represents one of the most advanced hypercars ever produced. This collector-grade example features the rare Weissach Package, which reduces weight by 41 kg through carbon fiber components and magnesium wheels. The hybrid powertrain combines a high-revving V8 engine with two electric motors for a combined 887 hp, enabling 0-60 mph in just 2.5 seconds. The immaculate condition and low mileage make this a truly exceptional investment opportunity.',
            'features' => [
                'Weissach Package',
                'Liquid Metal Chrome Blue Paint',
                'Magnesium Wheels',
                'Front Axle Lift System',
                'Burmester High-End Surround Sound',
                'Carbon Fiber Interior Package'
            ]
        ]
    ];
}

/**
 * Get cars available for rent
 * 
 * @return array Array of rental cars
 */
function getCarsForRent() {
    return [
        [
            'id' => 101,
            'model' => 'Porsche 911 Carrera 4S',
            'year' => 2023,
            'rental_rate' => 500,
            'rental_rate_formatted' => '€500',
            'color' => 'Agate Grey Metallic',
            'engine' => '3.0L Twin-Turbo Flat-6',
            'transmission' => '8-Speed PDK',
            'image_url' => 'https://images.unsplash.com/photo-1580274455191-1c62238fa333?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'short_description' => 'Experience the legendary 911 with all-wheel drive capability.',
            'description' => 'Enjoy the perfect balance of performance and control with the 911 Carrera 4S. Its all-wheel drive system provides exceptional grip in all weather conditions, while the 3.0L twin-turbo engine delivers thrilling acceleration. This vehicle comes equipped with Sport Chrono Package and PASM sport suspension.',
            'features' => [
                'Sport Chrono Package',
                'PASM Sport Suspension',
                'Sport Exhaust System',
                'LED Matrix Headlights',
                'BOSE Surround Sound System',
                'Front and Rear Parking Sensors',
                'Reversing Camera',
                'Heated Sports Seats Plus',
                'Apple CarPlay',
                'Lane Change Assist'
            ]
        ],
        [
            'id' => 102,
            'model' => 'Porsche Taycan 4S',
            'year' => 2023,
            'rental_rate' => 450,
            'rental_rate_formatted' => '€450',
            'color' => 'Frozen Blue Metallic',
            'engine' => 'Dual Electric Motors',
            'transmission' => '2-Speed Automatic',
            'image_url' => 'https://images.unsplash.com/photo-1617037711236-47857bcdf8e9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'short_description' => 'Experience electric performance with the Porsche Taycan 4S.',
            'description' => 'Discover the future of sports cars with the Porsche Taycan 4S. This all-electric Porsche delivers instant acceleration and remarkable handling, combining sustainable mobility with the driving experience you expect from Porsche. Features include the Performance Battery Plus for extended range and impressive charging capabilities.',
            'features' => [
                'Performance Battery Plus (93.4 kWh)',
                'Adaptive Air Suspension',
                'Head-Up Display',
                'BOSE Surround Sound System',
                'Porsche Electric Sport Sound',
                'Comfort Access',
                'Four-Zone Climate Control',
                'Adaptive Sports Seats',
                'Mobile Charger Connect',
                'Lane Keep Assist with Traffic Sign Recognition'
            ]
        ],
        [
            'id' => 103,
            'model' => 'Porsche 718 Boxster GTS 4.0',
            'year' => 2022,
            'rental_rate' => 400,
            'rental_rate_formatted' => '€400',
            'color' => 'Guards Red',
            'engine' => '4.0L Flat-6',
            'transmission' => '6-Speed Manual',
            'image_url' => 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'short_description' => 'Open-top driving pleasure with naturally aspirated power.',
            'description' => 'Experience the purest form of driving pleasure with the 718 Boxster GTS 4.0. Its naturally aspirated 4.0L flat-six engine produces a spine-tingling soundtrack, especially with the roof down. The mid-engine layout provides perfect balance and handling precision, making every drive a special occasion.',
            'features' => [
                'Sport Chrono Package',
                'PASM Sport Suspension (20mm Lower)',
                'Sport Exhaust System',
                'Heated and Ventilated Seats',
                'BOSE Surround Sound System',
                'Wind Deflector',
                'Navigation System',
                'Apple CarPlay',
                'LED Headlights with PDLS',
                'Parking Sensors with Reversing Camera'
            ]
        ],
        [
            'id' => 104,
            'model' => 'Porsche Macan Turbo',
            'year' => 2022,
            'rental_rate' => 350,
            'rental_rate_formatted' => '€350',
            'color' => 'Sapphire Blue Metallic',
            'engine' => '2.9L Twin-Turbo V6',
            'transmission' => '7-Speed PDK',
            'image_url' => 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'short_description' => 'Performance SUV for all occasions, from city driving to long trips.',
            'description' => 'The Porsche Macan Turbo offers sports car performance with SUV practicality. Perfect for both city driving and longer journeys, it combines comfort, space, and thrilling acceleration. This vehicle features air suspension, premium audio, and all the luxuries you would expect from a Porsche.',
            'features' => [
                'Air Suspension with Self-Leveling',
                'Panoramic Roof System',
                'BOSE Surround Sound System',
                'Heated and Ventilated Front Seats',
                'Heated Steering Wheel',
                'Navigation System with Real-time Traffic',
                'Apple CarPlay and Android Auto',
                'Lane Keep Assist',
                'Adaptive Cruise Control',
                'Power Tailgate'
            ]
        ]
    ];
}

/**
 * Get user testimonials
 * 
 * @return array Array of testimonials
 */
function getTestimonials() {
    return [
        [
            'name' => 'Michael Schmidt',
            'location' => 'Berlin, Germany',
            'rating' => 5,
            'text' => 'Exceptional service from start to finish. The sales team was knowledgeable and helped me find the perfect 911 for my needs. Couldn\'t be happier with my purchase!'
        ],
        [
            'name' => 'Sophia Müller',
            'location' => 'Munich, Germany',
            'rating' => 5,
            'text' => 'I rented a Porsche Taycan for a weekend trip and was blown away by both the car and the service. The rental process was smooth, and the car exceeded all expectations.'
        ],
        [
            'name' => 'Thomas Weber',
            'location' => 'Frankfurt, Germany',
            'rating' => 4,
            'text' => 'Sold my Cayenne through this dealership and got a very fair price. The process was straightforward and quick. Would definitely use their services again in the future.'
        ]
    ];
}
?>