<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "<h2>Database Setup Script</h2>";

// Create users table
$sql_users = "CREATE TABLE IF NOT EXISTS users (
    id INT(11) NOT NULL AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY username (username)
)";

if ($conn->query($sql_users) === TRUE) {
    echo "<p>Users table created successfully or already exists.</p>";
} else {
    echo "<p>Error creating users table: " . $conn->error . "</p>";
}

// Create cars table if it doesn't exist
$sql_cars = "CREATE TABLE IF NOT EXISTS cars (
    id INT(11) NOT NULL AUTO_INCREMENT,
    brand VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    year INT(4),
    color VARCHAR(50),
    registration_number VARCHAR(20),
    status VARCHAR(20) DEFAULT 'available',
    PRIMARY KEY (id)
)";

if ($conn->query($sql_cars) === TRUE) {
    echo "<p>Cars table created successfully or already exists.</p>";
} else {
    echo "<p>Error creating cars table: " . $conn->error . "</p>";
}

// Create vehicles table if it doesn't exist
$sql_vehicles = "CREATE TABLE IF NOT EXISTS vehicles (
    id INT(11) NOT NULL AUTO_INCREMENT,
    type VARCHAR(50) NOT NULL,
    brand VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    year INT(4),
    license_plate VARCHAR(20),
    status VARCHAR(20) DEFAULT 'available',
    PRIMARY KEY (id)
)";

if ($conn->query($sql_vehicles) === TRUE) {
    echo "<p>Vehicles table created successfully or already exists.</p>";
} else {
    echo "<p>Error creating vehicles table: " . $conn->error . "</p>";
}

// Create contact_submissions table if it doesn't exist
$sql_contact = "CREATE TABLE IF NOT EXISTS contact_submissions (
    id INT(11) NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    subject VARCHAR(255),
    message TEXT NOT NULL,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'unread',
    PRIMARY KEY (id)
)";

if ($conn->query($sql_contact) === TRUE) {
    echo "<p>Contact submissions table created successfully or already exists.</p>";
} else {
    echo "<p>Error creating contact_submissions table: " . $conn->error . "</p>";
}

// Create myguests table if it doesn't exist
$sql_myguests = "CREATE TABLE IF NOT EXISTS myguests (
    id INT(11) NOT NULL AUTO_INCREMENT,
    firstname VARCHAR(50) NOT NULL,
    lastname VARCHAR(50) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    registration_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
)";

if ($conn->query($sql_myguests) === TRUE) {
    echo "<p>Myguests table created successfully or already exists.</p>";
} else {
    echo "<p>Error creating myguests table: " . $conn->error . "</p>";
}

// Create rental_bookings table if it doesn't exist
$sql_bookings = "CREATE TABLE IF NOT EXISTS rental_bookings (
    id INT(11) NOT NULL AUTO_INCREMENT,
    vehicle_id INT(11) NOT NULL,
    guest_id INT(11) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_price DECIMAL(10,2),
    status VARCHAR(20) DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
)";

if ($conn->query($sql_bookings) === TRUE) {
    echo "<p>Rental bookings table created successfully or already exists.</p>";
} else {
    echo "<p>Error creating rental_bookings table: " . $conn->error . "</p>";
}

// Create myguests1 table if it doesn't exist
$sql_myguests1 = "CREATE TABLE IF NOT EXISTS myguests1 (
    id INT(11) NOT NULL AUTO_INCREMENT,
    firstname VARCHAR(50) NOT NULL,
    lastname VARCHAR(50) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    registration_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
)";

if ($conn->query($sql_myguests1) === TRUE) {
    echo "<p>Myguests1 table created successfully or already exists.</p>";
} else {
    echo "<p>Error creating myguests1 table: " . $conn->error . "</p>";
}

// Check if admin user exists
$check_admin = "SELECT COUNT(*) as count FROM users WHERE username = 'admin'";
$result = $conn->query($check_admin);

if ($result) {
    $row = $result->fetch_assoc();
    
    // Create admin user if it doesn't exist
    if ($row['count'] == 0) {
        // Admin credentials
        $admin_username = "admin";
        $admin_password = "admin123"; // Plain text password
        $hashed_password = password_hash($admin_password, PASSWORD_DEFAULT); // Hash the password
        
        // Insert admin user
        $insert_admin = "INSERT INTO users (username, password) VALUES (?, ?)";
        $stmt = $conn->prepare($insert_admin);
        $stmt->bind_param("ss", $admin_username, $hashed_password);
        
        if ($stmt->execute()) {
            echo "<div style='background-color: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin-top: 20px;'>";
            echo "<h3>Admin User Created Successfully!</h3>";
            echo "<p><strong>Username:</strong> admin</p>";
            echo "<p><strong>Password:</strong> admin123</p>";
            echo "<p>Please use these credentials to log in to the admin dashboard.</p>";
            echo "</div>";
        } else {
            echo "<p>Error creating admin user: " . $stmt->error . "</p>";
        }
        
        $stmt->close();
    } else {
        echo "<p>Admin user already exists.</p>";
    }
} else {
    echo "<p>Error checking admin user: " . $conn->error . "</p>";
}

$conn->close();

echo "<p>Setup complete! <a href='login.php'>Go to login page</a></p>";
?>