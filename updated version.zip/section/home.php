<?php
session_start();

// Check if user is guest
if (isset($_GET['guest']) && $_GET['guest'] === 'true') {
    $_SESSION['guest'] = true;
}

// Determine if user is logged in or a guest
$is_logged_in = isset($_SESSION['user_id']);
$is_guest = isset($_SESSION['guest']) && $_SESSION['guest'] === true;

// If neither logged in nor a guest, redirect to welcome page
if (!$is_logged_in && !$is_guest) {
    header("Location: index.php");
    exit();
}

// Get username if logged in
$username = $is_logged_in ? $_SESSION['username'] : 'Guest';

require_once 'storage.php';
// Get featured cars
$featured_cars = [];
$featured_query = "SELECT id, model, year, price, short_description, image_url 
                  FROM cars 
                  WHERE featured = 1 
                  ORDER BY RAND() 
                  LIMIT 3";

// Check if connection is established before running query
if (isset($conn) && $conn) {
    $featured_result = mysqli_query($conn, $featured_query);
    
    if ($featured_result) {
        // Format the data for display
        while ($car = mysqli_fetch_assoc($featured_result)) {
            // Format the price with euro symbol
            $car['price_formatted'] = '€' . number_format($car['price'], 0, ',', '.');
            $featured_cars[] = $car;
        }
    } else {
        // Handle query error
        $featured_cars = [];
        error_log("Error fetching featured cars: " . mysqli_error($conn));
    }
} else {
    // If no connection, use function from storage.php as fallback
    $featured_cars = getFeaturedCars();
}

// Get testimonials
$testimonials = getTestimonials();

// Define image URL path
$img_url = '/assets/images/cars';

include 'header.php';
?>
<!-- Custom CSS -->
<style>
    body {
        font-family: 'Montserrat', sans-serif;
        color: #212529;
        line-height: 1.6;
    }
    
    h1, h2, h3, h4, h5, h6 {
        font-weight: 300;
        letter-spacing: 0.5px;
    }
    
    .btn {
        border-radius: 0;
        padding: 12px 30px;
        text-transform: uppercase;
        font-size: 13px;
        letter-spacing: 2px;
        transition: all 0.3s ease;
        font-weight: 400;
    }
    
    .btn-primary {
        background-color: #000;
        border-color: #000;
        position: relative;
        overflow: hidden;
    }
    
    .btn-primary:after {
        content: '';
        position: absolute;
        width: 0;
        height: 100%;
        top: 0;
        left: 0;
        background-color: rgba(255,255,255,0.1);
        transition: all 0.3s ease;
    }
    
    .btn-primary:hover {
        background-color: #0a0a0a;
        border-color: #0a0a0a;
    }
    
    .btn-primary:hover:after {
        width: 100%;
    }
    
    .btn-outline-dark {
        border-color: #000;
        color: #000;
        border-width: 1px;
    }
    
    .btn-outline-dark:hover {
        background-color: #000;
        color: #fff;
    }
    
    /* Hero Section */
    .hero-section {
        position: relative;
        background-color: #f8f9fa;
        padding: 120px 0;
        overflow: hidden;
    }
    
    .hero-section:after {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 50%;
        height: 100%;
        background-image: url('assets/images/hero-porsche.jpg');
        background-size: cover;
        background-position: center;
        z-index: 1;
    }
    
    .hero-content {
        position: relative;
        z-index: 2;
    }
    
    .hero-section h1 {
        font-size: 3.5rem;
        line-height: 1.2;
        margin-bottom: 1.5rem;
    }
    
    /* Cards */
    .card {
        border: none;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        transition: all 0.3s ease;
        border-radius: 0;
        background-color: #fafafa;
    }
    
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }
    
    .card-body {
        padding: 2rem;
    }
    
    .card-title {
        font-weight: 300;
        letter-spacing: 1px;
        text-transform: uppercase;
        margin-bottom: 1rem;
    }
    
    .car-img-top {
        height: 240px;
        background-size: cover;
        background-position: center;
        position: relative;
    }
    
    .car-img-top:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 30%;
        background: linear-gradient(to top, rgba(0,0,0,0.3), transparent);
    }
    
    /* Sections */
    section {
        padding: 80px 0;
    }
    
    .section-header {
        margin-bottom: 40px;
    }
    
    .section-header h2 {
        position: relative;
        display: inline-block;
        margin-bottom: 15px;
    }
    
    .section-header h2:after {
        content: '';
        position: absolute;
        left: 0;
        bottom: -10px;
        width: 50px;
        height: 2px;
        background-color: #d5a353;
    }
    
    .text-center .section-header h2:after {
        left: 50%;
        transform: translateX(-50%);
    }
    
    /* CTA Section */
    .cta-section {
        background-color: #000;
        color: #fff;
        padding: 80px 0;
    }
    
    .cta-section .btn-outline-dark {
        border-color: #fff;
        color: #fff;
    }
    
    .cta-section .btn-outline-dark:hover {
        background-color: #fff;
        color: #000;
    }
    
    /* Heritage Section */
    .heritage-section {
        background-color: #0b0c0e;
        padding: 100px 0;
        color: #fff;
        position: relative;
    }
    
    .heritage-section:before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-image: linear-gradient(to right, rgba(11,12,14,0.9), rgba(11,12,14,0.7));
        z-index: 1;
    }
    
    .heritage-content {
        position: relative;
        z-index: 2;
    }
    
    .heritage-content h2 {
        font-size: 2.5rem;
        margin-bottom: 20px;
        position: relative;
        font-weight: 200;
        letter-spacing: 2px;
    }
    
    .heritage-content h2:after {
        content: '';
        position: absolute;
        left: 0;
        bottom: -10px;
        width: 50px;
        height: 1px;
        background-color: #d5a353;
    }
    
    .heritage-image {
        position: relative;
        z-index: 2;
        overflow: hidden;
    }
    
    /* Services Cards Enhancement */
    .service-card {
        height: 100%;
        transition: all 0.3s ease;
        border-left: 1px solid #e0e0e0;
        background-color: #fff;
    }
    
    .service-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }
    
    .service-icon {
        width: 60px;
        height: 1px;
        background-color: #d5a353;
        margin-bottom: 20px;
    }
    
    /* Testimonials Enhancement */
    .testimonial-card {
        position: relative;
        padding: 30px 40px;
        background-color: #fff;
        border-left: 2px solid #d5a353;
    }
    
    .testimonial-card:before {
        content: '';
        width: 20px;
        height: 1px;
        background-color: #d5a353;
        position: absolute;
        top: 30px;
        left: -10px;
    }
    
    /* Buttons Enhancement */
    .btn-link {
        position: relative;
        padding-left: 0;
        padding-right: 0;
        color: #000;
        border-bottom: 1px solid transparent;
        text-decoration: none;
        letter-spacing: 1px;
        font-size: 12px;
    }
    
    .btn-link:hover {
        color: #000;
        border-bottom: 1px solid #d5a353;
    }
</style>

<main>
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="hero-content">
                        <h1>Excellence in<br>Every Detail</h1>
                        <p class="lead mb-4">Experience the pinnacle of automotive engineering and luxury with our curated collection of Porsche vehicles.</p>
                        <div>
                            <a href="buy.php" class="btn btn-primary me-3">Explore Models</a>
                            <a href="contact.php" class="btn btn-outline-dark">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Heritage Section -->
    <section class="heritage-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0">
                    <div class="heritage-image">
                        <img src="Porsche-911-PNG-Transparent.png" alt="Porsche Heritage" class="img-fluid">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="heritage-content">
                        <h2>Our Heritage</h2>
                        <p class="lead mb-4">A legacy of luxury, performance, and uncompromising excellence.</p>
                        <p>Our dealership embodies the Porsche philosophy—blending tradition with innovation. We provide an exceptional experience for discerning clients who demand perfection in every detail.</p>
                        <p>With a curated selection of the finest vehicles and a team of passionate experts, we offer much more than automobiles—we offer an entrance into the exclusive world of Porsche.</p>
                        <div class="mt-4">
                            <a href="buy.php" class="btn btn-primary">Discover More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section class="bg-light">
        <div class="container">
            <div class="section-header text-center">
                <h2>Bespoke Services</h2>
                <p class="lead">Tailored solutions for the discerning Porsche enthusiast</p>
            </div>
            
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card service-card h-100 p-4">
                        <div class="card-body">
                            <div class="service-icon mb-4"></div>
                            <i class="fas fa-car fa-lg text-dark mb-3"></i>
                            <h5 class="card-title">Acquisition</h5>
                            <p class="card-text">Find your perfect Porsche with our personalized procurement service. From the latest models to rare classics, we locate vehicles that match your exact specifications.</p>
                            <a href="buy.php" class="btn btn-link p-0 mt-3">Explore Options</a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="card service-card h-100 p-4">
                        <div class="card-body">
                            <div class="service-icon mb-4"></div>
                            <i class="fas fa-tag fa-lg text-dark mb-3"></i>
                            <h5 class="card-title">Consignment</h5>
                            <p class="card-text">Our premium consignment service ensures your Porsche finds its ideal new owner. We handle every aspect of the sale with the care and attention your vehicle deserves.</p>
                            <a href="sell.php" class="btn btn-link p-0 mt-3">Learn More</a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="card service-card h-100 p-4">
                        <div class="card-body">
                            <div class="service-icon mb-4"></div>
                            <i class="fas fa-key fa-lg text-dark mb-3"></i>
                            <h5 class="card-title">Experience</h5>
                            <p class="card-text">Indulge in the Porsche driving experience with our exclusive rental program. Perfect for special occasions or for those seeking an extended test drive experience.</p>
                            <a href="rent.php" class="btn btn-link p-0 mt-3">Discover Options</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section>
        <div class="container">
            <div class="section-header text-center">
                <h2>Client Testimonials</h2>
                <p class="lead">The voices of our distinguished clientele</p>
            </div>
            
            <div class="row">
                <?php 
                // If no testimonials are found, show placeholder content
                if (empty($testimonials)) {
                    $testimonials = [
                        [
                            'name' => 'Michael S.',
                            'location' => 'Munich, Germany',
                            'rating' => 5,
                            'text' => 'The entire experience exceeded my expectations. From selection to delivery, the team was professional and attentive to every detail.'
                        ],
                        [
                            'name' => 'Sophia L.',
                            'location' => 'Vienna, Austria',
                            'rating' => 5,
                            'text' => 'I couldn\'t be happier with my new Porsche 911. The personalized attention and expert knowledge made the process effortless.'
                        ],
                        [
                            'name' => 'Alexander B.',
                            'location' => 'Zurich, Switzerland',
                            'rating' => 5,
                            'text' => 'As a long-time Porsche enthusiast, I appreciate their commitment to excellence. My fourth purchase from them and certainly not my last.'
                        ]
                    ];
                }
                
                foreach ($testimonials as $testimonial): 
                ?>
                <div class="col-md-4 mb-4">
                    <div class="card testimonial-card h-100 p-4">
                        <div class="card-body">
                            <div class="mb-3">
                                <?php for ($i = 0; $i < $testimonial['rating']; $i++): ?>
                                    <i class="fas fa-star text-warning"></i>
                                <?php endfor; ?>
                            </div>
                            <p class="card-text fst-italic mb-4"><?php echo htmlspecialchars($testimonial['text']); ?></p>
                            <div>
                                <h6 class="mb-0 text-uppercase"><?php echo htmlspecialchars($testimonial['name']); ?></h6>
                                <p class="text-muted small mb-0"><?php echo htmlspecialchars($testimonial['location']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Call to Action -->
    <section class="cta-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="mb-4">Elevate Your Driving Experience</h2>
                    <p class="lead mb-4">Schedule a private consultation with our Porsche specialists</p>
                    <div>
                        <a href="contact.php" class="btn btn-primary me-3">Reserve Appointment</a>
                        <a href="buy.php" class="btn btn-outline-dark">View Collection</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include 'footer.php'; ?>