<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = ""; // Leave blank as per your example, but should be set in production
$dbname = "test1";

// Connect to database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = '';

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input
    $firstname = isset($_POST['firstname']) ? trim($_POST['firstname']) : '';
    $lastname = isset($_POST['lastname']) ? trim($_POST['lastname']) : '';
    $fullname = $firstname . ' ' . $lastname;
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
    
    // Validation
    if (empty($firstname) || empty($lastname) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = 'Please fill in all fields';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long';
    } else {
        // Check if email already exists in the database
        $check_email = $conn->prepare("SELECT email FROM users WHERE email = ?");
        $check_email->bind_param("s", $email);
        $check_email->execute();
        $result = $check_email->get_result();
        
        if ($result->num_rows > 0) {
            $error = 'Email address is already registered';
        }
        $check_email->close();
        
        // If no errors, proceed with registration
        if (empty($error)) {
            // Begin transaction for consistency across both tables
            $conn->begin_transaction();
            
            try {
                // Hash the password for security
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                // Insert into users table
                $stmt1 = $conn->prepare("INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, NOW())");
                $stmt1->bind_param("sss", $fullname, $email, $hashed_password);
                $stmt1->execute();
                $stmt1->close();
                
                // Insert into myguests1 table
                $stmt2 = $conn->prepare("INSERT INTO myguests1 (firstname, lastname, email) VALUES (?, ?, ?)");
                $stmt2->bind_param("sss", $firstname, $lastname, $email);
                $stmt2->execute();
                $stmt2->close();
                
                // Commit transaction
                $conn->commit();
                
                // Set session variables (optional)
                $_SESSION['user_id'] = $conn->insert_id;
                $_SESSION['username'] = $fullname;
                $_SESSION['email'] = $email;
                
                // Redirect to home page
                header("Location: home.php");
                exit();
            } catch (Exception $e) {
                // Rollback transaction on error
                $conn->rollback();
                $error = 'Registration failed: ' . $e->getMessage();
            }
        }
    }
}

// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join Porsche Experience - Register</title>
    <style>
        :root {
            --porsche-red: #d00;
            --porsche-black: #000;
            --porsche-gray: #333;
            --porsche-light-gray: #f5f5f5;
            --porsche-silver: #e0e0e0;
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            background-color: #000;
            color: white;
            line-height: 1.6;
            height: 100vh;
            overflow: hidden;
        }
        
        .registration-container {
            height: 100vh;
            display: flex;
            position: relative;
        }
        
        .left-panel {
            width: 60%;
            height: 100%;
            position: relative;
            overflow: hidden;
        }
        
        .bg-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('assets/images/porsche-showroom.jpg');
            background-size: cover;
            background-position: center;
            filter: brightness(0.7);
            transition: var(--transition);
            z-index: 1;
        }
        
        .bg-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.2) 100%);
            z-index: 2;
        }
        
        .content-wrapper {
            position: relative;
            z-index: 3;
            padding: 50px;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        
        .branding {
            margin-bottom: 30px;
        }
        
        .branding img {
            height: 40px;
            background-color: black;
        }
        
        .content-box {
            max-width: 450px;
        }
        
        .headline {
            font-size: 3.5rem;
            font-weight: 300;
            letter-spacing: -1px;
            margin-bottom: 20px;
            line-height: 1.1;
        }
        
        .headline span {
            font-weight: 700;
            display: block;
            color: var(--porsche-red);
        }
        
        .subheadline {
            font-size: 1.1rem;
            margin-bottom: 30px;
            opacity: 0.8;
        }
        
        .feature-list {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 40px;
        }
        
        .feature-item {
            display: flex;
            align-items: center;
            background-color: rgba(255,255,255,0.1);
            padding: 10px 20px;
            border-radius: 30px;
            backdrop-filter: blur(5px);
        }
        
        .feature-icon {
            margin-right: 10px;
            color: var(--porsche-red);
        }
        
        .footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 20px;
            font-size: 0.9rem;
            opacity: 0.7;
        }
        
        .footer-links {
            display: flex;
            gap: 20px;
        }
        
        .footer-links a {
            color: white;
            text-decoration: none;
            transition: var(--transition);
        }
        
        .footer-links a:hover {
            color: var(--porsche-red);
        }
        
        .social-links {
            display: flex;
            gap: 15px;
        }
        
        .social-links a {
            color: white;
            text-decoration: none;
            transition: var(--transition);
        }
        
        .social-links a:hover {
            color: var(--porsche-red);
        }
        
        .right-panel {
            width: 40%;
            height: 100%;
            background-color: var(--porsche-light-gray);
            overflow-y: auto;
            padding: 0 5%;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .form-container {
            max-width: 400px;
            margin: 0 auto;
            color: var(--porsche-gray);
        }
        
        .form-heading {
            font-size: 1.8rem;
            font-weight: 600;
            margin-bottom: 30px;
            color: var(--porsche-black);
            position: relative;
            padding-bottom: 15px;
        }
        
        .form-heading::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--porsche-red);
        }
        
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--porsche-gray);
            font-size: 0.9rem;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--porsche-silver);
            border-radius: 4px;
            background-color: white;
            transition: var(--transition);
        }
        
        .form-control:focus {
            border-color: var(--porsche-red);
            box-shadow: 0 0 0 3px rgba(210,0,0,0.1);
            outline: none;
        }
        
        .form-text {
            display: block;
            margin-top: 5px;
            font-size: 0.8rem;
            color: #777;
        }
        
        .btn-register {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 4px;
            background-color: var(--porsche-red);
            color: white;
            font-weight: 600;
            letter-spacing: 0.5px;
            cursor: pointer;
            transition: var(--transition);
            margin-top: 10px;
        }
        
        .btn-register:hover {
            background-color: #b00;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .alternate-links {
            text-align: center;
            margin-top: 25px;
            font-size: 0.9rem;
        }
        
        .alternate-links a {
            color: var(--porsche-red);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
        }
        
        .alternate-links a:hover {
            text-decoration: underline;
        }
        
        .alert {
            padding: 12px 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            border: none;
        }
        
        .alert-danger {
            background-color: rgba(220,53,69,0.1);
            color: #dc3545;
        }
        
        /* Tooltip styles */
        .form-group {
            position: relative;
        }
        
        .tooltip {
            visibility: hidden;
            position: absolute;
            right: 0;
            top: 65px;
            background-color: var(--porsche-black);
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
            width: 250px;
            font-size: 0.85rem;
            z-index: 100;
            opacity: 0;
            transition: opacity 0.3s, visibility 0.3s;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .tooltip::after {
            content: "";
            position: absolute;
            top: -10px;
            right: 20px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent transparent var(--porsche-black) transparent;
        }
        
        .form-control:hover + .tooltip {
            visibility: visible;
            opacity: 1;
        }
        
        .tooltip-title {
            font-weight: bold;
            margin-bottom: 5px;
            color: var(--porsche-red);
        }
        
        @media (max-width: 992px) {
            .registration-container {
                flex-direction: column;
                overflow-y: auto;
                height: auto;
            }
            
            .left-panel, .right-panel {
                width: 100%;
            }
            
            .left-panel {
                height: 300px;
            }
            
            .content-wrapper {
                padding: 30px;
            }
            
            .headline {
                font-size: 2.5rem;
            }
            
            .content-box {
                max-width: 100%;
            }
            
            .footer {
                display: none;
            }
            
            .right-panel {
                padding: 40px 20px;
            }
            
            .form-container {
                max-width: 100%;
            }
        }
    </style>
    <!-- Add Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="registration-container">
        <div class="left-panel">
            <div class="bg-image"></div>
            <div class="bg-overlay"></div>
            <div class="content-wrapper">
                <div class="branding">
                    <img src="1720107822porsche-car-logo-png.png" alt="Porsche Logo">
                </div>
                
                <div class="content-box">
                    <h1 class="headline">Join The <span>Porsche Family</span></h1>
                    <p class="subheadline">Create your Porsche account and unlock exclusive benefits, event invitations, and personalized experiences designed around your passion for performance.</p>
                    
                    <div class="feature-list">
                        <div class="feature-item">
                            <span class="feature-icon"><i class="fas fa-calendar-alt"></i></span>
                            Track Day Events
                        </div>
                        <div class="feature-item">
                            <span class="feature-icon"><i class="fas fa-tag"></i></span>
                            Exclusive Offers
                        </div>
                        <div class="feature-item">
                            <span class="feature-icon"><i class="fas fa-wrench"></i></span>
                            Priority Service
                        </div>
                    </div>
                </div>
                
                <div class="footer">
                    <div class="footer-links">
                        <a href="#">Privacy Policy</a>
                        <a href="#">Terms of Service</a>
                        <a href="#">Contact Us</a>
                    </div>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="right-panel">
            <div class="form-container">
                <h2 class="form-heading">Create Your Account</h2>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="form-group">
                        <label for="firstname" class="form-label">First Name</label>
                        <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Enter your first name" value="<?php echo isset($firstname) ? htmlspecialchars($firstname) : ''; ?>" required>
                        <div class="tooltip">
                            <div class="tooltip-title">First Name</div>
                            <p>Please enter your legal first name as it appears on your official documents. This will be used for all communications and event registrations with Porsche.</p>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="lastname" class="form-label">Last Name</label>
                        <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Enter your last name" value="<?php echo isset($lastname) ? htmlspecialchars($lastname) : ''; ?>" required>
                        <div class="tooltip">
                            <div class="tooltip-title">Last Name</div>
                            <p>Please enter your legal last name as it appears on your official documents. Your full name will be displayed on your Porsche Account profile.</p>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email address" value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>" required>
                        <div class="tooltip">
                            <div class="tooltip-title">Email Address</div>
                            <p>Enter a valid email address that you check regularly. This will be your login username and used for all communications from Porsche, including exclusive offers and event invitations.</p>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Create a password" required>
                        <small class="form-text">Password must be at least 6 characters long</small>
                        <div class="tooltip">
                            <div class="tooltip-title">Password</div>
                            <p>Create a secure password for your Porsche account. Your password must be at least 6 characters long and should include a combination of letters, numbers, and special characters for enhanced security.</p>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm your password" required>
                        <div class="tooltip">
                            <div class="tooltip-title">Confirm Password</div>
                            <p>Please re-enter your password exactly as you typed it in the previous field. This helps ensure you haven't made any typing errors.</p>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-register">Create Account</button>
                    
                    <div class="alternate-links">
                        <p>Already have an account? <a href="login.php">Sign In</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Optional: Add mobile touch support for tooltip display
            if ('ontouchstart' in window) {
                const inputFields = document.querySelectorAll('.form-control');
                
                inputFields.forEach(input => {
                    const tooltip = input.nextElementSibling;
                    if (tooltip && tooltip.classList.contains('tooltip')) {
                        input.addEventListener('focus', function() {
                            // Hide all other tooltips first
                            document.querySelectorAll('.tooltip').forEach(t => {
                                t.style.visibility = 'hidden';
                                t.style.opacity = '0';
                            });
                            
                            // Show this tooltip
                            tooltip.style.visibility = 'visible';
                            tooltip.style.opacity = '1';
                        });
                        
                        input.addEventListener('blur', function() {
                            tooltip.style.visibility = 'hidden';
                            tooltip.style.opacity = '0';
                        });
                    }
                });
            }
        });
    </script>
</body>
</html>