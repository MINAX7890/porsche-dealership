<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="InsertintoTable.php" method="post">
            <label>First name:</label> <input type='text' name='FirstName' /><br>
            <label>Last name:</label> <input type='text' name='LastName' /><br>
    
            <label>email</label> <input type='email' name='mail' /><br> 
        
            <label>select department</label>
                <select name="stDept" id="inp07">
                    <option value="1">CS</option>
                    <option value="2">IS</option>
                    <option value="7">SE</option>
                </select>
            <br>
            <input type="submit" value="register"/>
        <?php
        // put your code here
        ?>
    </body>
</html>
