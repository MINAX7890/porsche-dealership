<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<?php
$servername = "localhost";
$username = "root";
$password = "";/* Put your password here */
$db="admin";
$conn = new mysqli($servername, $username, $password,$db);
// Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
if (isset($_POST['delete']))
{
    #echo"get id ".$_POST['id'];
    
    foreach($_POST['id'] as $x)
    {
        $sql = "DELETE FROM Myguests WHERE id = $x" ;
        $retval = mysqli_query($conn, $sql);
            
        if(! $retval ) {
               die('Could not delete data: ' . mysql_error());
            }   
        #echo "Deleted data successfully\n";
    }
}
    
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form method="post" actoin="<?php $_PHP_SELF ?>">
        <table border="1" width="50%">
        <?php
        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $sql = "SELECT * FROM MyGuests";
        $result = mysqli_query($conn, $sql);
        $i=1;
        if (mysqli_num_rows($result) > 0) 
        {
                while ( $row = mysqli_fetch_assoc($result) ) 
                {
                    if($i==1)
                    { //print table header
                        echo "<tr bgcolor='#f4f4f4'>";
                        echo"<td> Select </td>";
                        foreach($row as $key=>$value)
                            echo "<td>".$key."</td>";
                        echo "</tr>";   
                    }
                    if($i%2==1)
                        echo "<tr bgcolor='yellow'> ";
                    else 
                        echo "<tr > ";
                        
                    foreach($row as $key=>$value)
                    {
                        if ($key=="id")
                        {
                            echo "<td> <input type='checkbox' name='id[]' value='".$value."'></td>";
                        }
                        echo "<td>". $value ."</td>";
                    }
                    echo "</tr>";
                    $i++;
                }
                echo"</table>";
                echo"<input type='submit' value='delete' name='delete'>";
                echo"</form>";
                
                
        }
        else 
        {
            echo "0 results";
        }       
        ?>
            
        
</html>
