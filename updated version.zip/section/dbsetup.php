-- Create rental_cars table if it doesn't exist
CREATE TABLE IF NOT EXISTS `rental_cars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(100) NOT NULL,
  `year` varchar(4) NOT NULL,
  `description` text NOT NULL,
  `short_description` varchar(255) NOT NULL,
  `engine` varchar(100) NOT NULL,
  `transmission` varchar(50) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `features` text NOT NULL,
  `rental_rate` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create rental_bookings table if it doesn't exist
CREATE TABLE IF NOT EXISTS `rental_bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `car_id` int(11) NOT NULL,
  `renter_name` varchar(100) NOT NULL,
  `renter_email` varchar(100) NOT NULL,
  `renter_phone` varchar(20) NOT NULL,
  `pickup_date` date NOT NULL,
  `return_date` date NOT NULL,
  `special_requests` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `car_id` (`car_id`),
  CONSTRAINT `rental_bookings_ibfk_1` FOREIGN KEY (`car_id`) REFERENCES `rental_cars` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample data for rental cars
INSERT INTO `rental_cars` (`model`, `year`, `description`, `short_description`, `engine`, `transmission`, `image_url`, `features`, `rental_rate`) VALUES
('Porsche 911 Carrera', '2023', 'The iconic 911 Carrera delivers exceptional performance and driving pleasure. With its powerful flat-six engine and precise handling, it offers an unmatched driving experience that has made it a legend among sports cars.', 'The iconic sports car that defines the Porsche brand with exceptional performance and handling.', '3.0L Twin-Turbo Flat-Six', 'PDK Automatic', 'images/porsche-911.jpg', '[\"385 hp\",\"182 mph top speed\",\"Sports exhaust system\",\"Sports Chrono Package\",\"Heated leather seats\",\"Bose sound system\",\"Navigation system\",\"Automatic climate control\"]', 499.00),
('Porsche Taycan', '2023', 'Experience the future of electric performance with the Porsche Taycan. This all-electric sports car combines stunning acceleration with typical Porsche handling dynamics and practicality for daily use.', 'Porsche\'s revolutionary all-electric sports car with instant acceleration and precision handling.', 'Dual Electric Motors', 'Single-Speed', 'images/porsche-taycan.jpg', '[\"Dual electric motors\",\"402 hp\",\"155 mph top speed\",\"Range up to 227 miles\",\"Fast charging capability\",\"Panoramic glass roof\",\"Adaptive air suspension\",\"Premium audio system\"]', 449.00),
('Porsche Cayenne', '2023', 'The Porsche Cayenne combines sports car performance with SUV versatility. Perfect for those who need space and practicality without compromising on the Porsche driving experience.', 'A luxury SUV that combines Porsche performance with everyday practicality.', '3.0L V6 Turbo', '8-Speed Automatic', 'images/porsche-cayenne.jpg', '[\"335 hp\",\"152 mph top speed\",\"All-wheel drive\",\"Air suspension\",\"Panoramic roof\",\"Heated and ventilated seats\",\"Premium sound system\",\"Advanced driver assistance\"]', 399.00);