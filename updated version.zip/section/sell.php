<?php
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test1";

// Check if user is authenticated
$is_logged_in = isset($_SESSION['user_id']);

// Redirect if not logged in
if (!$is_logged_in) {
    header("Location: login.php");
    exit();
}

$submission_success = false;
$submission_error = '';
$form_data = []; // To preserve form data on validation failure

/**
 * Establishes database connection
 * @return mysqli|false Returns a mysqli connection object or false on failure
 */
function connectDB() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "test1";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        return false;
    }
    
    return $conn;
}

/**
 * Sanitizes input data to prevent XSS attacks
 * @param string $data Data to sanitize
 * @return string Sanitized data
 */
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Validates form data
 * @param array $data Form data to validate
 * @return array Array with validation status and error messages
 */
function validateFormData($data) {
    $errors = [];
    
    // Validate required fields
    $required_fields = ['seller_name', 'email', 'phone', 'car_model', 'car_year', 'car_color', 'car_mileage', 'asking_price'];
    foreach ($required_fields as $field) {
        if (empty($data[$field])) {
            $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required';
        }
    }
    
    // Validate email
    if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address';
    }
    
    // Validate phone (simple validation for demonstration)
    if (!empty($data['phone']) && !preg_match('/^[0-9+() -]{6,20}$/', $data['phone'])) {
        $errors[] = 'Please enter a valid phone number';
    }
    
    // Validate year
    if (!empty($data['car_year'])) {
        $year = (int)$data['car_year'];
        $current_year = (int)date('Y');
        if ($year < 1950 || $year > $current_year) {
            $errors[] = 'Please enter a valid year between 1950 and ' . $current_year;
        }
    }
    
    // Validate mileage
    if (!empty($data['car_mileage']) && ((int)$data['car_mileage'] < 0)) {
        $errors[] = 'Mileage cannot be negative';
    }
    
    // Validate price
    if (!empty($data['asking_price']) && ((float)$data['asking_price'] <= 0)) {
        $errors[] = 'Please enter a valid asking price';
    }
    
    return [
        'valid' => empty($errors),
        'errors' => $errors
    ];
}

/**
 * Create vehicles table if it doesn't exist
 * @param mysqli $conn Database connection
 * @return bool Success status
 */
function ensureVehiclesTableExists($conn) {
    $create_table_sql = "CREATE TABLE IF NOT EXISTS vehicles (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT(6) NULL,
        seller_name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        car_model VARCHAR(100) NOT NULL,
        car_year INT(4) NOT NULL,
        car_color VARCHAR(50) NOT NULL,
        car_mileage INT(10) NOT NULL,
        car_condition VARCHAR(50) NOT NULL,
        asking_price DECIMAL(10,2) NOT NULL,
        additional_info TEXT,
        submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (user_id)
    )";
    
    return $conn->query($create_table_sql);
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize all input data
    foreach ($_POST as $key => $value) {
        $form_data[$key] = sanitizeInput($value);
    }
    
    // Validate form data
    $validation = validateFormData($form_data);
    
    if (!$validation['valid']) {
        $submission_error = implode('<br>', $validation['errors']);
    } else {
        // Connect to database
        $conn = connectDB();
        
        if (!$conn) {
            $submission_error = 'Database connection failed. Please try again later.';
        } else {
            // Ensure vehicles table exists
            if (!ensureVehiclesTableExists($conn)) {
                $submission_error = "Error creating table: " . $conn->error;
            } else {
                // Prepare data for insertion
                $user_id = $_SESSION['user_id'];
                $seller_name = $conn->real_escape_string($form_data['seller_name']);
                $email = $conn->real_escape_string($form_data['email']);
                $phone = $conn->real_escape_string($form_data['phone']);
                $car_model = $conn->real_escape_string($form_data['car_model']);
                $car_year = (int)$form_data['car_year'];
                $car_color = $conn->real_escape_string($form_data['car_color']);
                $car_mileage = (int)$form_data['car_mileage'];
                $car_condition = $conn->real_escape_string($form_data['car_condition']);
                $asking_price = (float)$form_data['asking_price'];
                $additional_info = $conn->real_escape_string($form_data['additional_info'] ?? '');
                
                // Insert vehicle data using prepared statement
                $insert_sql = "INSERT INTO vehicles (user_id, seller_name, email, phone, car_model, car_year, car_color, car_mileage, car_condition, asking_price, additional_info) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                $stmt = $conn->prepare($insert_sql);
                if (!$stmt) {
                    $submission_error = "Preparation failed: " . $conn->error;
                } else {
                    $stmt->bind_param("issssisisds", $user_id, $seller_name, $email, $phone, $car_model, $car_year, $car_color, $car_mileage, $car_condition, $asking_price, $additional_info);
                    
                    if ($stmt->execute()) {
                        $submission_success = true;
                        // Clear form data on successful submission
                        $form_data = [];
                    } else {
                        $submission_error = "Error: " . $stmt->error;
                    }
                    
                    $stmt->close();
                }
            }
            
            $conn->close();
        }
    }
}

// Pre-fill form data for logged-in users if first visit
if (empty($form_data)) {
    $form_data['seller_name'] = $_SESSION['username'] ?? '';
    $form_data['email'] = $_SESSION['email'] ?? '';
}

// Get the current year for the year input max value
$current_year = date('Y');
?>

<?php include 'header.php'; ?>

<style>
:root {
    --porsche-red: #d5001c;
    --porsche-black: #000000;
    --porsche-gold: #c9a96e;
    --porsche-silver: #a6a6a6;
    --porsche-dark-gray: #2c2c2c;
    --gradient-primary: linear-gradient(135deg, var(--porsche-red) 0%, #b8001a 100%);
    --gradient-secondary: linear-gradient(135deg, var(--porsche-dark-gray) 0%, var(--porsche-black) 100%);
    --shadow-elegant: 0 20px 40px rgba(0, 0, 0, 0.1);
    --shadow-hover: 0 30px 60px rgba(0, 0, 0, 0.15);
}

body {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}

.sell-section {
    padding: 4rem 0 6rem;
    position: relative;
    overflow: hidden;
}

.sell-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 200px;
    background: var(--gradient-primary);
    opacity: 0.05;
    z-index: 0;
}

.section-header {
    position: relative;
    z-index: 1;
}

.section-header h1 {
    font-size: 3.5rem;
    font-weight: 800;
    background: var(--gradient-primary);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 1rem;
    letter-spacing: -0.02em;
}

.section-header .lead {
    font-size: 1.25rem;
    color: #6c757d;
    font-weight: 400;
    max-width: 600px;
    margin: 0 auto;
}

.card {
    border: none;
    border-radius: 20px;
    box-shadow: var(--shadow-elegant);
    backdrop-filter: blur(10px);
    background: rgba(255, 255, 255, 0.95);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    overflow: hidden;
    position: relative;
}

.card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: var(--gradient-primary);
}

.card:hover {
    transform: translateY(-8px);
    box-shadow: var(--shadow-hover);
}

.card-body {
    padding: 3rem;
}

.form-label {
    font-weight: 600;
    color: var(--porsche-dark-gray);
    margin-bottom: 0.75rem;
    font-size: 0.95rem;
    letter-spacing: 0.01em;
}

.form-control, 
.form-select {
    border: 2px solid #e9ecef;
    border-radius: 12px;
    padding: 0.875rem 1.25rem;
    font-size: 1rem;
    transition: all 0.3s ease;
    background: rgba(255, 255, 255, 0.8);
    backdrop-filter: blur(5px);
}

.form-control:focus, 
.form-select:focus {
    border-color: var(--porsche-red);
    box-shadow: 0 0 0 0.2rem rgba(213, 0, 28, 0.15);
    transform: translateY(-2px);
    background: rgba(255, 255, 255, 0.95);
}

.form-control.is-invalid {
    border-color: #dc3545;
    box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.15);
}

.input-group-text {
    background: var(--gradient-primary);
    color: white;
    border: none;
    font-weight: 600;
    border-radius: 12px 0 0 12px;
}

.btn-primary {
    background: var(--gradient-primary);
    border: none;
    border-radius: 12px;
    padding: 1rem 2.5rem;
    font-weight: 600;
    font-size: 1.1rem;
    letter-spacing: 0.5px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
}

.btn-primary::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: left 0.5s;
}

.btn-primary:hover::before {
    left: 100%;
}

.btn-primary:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 35px rgba(213, 0, 28, 0.3);
}

.btn-outline-secondary {
    border: 2px solid var(--porsche-silver);
    color: var(--porsche-dark-gray);
    border-radius: 12px;
    padding: 1rem 2.5rem;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-outline-secondary:hover {
    background: var(--porsche-dark-gray);
    border-color: var(--porsche-dark-gray);
    transform: translateY(-3px);
}

.alert-danger {
    background: linear-gradient(135deg, #f8d7da 0%, #f1aeb5 100%);
    border: none;
    border-radius: 12px;
    border-left: 4px solid #dc3545;
    color: #721c24;
    font-weight: 500;
}

.alert-success {
    background: linear-gradient(135deg, #d1e7dd 0%, #a3cfbb 100%);
    border: none;
    border-radius: 12px;
    border-left: 4px solid #198754;
    color: #0f5132;
}

.process-card {
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    border-radius: 20px;
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(10px);
}

.process-card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: var(--shadow-hover);
}

.process-icon {
    padding: 1.5rem;
    background: linear-gradient(135deg, rgba(213, 0, 28, 0.1) 0%, rgba(213, 0, 28, 0.05) 100%);
    border-radius: 50%;
    display: inline-block;
    transition: all 0.3s ease;
}

.process-card:hover .process-icon {
    transform: scale(1.1);
    background: var(--gradient-primary);
}

.process-card:hover .process-icon i {
    color: white !important;
}

.testimonial-card {
    background: var(--gradient-secondary);
    color: white;
    border-radius: 20px;
    position: relative;
    overflow: hidden;
}

.testimonial-card::before {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    width: 200px;
    height: 200px;
    background: radial-gradient(circle, rgba(201, 169, 110, 0.1) 0%, transparent 70%);
}

.success-checkmark {
    width: 80px;
    height: 80px;
    background: var(--gradient-primary);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 2rem;
    animation: checkmarkPulse 2s infinite;
}

@keyframes checkmarkPulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}

.section-divider {
    height: 2px;
    background: var(--gradient-primary);
    border: none;
    border-radius: 2px;
    opacity: 0.3;
    margin: 3rem 0;
}

@media (max-width: 768px) {
    .section-header h1 {
        font-size: 2.5rem;
    }
    
    .card-body {
        padding: 2rem;
    }
    
    .btn-primary, .btn-outline-secondary {
        padding: 0.875rem 2rem;
        font-size: 1rem;
    }
}

/* Smooth scroll behavior */
html {
    scroll-behavior: smooth;
}

/* Form animations */
.form-floating-label {
    position: relative;
}

.form-floating-label input:focus + label,
.form-floating-label input:not(:placeholder-shown) + label {
    transform: translateY(-1.5rem) scale(0.85);
    color: var(--porsche-red);
}

/* Custom checkbox styling */
.form-check-input:checked {
    background-color: var(--porsche-red);
    border-color: var(--porsche-red);
}

.form-check-input:focus {
    box-shadow: 0 0 0 0.2rem rgba(213, 0, 28, 0.25);
}
</style>

<main>
    <section class="sell-section">
        <div class="container">
            <div class="section-header text-center mb-5">
                <h1 class="fw-bold">Sell Your Porsche</h1>
                <p class="lead">Get the best value for your premium vehicle with our expert evaluation service</p>
            </div>
            
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <?php if ($submission_success): ?>
                    <!-- Success message -->
                    <div class="card mb-4">
                        <div class="card-body text-center p-5">
                            <div class="success-checkmark">
                                <i class="fas fa-check text-white" style="font-size: 2rem;"></i>
                            </div>
                            <h2 class="fw-bold mb-3" style="color: var(--porsche-dark-gray);">Thank You for Your Submission</h2>
                            <p class="lead mb-4" style="color: #6c757d;">We've received your Porsche details and our team will review your information promptly. You can expect to hear from one of our specialists within 24-48 hours.</p>
                            <div class="d-flex justify-content-center gap-3 flex-wrap">
                                <a href="home.php" class="btn btn-primary">
                                    <i class="fas fa-home me-2"></i>Return to Home
                                </a>
                                <a href="sell.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-plus me-2"></i>Submit Another Vehicle
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <!-- Form card -->
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-4">
                                <div class="me-3">
                                    <i class="fas fa-car-side fa-2x" style="color: var(--porsche-red);"></i>
                                </div>
                                <div>
                                    <h3 class="fw-bold mb-1" style="color: var(--porsche-dark-gray);">Vehicle Details Form</h3>
                                    <p class="text-muted mb-0">Please provide accurate information about your Porsche</p>
                                </div>
                            </div>
                            
                            <?php if ($submission_error): ?>
                            <div class="alert alert-danger mb-4">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                <?php echo $submission_error; ?>
                            </div>
                            <?php endif; ?>
                            
                            <form method="POST" action="sell.php" novalidate>
                                <!-- Contact Information -->
                                <div class="mb-5">
                                    <div class="d-flex align-items-center mb-4">
                                        <i class="fas fa-user-circle me-3 text-primary"></i>
                                        <h5 class="fw-bold mb-0" style="color: var(--porsche-dark-gray);">Contact Information</h5>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="seller_name" class="form-label">
                                                <i class="fas fa-user me-2"></i>Your Name*
                                            </label>
                                            <input type="text" class="form-control" id="seller_name" name="seller_name" value="<?php echo htmlspecialchars($form_data['seller_name'] ?? ''); ?>" required>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label for="email" class="form-label">
                                                <i class="fas fa-envelope me-2"></i>Email Address*
                                            </label>
                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($form_data['email'] ?? ''); ?>" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="phone" class="form-label">
                                            <i class="fas fa-phone me-2"></i>Phone Number*
                                        </label>
                                        <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($form_data['phone'] ?? ''); ?>" placeholder="+1 (123) 456-7890" required>
                                    </div>
                                </div>
                                
                                <hr class="section-divider">
                                
                                <!-- Car Information -->
                                <div class="mb-5">
                                    <div class="d-flex align-items-center mb-4">
                                        <i class="fas fa-car me-3 text-primary"></i>
                                        <h5 class="fw-bold mb-0" style="color: var(--porsche-dark-gray);">Porsche Details</h5>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="car_model" class="form-label">
                                                <i class="fas fa-tag me-2"></i>Porsche Model*
                                            </label>
                                            <input type="text" class="form-control" id="car_model" name="car_model" value="<?php echo htmlspecialchars($form_data['car_model'] ?? ''); ?>" placeholder="e.g. 911 Carrera, Cayenne, Panamera" required>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label for="car_year" class="form-label">
                                                <i class="fas fa-calendar me-2"></i>Year*
                                            </label>
                                            <input type="number" class="form-control" id="car_year" name="car_year" value="<?php echo htmlspecialchars($form_data['car_year'] ?? ''); ?>" min="1950" max="<?php echo $current_year; ?>" required>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="car_color" class="form-label">
                                                <i class="fas fa-palette me-2"></i>Color*
                                            </label>
                                            <input type="text" class="form-control" id="car_color" name="car_color" value="<?php echo htmlspecialchars($form_data['car_color'] ?? ''); ?>" required>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label for="car_mileage" class="form-label">
                                                <i class="fas fa-tachometer-alt me-2"></i>Mileage (km)*
                                            </label>
                                            <input type="number" class="form-control" id="car_mileage" name="car_mileage" value="<?php echo htmlspecialchars($form_data['car_mileage'] ?? ''); ?>" min="0" step="100" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="car_condition" class="form-label">
                                            <i class="fas fa-star me-2"></i>Vehicle Condition*
                                        </label>
                                        <select class="form-select" id="car_condition" name="car_condition" required>
                                            <option value="">-- Select Condition --</option>
                                            <option value="Excellent" <?php echo (isset($form_data['car_condition']) && $form_data['car_condition'] == 'Excellent') ? 'selected' : ''; ?>>⭐⭐⭐⭐⭐ Excellent - Like new condition</option>
                                            <option value="Very Good" <?php echo (isset($form_data['car_condition']) && $form_data['car_condition'] == 'Very Good') ? 'selected' : ''; ?>>⭐⭐⭐⭐ Very Good - Minor wear, well maintained</option>
                                            <option value="Good" <?php echo (isset($form_data['car_condition']) && $form_data['car_condition'] == 'Good') ? 'selected' : ''; ?>>⭐⭐⭐ Good - Normal wear for age and mileage</option>
                                            <option value="Fair" <?php echo (isset($form_data['car_condition']) && $form_data['car_condition'] == 'Fair') ? 'selected' : ''; ?>>⭐⭐ Fair - Some mechanical or cosmetic issues</option>
                                            <option value="Poor" <?php echo (isset($form_data['car_condition']) && $form_data['car_condition'] == 'Poor') ? 'selected' : ''; ?>>⭐ Poor - Significant mechanical or cosmetic issues</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="asking_price" class="form-label">
                                            <i class="fas fa-euro-sign me-2"></i>Asking Price (€)*
                                        </label>
                                        <div class="input-group">
                                            <span class="input-group-text">€</span>
                                            <input type="number" class="form-control" id="asking_price" name="asking_price" value="<?php echo htmlspecialchars($form_data['asking_price'] ?? ''); ?>" min="0" step="1000" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="additional_info" class="form-label">
                                            <i class="fas fa-info-circle me-2"></i>Additional Information
                                        </label>
                                        <textarea class="form-control" id="additional_info" name="additional_info" rows="4" placeholder="Please include any additional details about your vehicle, such as options, modifications, service history, or any issues."><?php echo htmlspecialchars($form_data['additional_info'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                                
                                <!-- Terms and Submit -->
                                <div class="form-check mb-4 p-3" style="background: rgba(213, 0, 28, 0.05); border-radius: 12px;">
                                    <input class="form-check-input" type="checkbox" id="terms_agreement" name="terms_agreement" required>
                                    <label class="form-check-label fw-500" for="terms_agreement">
                                        <i class="fas fa-shield-alt me-2"></i>
                                        I agree to be contacted about my vehicle and I confirm that the information provided is accurate.
                                    </label>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary btn-lg">
                                        <i class="fas fa-paper-plane me-2"></i>
                                        Submit Vehicle Information
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <!-- How it works section -->
                    <div class="sell-process mt-5">
                        <div class="section-header text-center mb-5">
                            <h3 class="fw-bold" style="color: var(--porsche-dark-gray);">The Porsche Selling Process</h3>
                            <p style="color: #6c757d;">Three simple steps to sell your vehicle with confidence</p>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <div class="card h-100 process-card text-center">
                                    <div class="card-body p-4">
                                        <div class="process-icon mb-3">
                                            <i class="fas fa-clipboard-list fa-3x text-primary"></i>
                                        </div>
                                        <h5 class="card-title fw-bold" style="color: var(--porsche-dark-gray);">1. Submit Details</h5>
                                        <p class="card-text" style="color: #6c757d;">Complete our comprehensive form with detailed information about your Porsche.</p>
                                    </div>
                                </div>
                            </div>
                            
                          <div class="col-md-4 mb-4">
                                <div class="card h-100 process-card text-center">
                                    <div class="card-body p-4">
                                        <div class="process-icon mb-3">
                                            <i class="fas fa-search-dollar fa-3x text-primary"></i>
                                        </div>
                                        <h5 class="card-title fw-bold" style="color: var(--porsche-dark-gray);">2. Expert Evaluation</h5>
                                        <p class="card-text" style="color: #6c757d;">Our certified Porsche specialists will assess your vehicle's value using market data and condition reports.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-4 mb-4">
                                <div class="card h-100 process-card text-center">
                                    <div class="card-body p-4">
                                        <div class="process-icon mb-3">
                                            <i class="fas fa-handshake fa-3x text-primary"></i>
                                        </div>
                                        <h5 class="card-title fw-bold" style="color: var(--porsche-dark-gray);">3. Complete Sale</h5>
                                        <p class="card-text" style="color: #6c757d;">Receive a competitive offer and complete the sale with our secure, streamlined process.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Benefits section -->
                    <div class="benefits-section mt-5">
                        <div class="section-header text-center mb-5">
                            <h3 class="fw-bold" style="color: var(--porsche-dark-gray);">Why Choose Our Service</h3>
                            <p style="color: #6c757d;">The advantages of selling your Porsche through our platform</p>
                        </div>
                        
                        <div class="row">
                            <div class="col-lg-6 mb-4">
                                <div class="card h-100 testimonial-card">
                                    <div class="card-body p-4">
                                        <div class="d-flex align-items-center mb-3">
                                            <i class="fas fa-certificate fa-2x text-warning me-3"></i>
                                            <h5 class="card-title fw-bold mb-0 text-white">Certified Experts</h5>
                                        </div>
                                        <p class="card-text text-light opacity-75">Our team consists of certified Porsche specialists with years of experience in luxury vehicle valuation and sales.</p>
                                        <div class="d-flex align-items-center">
                                            <div class="flex-grow-1">
                                                <small class="text-warning">★★★★★</small>
                                                <small class="text-light opacity-75 ms-2">Based on 500+ reviews</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-6 mb-4">
                                <div class="card h-100" style="background: linear-gradient(135deg, var(--porsche-gold) 0%, #b8941f 100%); color: white;">
                                    <div class="card-body p-4">
                                        <div class="d-flex align-items-center mb-3">
                                            <i class="fas fa-shield-alt fa-2x text-white me-3"></i>
                                            <h5 class="card-title fw-bold mb-0 text-white">Secure & Transparent</h5>
                                        </div>
                                        <p class="card-text text-white opacity-90">All transactions are secured and transparent. No hidden fees, no surprises - just honest, fair pricing for your vehicle.</p>
                                        <div class="d-flex align-items-center">
                                            <div class="flex-grow-1">
                                                <small class="text-white">🔒</small>
                                                <small class="text-white opacity-75 ms-2">SSL Encrypted & Insured</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-md-4 mb-3">
                                <div class="d-flex align-items-center p-3" style="background: rgba(255, 255, 255, 0.8); border-radius: 12px; backdrop-filter: blur(10px);">
                                    <i class="fas fa-clock fa-2x text-primary me-3"></i>
                                    <div>
                                        <h6 class="fw-bold mb-1" style="color: var(--porsche-dark-gray);">Quick Response</h6>
                                        <small style="color: #6c757d;">24-48 hour evaluation</small>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <div class="d-flex align-items-center p-3" style="background: rgba(255, 255, 255, 0.8); border-radius: 12px; backdrop-filter: blur(10px);">
                                    <i class="fas fa-euro-sign fa-2x text-primary me-3"></i>
                                    <div>
                                        <h6 class="fw-bold mb-1" style="color: var(--porsche-dark-gray);">Best Market Price</h6>
                                        <small style="color: #6c757d;">Competitive valuations</small>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <div class="d-flex align-items-center p-3" style="background: rgba(255, 255, 255, 0.8); border-radius: 12px; backdrop-filter: blur(10px);">
                                    <i class="fas fa-users fa-2x text-primary me-3"></i>
                                    <div>
                                        <h6 class="fw-bold mb-1" style="color: var(--porsche-dark-gray);">Personal Service</h6>
                                        <small style="color: #6c757d;">Dedicated specialist</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Contact section -->
                    <div class="contact-section mt-5">
                        <div class="card" style="background: var(--gradient-secondary); color: white;">
                            <div class="card-body p-5 text-center">
                                <h4 class="fw-bold mb-3">Have Questions?</h4>
                                <p class="lead mb-4">Our Porsche specialists are here to help you through every step of the selling process.</p>
                                <div class="row justify-content-center">
                                    <div class="col-md-8">
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <div class="d-flex align-items-center justify-content-center">
                                                    <i class="fas fa-phone fa-lg me-2 text-warning"></i>
                                                    <div class="text-start">
                                                        <small class="opacity-75">Call us:</small><br>
                                                        <strong>+1 (555) 123-CARS</strong>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <div class="d-flex align-items-center justify-content-center">
                                                    <i class="fas fa-envelope fa-lg me-2 text-warning"></i>
                                                    <div class="text-start">
                                                        <small class="opacity-75">Email us:</small><br>
                                                        <strong>sell@porschedealer.com</strong>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
</main>

<script>
// Form validation and enhancement
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    const submitBtn = document.querySelector('button[type="submit"]');
    
    if (form && submitBtn) {
        // Add form validation
        form.addEventListener('submit', function(e) {
            const termsCheckbox = document.getElementById('terms_agreement');
            if (termsCheckbox && !termsCheckbox.checked) {
                e.preventDefault();
                alert('Please agree to the terms and conditions to continue.');
                termsCheckbox.focus();
                return false;
            }
            
            // Show loading state
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Submitting...';
            submitBtn.disabled = true;
        });
        
        // Auto-format phone number
        const phoneInput = document.getElementById('phone');
        if (phoneInput) {
            phoneInput.addEventListener('input', function(e) {
                let value = e.target.value.replace(/\D/g, '');
                if (value.length >= 10) {
                    value = value.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
                }
                e.target.value = value;
            });
        }
        
        // Auto-format price input
        const priceInput = document.getElementById('asking_price');
        if (priceInput) {
            priceInput.addEventListener('input', function(e) {
                let value = e.target.value.replace(/[^\d]/g, '');
                if (value) {
                    value = parseInt(value).toLocaleString();
                }
                // Note: We don't update the input value here to avoid cursor issues
                // The formatting is just for display in a separate element if needed
            });
        }
        
        // Enhanced form field animations
        const formControls = document.querySelectorAll('.form-control, .form-select');
        formControls.forEach(control => {
            control.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            
            control.addEventListener('blur', function() {
                this.parentElement.classList.remove('focused');
                if (this.value.trim() !== '') {
                    this.parentElement.classList.add('filled');
                } else {
                    this.parentElement.classList.remove('filled');
                }
            });
        });
    }
    
    // Smooth scroll for any anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add intersection observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // Observe all cards for animation
    document.querySelectorAll('.card, .process-card').forEach(card => {
        observer.observe(card);
    });
});

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    .card, .process-card {
        opacity: 0;
        transform: translateY(30px);
        transition: all 0.6s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .card.animate-in, .process-card.animate-in {
        opacity: 1;
        transform: translateY(0);
    }
    
    .form-group.focused .form-control {
        border-color: var(--porsche-red);
        box-shadow: 0 0 0 0.2rem rgba(213, 0, 28, 0.15);
    }
    
    .form-group.filled .form-label {
        color: var(--porsche-red);
    }
    
    @media (prefers-reduced-motion: reduce) {
        .card, .process-card {
            opacity: 1;
            transform: none;
            transition: none;
        }
    }
`;
document.head.appendChild(style);
</script>

<?php include 'footer.php'; ?>