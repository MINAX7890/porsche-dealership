<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test1";

// Start session for admin authentication
session_start();

// Check if the user is logged in, if not redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to get all tables from the database
function getTables($conn) {
    $tables = array();
    $result = $conn->query("SHOW TABLES");
    if ($result->num_rows > 0) {
        while($row = $result->fetch_row()) {
            $tables[] = $row[0];
        }
    }
    return $tables;
}

// Function to get the structure of a table
function getTableStructure($conn, $table) {
    $structure = array();
    $result = $conn->query("DESCRIBE $table");
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $structure[] = $row;
        }
    }
    return $structure;
}

// Function to get data from a table
function getTableData($conn, $table, $limit = 100, $offset = 0) {
    $data = array();
    $result = $conn->query("SELECT * FROM $table LIMIT $limit OFFSET $offset");
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    return $data;
}

// Function to count records in a table
function countRecords($conn, $table) {
    $result = $conn->query("SELECT COUNT(*) as count FROM $table");
    $row = $result->fetch_assoc();
    return $row['count'];
}

// Handle actions like delete, add, edit
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Delete record
    if (isset($_POST['delete'])) {
        $table = $_POST['table'];
        $id_column = $_POST['id_column'];
        $id = $_POST['id'];
        $stmt = $conn->prepare("DELETE FROM $table WHERE $id_column = ?");
        $stmt->bind_param('s', $id);
        if ($stmt->execute()) {
            $message = "Record deleted successfully";
        } else {
            $message = "Error deleting record: " . $conn->error;
        }
        $stmt->close();
    }
    
    // Add record
    if (isset($_POST['add'])) {
        $table = $_POST['table'];
        $columns = $_POST['columns'];
        $values = $_POST['values'];
        $columns_str = implode(", ", $columns);
        $placeholders = implode(", ", array_fill(0, count($values), "?"));
        $stmt = $conn->prepare("INSERT INTO $table ($columns_str) VALUES ($placeholders)");
        $types = str_repeat('s', count($values));
        $stmt->bind_param($types, ...$values);
        if ($stmt->execute()) {
            $message = "Record added successfully";
        } else {
            $message = "Error adding record: " . $conn->error;
        }
        $stmt->close();
    }
    
    // Edit record
    if (isset($_POST['edit'])) {
        $table = $_POST['table'];
        $id_column = $_POST['id_column'];
        $id = $_POST['id'];
        $columns = $_POST['columns'];
        $values = $_POST['values'];
        $set_clause = "";
        for ($i = 0; $i < count($columns); $i++) {
            $set_clause .= $columns[$i] . " = ?, ";
        }
        $set_clause = rtrim($set_clause, ", ");
        $stmt = $conn->prepare("UPDATE $table SET $set_clause WHERE $id_column = ?");
        $types = str_repeat('s', count($values) + 1);
        $values[] = $id;
        $stmt->bind_param($types, ...$values);
        if ($stmt->execute()) {
            $message = "Record updated successfully";
        } else {
            $message = "Error updating record: " . $conn->error;
        }
        $stmt->close();
    }
}

// Get current table to display
$current_table = isset($_GET['table']) ? $_GET['table'] : null;
$tables = getTables($conn);

// Pagination settings
$records_per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $records_per_page;

// Get table data if a table is selected
$table_structure = null;
$table_data = null;
$total_records = 0;
$total_pages = 0;

if ($current_table) {
    $table_structure = getTableStructure($conn, $current_table);
    $table_data = getTableData($conn, $current_table, $records_per_page, $offset);
    $total_records = countRecords($conn, $current_table);
    $total_pages = ceil($total_records / $records_per_page);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --sidebar-bg: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --sidebar-width: 280px;
            --primary-color: #667eea;
            --secondary-color: #764ba2;
        }
        
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f8f9fa; }
        
        .sidebar {
            background: var(--sidebar-bg);
            width: var(--sidebar-width);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            color: white;
            box-shadow: 4px 0 10px rgba(0,0,0,0.1);
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 2rem 1.5rem;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h3 {
            margin: 0;
            font-weight: 700;
            letter-spacing: 1px;
        }
        
        .nav-link {
            color: rgba(255,255,255,0.8) !important;
            padding: 0.8rem 1.5rem;
            border-radius: 0;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .nav-link:hover {
            background: rgba(255,255,255,0.1);
            color: white !important;
            border-left-color: white;
        }
        
        .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white !important;
            border-left-color: white;
            font-weight: 600;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
            min-height: 100vh;
        }
        
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: transform 0.2s ease;
        }
        
        .card:hover { transform: translateY(-2px); }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 1.25rem 1.5rem;
        }
        
        .btn {
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
        }
        
        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        
        .table {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        
        .table thead th {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            border: none;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.5px;
        }
        
        .table tbody tr {
            transition: background-color 0.2s ease;
        }
        
        .table tbody tr:hover {
            background-color: rgba(102, 126, 234, 0.05);
        }
        
        .alert {
            border: none;
            border-radius: 10px;
            padding: 1rem 1.5rem;
        }
        
        .modal-content {
            border-radius: 15px;
            border: none;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .modal-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-radius: 15px 15px 0 0;
        }
        
        .form-control {
            border-radius: 8px;
            border: 1px solid #e0e6ed;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        
        .pagination .page-link {
            border-radius: 8px;
            margin: 0 2px;
            border: none;
            color: var(--primary-color);
        }
        
        .pagination .page-item.active .page-link {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
        }
        
        .welcome-card {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            text-align: center;
            padding: 3rem 2rem;
        }
        
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0; }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3><i class="fas fa-tachometer-alt me-2"></i>Admin Panel</h3>
        </div>
        <ul class="nav flex-column py-3">
            <?php foreach ($tables as $table): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_table == $table) ? 'active' : ''; ?>" 
                   href="?table=<?php echo $table; ?>">
                    <i class="fas fa-table me-2"></i><?php echo ucfirst($table); ?>
                </a>
            </li>
            <?php endforeach; ?>
        </ul>
        <div class="p-3 mt-auto">
            <a href="logout.php" class="btn btn-light w-100">
                <i class="fas fa-sign-out-alt me-2"></i>Logout
            </a>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <?php if (!empty($message)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo $message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <?php if ($current_table): ?>
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="mb-0"><i class="fas fa-database me-2"></i><?php echo ucfirst($current_table); ?></h4>
                <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addRecordModal">
                    <i class="fas fa-plus me-2"></i>Add Record
                </button>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <?php foreach ($table_structure as $column): ?>
                                <th><?php echo $column['Field']; ?></th>
                                <?php endforeach; ?>
                                <th width="150">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($table_data)): ?>
                            <tr>
                                <td colspan="<?php echo count($table_structure) + 1; ?>" class="text-center py-4">
                                    <i class="fas fa-inbox fa-2x text-muted mb-2"></i><br>No records found
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($table_data as $row): ?>
                            <tr>
                                <?php foreach ($table_structure as $column): ?>
                                <td><?php echo htmlspecialchars($row[$column['Field']] ?? ''); ?></td>
                                <?php endforeach; ?>
                                <td>
                                    <button class="btn btn-sm btn-warning me-1 edit-record" 
                                            data-bs-toggle="modal" data-bs-target="#editRecordModal"
                                            data-record='<?php echo json_encode($row); ?>'>
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger delete-record" 
                                            data-bs-toggle="modal" data-bs-target="#deleteConfirmModal"
                                            data-id="<?php echo $row[$table_structure[0]['Field']]; ?>"
                                            data-id-column="<?php echo $table_structure[0]['Field']; ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <?php if ($total_pages > 1): ?>
                <div class="d-flex justify-content-center p-3">
                    <nav>
                        <ul class="pagination mb-0">
                            <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?table=<?php echo $current_table; ?>&page=<?php echo $page-1; ?>">Previous</a>
                            </li>
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?php echo ($page == $i) ? 'active' : ''; ?>">
                                <a class="page-link" href="?table=<?php echo $current_table; ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?table=<?php echo $current_table; ?>&page=<?php echo $page+1; ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Modals -->
        <div class="modal fade" id="addRecordModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add New Record</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form method="post">
                            <input type="hidden" name="table" value="<?php echo $current_table; ?>">
                            <input type="hidden" name="add" value="1">
                            <?php foreach ($table_structure as $column): ?>
                            <?php if ($column['Extra'] != 'auto_increment'): ?>
                            <div class="mb-3">
                                <label class="form-label"><?php echo $column['Field']; ?></label>
                                <input type="hidden" name="columns[]" value="<?php echo $column['Field']; ?>">
                                <input type="text" class="form-control" name="values[]" <?php echo ($column['Null'] === 'NO') ? 'required' : ''; ?>>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; ?>
                            <button type="submit" class="btn btn-primary w-100">Add Record</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="editRecordModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Record</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form method="post">
                            <input type="hidden" name="table" value="<?php echo $current_table; ?>">
                            <input type="hidden" name="edit" value="1">
                            <input type="hidden" id="edit_id_column" name="id_column">
                            <input type="hidden" id="edit_id" name="id">
                            <div id="editFieldsContainer"></div>
                            <button type="submit" class="btn btn-warning w-100">Update Record</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="deleteConfirmModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-danger">
                        <h5 class="modal-title text-white">Confirm Delete</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body text-center">
                        <i class="fas fa-exclamation-triangle fa-3x text-danger mb-3"></i>
                        <p>Are you sure you want to delete this record?</p>
                        <form method="post">
                            <input type="hidden" name="table" value="<?php echo $current_table; ?>">
                            <input type="hidden" name="delete" value="1">
                            <input type="hidden" id="delete_id_column" name="id_column">
                            <input type="hidden" id="delete_id" name="id">
                            <button type="submit" class="btn btn-danger w-100">Delete Record</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="card welcome-card">
            <div class="card-body">
                <i class="fas fa-tachometer-alt fa-4x mb-3"></i>
                <h1>Admin Dashboard</h1>
                <p class="lead">Welcome to your admin dashboard. Select a table from the sidebar to manage your data.</p>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const editButtons = document.querySelectorAll('.edit-record');
            const editFieldsContainer = document.getElementById('editFieldsContainer');
            const tableStructure = <?php echo json_encode($table_structure); ?>;
            const primaryKeyField = tableStructure ? tableStructure[0]['Field'] : '';
            
            editButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const record = JSON.parse(this.getAttribute('data-record'));
                    document.getElementById('edit_id_column').value = primaryKeyField;
                    document.getElementById('edit_id').value = record[primaryKeyField];
                    
                    editFieldsContainer.innerHTML = '';
                    
                    tableStructure.forEach(column => {
                        const fieldName = column['Field'];
                        if (fieldName !== primaryKeyField) {
                            const div = document.createElement('div');
                            div.className = 'mb-3';
                            
                            const label = document.createElement('label');
                            label.className = 'form-label';
                            label.textContent = fieldName;
                            
                            const hiddenInput = document.createElement('input');
                            hiddenInput.type = 'hidden';
                            hiddenInput.name = 'columns[]';
                            hiddenInput.value = fieldName;
                            
                            const input = document.createElement('input');
                            input.type = 'text';
                            input.className = 'form-control';
                            input.name = 'values[]';
                            input.value = record[fieldName] || '';
                            if (column['Null'] === 'NO') {
                                input.required = true;
                            }
                            
                            div.appendChild(label);
                            div.appendChild(hiddenInput);
                            div.appendChild(input);
                            editFieldsContainer.appendChild(div);
                        }
                    });
                });
            });
            
            const deleteButtons = document.querySelectorAll('.delete-record');
            
            deleteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    document.getElementById('delete_id_column').value = this.getAttribute('data-id-column');
                    document.getElementById('delete_id').value = this.getAttribute('data-id');
                });
            });
        });
    </script>
</body>
</html>