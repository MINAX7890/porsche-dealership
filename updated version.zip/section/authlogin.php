/**
 * Authenticates a user checking both users and myguests1 tables
 * @param string $email The user's email address
 * @param string $password The user's password
 * @return array Returns an array with user data and success status
 */
function login($email, $password) {
    try {
        $conn = connectDB();
        
        if (!$conn) {
            throw new Exception('Database connection failed. Please try again later.');
        }
        
        // First check users table (which has secure password hashing)
        $stmt = $conn->prepare("SELECT id, username, email, password FROM users WHERE email = ?");
        if (!$stmt) {
            throw new Exception('Prepare statement failed: ' . $conn->error);
        }
        
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // User found in users table
            $user = $result->fetch_assoc();
            
            // Verify password
            if (password_verify($password, $user['password'])) {
                $stmt->close();
                $conn->close();
                
                // Remove password from the returned user data
                unset($user['password']);
                
                return [
                    'success' => true,
                    'user' => $user,
                    'message' => 'Login successful'
                ];
            }
        }
        $stmt->close();
        
        // If we're here, either user wasn't found in users table or password didn't match
        // Now check myguests1 table (assuming password is stored plaintext for legacy users)
        // NOTE: This is NOT secure and should be migrated to proper password hashing
        
        $stmt = $conn->prepare("SELECT id, firstname, lastname, email FROM myguests1 WHERE email = ?");
        if (!$stmt) {
            throw new Exception('Prepare statement failed: ' . $conn->error);
        }
        
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // User found in myguests1 table
            $guest = $result->fetch_assoc();
            
            // Since myguests1 doesn't have a password field, we'll need to verify
            // the password through another method or table
            // For now, assuming you have a separate table or method to verify
            // these users' passwords (this needs to be implemented)
            
            // IMPORTANT: This is a placeholder. In a real scenario, you need proper password verification
            // Example of how you might check a password for myguests1 users:
            $verificationResult = verifyMyGuestsPassword($email, $password, $conn);
            
            if ($verificationResult) {
                $stmt->close();
                $conn->close();
                
                return [
                    'success' => true,
                    'user' => [
                        'id' => $guest['id'],
                        'username' => $guest['firstname'] . ' ' . $guest['lastname'],
                        'email' => $guest['email']
                    ],
                    'message' => 'Login successful (myguests1)'
                ];
            }
        }
        
        $stmt->close();
        $conn->close();
        
        // If we reach here, authentication failed for both tables
        return [
            'success' => false,
            'message' => 'Invalid email or password'
        ];
        
    } catch (Exception $e) {
        error_log("Error in login function: " . $e->getMessage());
        // Close connections
        if (isset($stmt) && $stmt instanceof mysqli_stmt) $stmt->close();
        if (isset($conn) && $conn instanceof mysqli) $conn->close();
        return [
            'success' => false,
            'message' => 'Login error: ' . $e->getMessage()
        ];
    }
}

/**
 * Verify password for myguests1 table users
 * NOTE: This is a placeholder function - you need to implement this based on
 * how passwords are stored for myguests1 users
 */
function verifyMyGuestsPassword($email, $password, $conn) {
    // IMPORTANT: This is just an example.
    // In reality, you should NEVER store passwords in plaintext.
    // All passwords should be securely hashed and salted.
    
    // Method 1: If you have a separate password table for myguests1
    $stmt = $conn->prepare("SELECT password FROM myguests_passwords WHERE email = ?");
    if ($stmt) {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            // Ideally this would be password_verify() if properly hashed
            $passwordMatch = ($row['password'] === $password); 
            $stmt->close();
            return $passwordMatch;
        }
        $stmt->close();
    }
    
    // Method 2: If you're using the users table for password storage
    $stmt = $conn->prepare("SELECT password FROM users WHERE email = ?");
    if ($stmt) {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $passwordMatch = password_verify($password, $row['password']);
            $stmt->close();
            return $passwordMatch;
        }
        $stmt->close();
    }
    
    return false;
}