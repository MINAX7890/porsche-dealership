<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->

<?php
/*
require_once "pdo.php";
$sqlQueryString="select * from MyGuests";
$Data =  $pdo->query($sqlQueryString);
 * */
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <table border="1" width="50%">
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";/* Put your password here */
        $db="test1";
        /* Create connection */
        $conn = new mysqli($servername, $username, $password,$db);
// Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $sql = "SELECT * FROM MyGuests";
        $result = mysqli_query($conn, $sql);
        $i=1;
        if (mysqli_num_rows($result) > 0) 
        {
                while ( $row = mysqli_fetch_assoc($result) ) #( $row = $Data->fetch(PDO::FETCH_ASSOC) )
                {
                    if($i==1)
                    { //print table header
                        echo "<tr bgcolor='#f4f4f4'>";
                        foreach($row as $key=>$value)
                            echo "<td>".$key."</td>";
                        echo "</tr>";   
                    }
                    if($i%2==1)
                        echo "<tr bgcolor='yellow'> ";
                    else 
                        echo "<tr > ";
                    foreach($row as $key=>$value)
                        echo "<td>". $value ."</td>"; 
                    echo "</tr>";
                    $i++;
                }
        }
        else 
        {
            echo "0 results";
        }       
        ?>
        </table>
    </body>
</html>
