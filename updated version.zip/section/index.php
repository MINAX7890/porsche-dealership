<?php
// Start session
session_start();
// Redirect to home if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: home.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Porsche Dealership - Premium Luxury Experience</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --porsche-red: #D5001C;
            --porsche-black: #000000;
            --porsche-grey: #f4f4f4;
            --transition-speed: 0.3s;
        }
        
        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        
        .welcome-container {
            display: flex;
            min-height: 100vh;
        }
        
        .welcome-left {
            width: 50%;
            padding: 3rem;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .welcome-right {
            width: 50%;
            position: relative;
            overflow: hidden;
        }
        
        .gif-background {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .logo {
            margin-bottom: 2.5rem;
        }
        
        .logo img {
            height: 60px;
        }
        
        h1 {
            font-weight: 700;
            font-size: 3.5rem;
            margin-bottom: 1rem;
        }
        
        .lead {
            font-size: 1.25rem;
            margin-bottom: 2.5rem;
            color: #555;
        }
        
        .welcome-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 3rem;
        }
        
        .btn-login {
            background-color: var(--porsche-red);
            color: white;
            border: none;
            padding: 0.75rem 2rem;
            border-radius: 30px;
            font-weight: 600;
            text-decoration: none;
            transition: all var(--transition-speed);
        }
        
        .btn-login:hover {
            background-color: #B20017;
            transform: translateY(-2px);
        }
        
        .btn-create {
            border: 2px solid var(--porsche-red);
            color: var(--porsche-red);
            background-color: transparent;
            padding: 0.75rem 2rem;
            border-radius: 30px;
            font-weight: 600;
            text-decoration: none;
            transition: all var(--transition-speed);
        }
        
        .btn-create:hover {
            background-color: var(--porsche-red);
            color: white;
            transform: translateY(-2px);
        }
        
        .btn-guest {
            color: #333;
            text-decoration: none;
            padding: 0.75rem 0;
            font-weight: 500;
            transition: all var(--transition-speed);
        }
        
        .btn-guest:hover {
            color: var(--porsche-red);
        }
        
        .feature-container {
            display: flex;
            margin-top: 2rem;
            gap: 1.5rem;
        }
        
        .feature-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .feature-icon {
            width: 45px;
            height: 45px;
            background-color: rgba(213, 0, 28, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--porsche-red);
        }
        
        .social-container {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .social-icon {
            width: 40px;
            height: 40px;
            background-color: #f4f4f4;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #333;
            transition: all var(--transition-speed);
        }
        
        .social-icon:hover {
            background-color: var(--porsche-red);
            color: white;
            transform: translateY(-3px);
        }
        
        .model-badge {
            position: absolute;
            top: 2rem;
            right: 2rem;
            background-color: var(--porsche-red);
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 30px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            z-index: 10;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .car-model-name {
            position: absolute;
            bottom: 2rem;
            right: 2rem;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 30px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            z-index: 10;
        }
        
        @media (max-width: 991px) {
            .welcome-container {
                flex-direction: column;
            }
            
            .welcome-left, .welcome-right {
                width: 100%;
            }
            
            .welcome-right {
                height: 50vh;
            }
            
            h1 {
                font-size: 2.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="welcome-container">
        <div class="welcome-left">
            <div class="logo">
                <img src="1720107822porsche-car-logo-png.png" alt="Porsche Logo">
            </div>
            
            <h1>Experience Excellence</h1>
            <p class="lead">Discover the perfect Porsche for your lifestyle. Buy, sell, or rent premium vehicles with our exclusive dealership services.</p>
            
            <div class="welcome-buttons">
                <a href="login.php" class="btn-login">Login</a>
                <a href="register.php" class="btn-create">Create Account</a>
                <!-- Updated guest access link to ensure consistent session handling -->
            </div>
            
            <div class="feature-container">
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-car"></i>
                    </div>
                    <div>Premium Selection</div>
                </div>
                
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div>Certified Pre-owned</div>
                </div>
                
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-tools"></i>
                    </div>
                    <div>Expert Service</div>
                </div>
            </div>
            
            <div class="social-container">
                <a href="#" class="social-icon">
                    <i class="fab fa-facebook-f"></i>
                </a>
                <a href="#" class="social-icon">
                    <i class="fab fa-instagram"></i>
                </a>
                <a href="#" class="social-icon">
                    <i class="fab fa-twitter"></i>
                </a>
                <a href="#" class="social-icon">
                    <i class="fab fa-youtube"></i>
                </a>
            </div>
        </div>
        
        <div class="welcome-right">
            <!-- GIF background - replace with your actual GIF path -->
            <img src="200.webp" alt="Porsche in motion" class="gif-background">
            
            <!-- Model badge at the top -->
            <div class="model-badge">
                NEW MODELS AVAILABLE
            </div>
            
            <!-- Car model name that changes -->
            <div class="car-model-name" id="car-model">
                EXPERIENCE THE DRIVE
            </div>
        </div>
    </div>

    <script>
        // Car model names that will rotate
        const carModels = [
            "Porsche 911 Turbo S",
            "Porsche Taycan",
            "Porsche Cayenne",
            "Porsche Panamera",
            "Porsche Macan",
            "Porsche 718 Cayman"
        ];
        
        let currentModelIndex = 0;
        const modelElement = document.getElementById('car-model');
        
        // Change car model name every 3 seconds
        setInterval(() => {
            currentModelIndex = (currentModelIndex + 1) % carModels.length;
            
            // Fade out effect
            modelElement.style.opacity = '0';
            
            setTimeout(() => {
                // Change the text
                modelElement.textContent = carModels[currentModelIndex];
                // Fade in effect
                modelElement.style.opacity = '1';
            }, 500);
        }, 3000);
        
        // Initialize fade transition
        modelElement.style.transition = 'opacity 0.5s ease';
    </script>
</body>
</html>