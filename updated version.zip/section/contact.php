<?php
session_start();

// Include database functionality
require_once 'contact_db_functions.php';

// Check if user is authenticated - no guest access allowed
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php?error=login_required");
    exit();
}

// Get inquiry type from parameters
$inquiry_type = isset($_GET['inquiry']) ? $_GET['inquiry'] : 'general';
$car_id = isset($_GET['car_id']) ? intval($_GET['car_id']) : 0;

// Initialize form variables
$form_submitted = false;
$form_success = false;
$form_message = '';
$form_errors = [];
$form_data = [];

// CSRF Protection
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Enhanced validation function
function validateContactFormEnhanced($data) {
    $errors = [];
    $sanitized_data = [];
    
    // Validate and sanitize name
    if (empty($data['name'])) {
        $errors['name'] = 'Name is required';
    } elseif (strlen(trim($data['name'])) < 2) {
        $errors['name'] = 'Name must be at least 2 characters long';
    } elseif (strlen(trim($data['name'])) > 100) {
        $errors['name'] = 'Name must not exceed 100 characters';
    } elseif (!preg_match('/^[a-zA-Z\s\'-]+$/', trim($data['name']))) {
        $errors['name'] = 'Name can only contain letters, spaces, hyphens, and apostrophes';
    } else {
        $sanitized_data['name'] = trim($data['name']);
    }
    
    // Validate and sanitize email
    if (empty($data['email'])) {
        $errors['email'] = 'Email is required';
    } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address';
    } elseif (strlen($data['email']) > 255) {
        $errors['email'] = 'Email address is too long';
    } else {
        $sanitized_data['email'] = strtolower(trim($data['email']));
    }
    
    // Validate and sanitize phone
    if (empty($data['phone'])) {
        $errors['phone'] = 'Phone number is required';
    } else {
        $phone = preg_replace('/[^0-9+\-\s\(\)]/', '', $data['phone']);
        if (strlen($phone) < 10) {
            $errors['phone'] = 'Phone number must be at least 10 digits';
        } elseif (strlen($phone) > 20) {
            $errors['phone'] = 'Phone number is too long';
        } else {
            $sanitized_data['phone'] = $phone;
        }
    }
    
    // Validate inquiry type
    $valid_inquiry_types = ['general', 'buy', 'sell', 'rent', 'service', 'parts', 'warranty', 'finance'];
    if (empty($data['inquiry_type']) || !in_array($data['inquiry_type'], $valid_inquiry_types)) {
        $errors['inquiry_type'] = 'Please select a valid inquiry type';
    } else {
        $sanitized_data['inquiry_type'] = $data['inquiry_type'];
    }
    
    // Validate message
    if (empty($data['message'])) {
        $errors['message'] = 'Message is required';
    } elseif (strlen(trim($data['message'])) < 10) {
        $errors['message'] = 'Message must be at least 10 characters long';
    } elseif (strlen(trim($data['message'])) > 2000) {
        $errors['message'] = 'Message must not exceed 2000 characters';
    } else {
        $sanitized_data['message'] = trim($data['message']);
    }
    
    // Validate car_id if provided
    if (!empty($data['car_id'])) {
        if (!is_numeric($data['car_id']) || intval($data['car_id']) <= 0) {
            $errors['car_id'] = 'Invalid car selection';
        } else {
            $sanitized_data['car_id'] = intval($data['car_id']);
        }
    }
    
    // Validate preferred contact method
    $valid_contact_methods = ['email', 'phone', 'both'];
    if (!empty($data['preferred_contact']) && !in_array($data['preferred_contact'], $valid_contact_methods)) {
        $errors['preferred_contact'] = 'Please select a valid contact preference';
    } else {
        $sanitized_data['preferred_contact'] = $data['preferred_contact'] ?? 'email';
    }
    
    // Validate preferred time if provided
    if (!empty($data['preferred_time'])) {
        $valid_times = ['morning', 'afternoon', 'evening', 'anytime'];
        if (!in_array($data['preferred_time'], $valid_times)) {
            $errors['preferred_time'] = 'Please select a valid time preference';
        } else {
            $sanitized_data['preferred_time'] = $data['preferred_time'];
        }
    }
    
    // Validate budget range if provided
    if (!empty($data['budget_range'])) {
        $valid_budgets = ['under_50k', '50k_100k', '100k_200k', '200k_500k', 'over_500k', 'flexible'];
        if (!in_array($data['budget_range'], $valid_budgets)) {
            $errors['budget_range'] = 'Please select a valid budget range';
        } else {
            $sanitized_data['budget_range'] = $data['budget_range'];
        }
    }
    
    return [
        'valid' => empty($errors),
        'errors' => $errors,
        'data' => $sanitized_data
    ];
}

// Rate limiting check
function checkRateLimit($user_id) {
    $current_time = time();
    $rate_limit_key = "contact_form_" . $user_id;
    
    if (!isset($_SESSION[$rate_limit_key])) {
        $_SESSION[$rate_limit_key] = [];
    }
    
    // Clean old entries (older than 1 hour)
    $_SESSION[$rate_limit_key] = array_filter($_SESSION[$rate_limit_key], function($timestamp) use ($current_time) {
        return ($current_time - $timestamp) < 3600;
    });
    
    // Check if user has exceeded limit (5 submissions per hour)
    if (count($_SESSION[$rate_limit_key]) >= 5) {
        return false;
    }
    
    // Add current timestamp
    $_SESSION[$rate_limit_key][] = $current_time;
    return true;
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF Token validation
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $form_message = 'Security token mismatch. Please try again.';
        $form_errors['csrf'] = 'Invalid security token';
    } else {
        // Rate limiting check
        if (!checkRateLimit($_SESSION['user_id'])) {
            $form_message = 'Too many submissions. Please wait before sending another message.';
            $form_errors['rate_limit'] = 'Rate limit exceeded';
        } else {
            // Validate form data
            $validation = validateContactFormEnhanced($_POST);
            
            if (!$validation['valid']) {
                $form_errors = $validation['errors'];
                $form_message = 'Please correct the errors below and try again.';
                $form_data = $_POST; // Preserve form data for repopulation
            } else {
                // Create submission array
                $submission = $validation['data'];
                $submission['user_id'] = $_SESSION['user_id'];
                $submission['ip_address'] = $_SERVER['REMOTE_ADDR'];
                $submission['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
                $submission['submitted_at'] = date('Y-m-d H:i:s');
                
                // Save to database
                try {
                    $result = saveContactSubmission($submission);
                    $form_submitted = true;
                    $form_success = $result['success'];
                    $form_message = $result['message'];
                    
                    if ($form_success) {
                        // Generate new CSRF token for security
                        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                        
                        // Clear form data on success
                        $form_data = [];
                        
                        // Send notification email (you would implement this function)
                        // sendNotificationEmail($submission);
                    }
                } catch (Exception $e) {
                    error_log("Contact form submission error: " . $e->getMessage());
                    $form_message = 'An error occurred while processing your request. Please try again later.';
                    $form_success = false;
                }
            }
        }
    }
}

// Get user information for form pre-population
$user_name = $_SESSION['username'] ?? '';
$user_email = $_SESSION['email'] ?? '';

?>

<?php include 'header.php'; ?>

<main>
    <section class="contact-hero py-5 bg-gradient">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <div class="hero-content">
                        <h1 class="display-4 fw-bold text-white mb-3">Get In Touch</h1>
                        <p class="lead text-white-50 mb-4">Experience exceptional service with Porsche. Our dedicated team is here to assist you with all your automotive needs.</p>
                        <div class="hero-stats d-flex flex-wrap gap-4">
                            <div class="stat-item">
                                <div class="h4 fw-bold text-white mb-0">24/7</div>
                                <small class="text-white-50">Customer Support</small>
                            </div>
                            <div class="stat-item">
                                <div class="h4 fw-bold text-white mb-0">&lt;2hr</div>
                                <small class="text-white-50">Response Time</small>
                            </div>
                            <div class="stat-item">
                                <div class="h4 fw-bold text-white mb-0">98%</div>
                                <small class="text-white-50">Satisfaction Rate</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 text-center">
                    <div class="hero-icon">
                        <i class="fas fa-comments fa-5x text-white opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="contact-form-section py-5">
        <div class="container">
            <?php if ($form_submitted && $form_success): ?>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="success-card card border-0 shadow-lg">
                        <div class="card-body text-center p-5">
                            <div class="success-animation mb-4">
                                <i class="fas fa-check-circle text-success" style="font-size: 4rem;"></i>
                            </div>
                            <h2 class="fw-bold mb-3 text-success">Message Sent Successfully!</h2>
                            <p class="lead mb-4"><?php echo htmlspecialchars($form_message); ?></p>
                            <p class="text-muted mb-4">Our team will review your inquiry and respond within 2 business hours. You'll receive a confirmation email shortly.</p>
                            <div class="d-flex justify-content-center gap-3">
                                <a href="home.php" class="btn btn-primary btn-lg">Return to Home</a>
                                <a href="contact.php" class="btn btn-outline-primary btn-lg">Send Another Message</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="row">
                <div class="col-lg-8 mb-5">
                    <div class="contact-form-card card border-0 shadow-lg">
                        <div class="card-header bg-dark text-white p-4">
                            <h3 class="fw-bold mb-0">
                                <i class="fas fa-envelope me-2"></i>
                                Send us a Message
                            </h3>
                            <p class="mb-0 opacity-75">Fill out the form below and we'll get back to you soon</p>
                        </div>
                        <div class="card-body p-4">
                            <?php if ($form_message && !$form_success): ?>
                            <div class="alert alert-danger d-flex align-items-center mb-4">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                <div class="flex-grow-1"><?php echo $form_message; ?></div>
                            </div>
                            <?php endif; ?>
                            
                            <form method="POST" action="contact.php<?php echo $inquiry_type ? '?inquiry=' . htmlspecialchars($inquiry_type) . ($car_id ? '&car_id=' . $car_id : '') : ''; ?>" class="needs-validation" novalidate>
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                
                                <!-- Personal Information Section -->
                                <div class="form-section mb-4">
                                    <h5 class="section-title fw-bold mb-3">
                                        <i class="fas fa-user me-2 text-primary"></i>
                                        Personal Information
                                    </h5>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="name" class="form-label fw-semibold">Full Name <span class="text-danger">*</span></label>
                                            <input type="text" 
                                                   class="form-control <?php echo isset($form_errors['name']) ? 'is-invalid' : ''; ?>" 
                                                   id="name" 
                                                   name="name" 
                                                   value="<?php echo htmlspecialchars($form_data['name'] ?? $user_name); ?>" 
                                                   required
                                                   maxlength="100"
                                                   pattern="[a-zA-Z\s\'-]+"
                                                   placeholder="Enter your full name">
                                            <?php if (isset($form_errors['name'])): ?>
                                            <div class="invalid-feedback"><?php echo $form_errors['name']; ?></div>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label for="email" class="form-label fw-semibold">Email Address <span class="text-danger">*</span></label>
                                            <input type="email" 
                                                   class="form-control <?php echo isset($form_errors['email']) ? 'is-invalid' : ''; ?>" 
                                                   id="email" 
                                                   name="email" 
                                                   value="<?php echo htmlspecialchars($form_data['email'] ?? $user_email); ?>" 
                                                   required
                                                   maxlength="255"
                                                   placeholder="your.email@example.com">
                                            <?php if (isset($form_errors['email'])): ?>
                                            <div class="invalid-feedback"><?php echo $form_errors['email']; ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="phone" class="form-label fw-semibold">Phone Number <span class="text-danger">*</span></label>
                                        <input type="tel" 
                                               class="form-control <?php echo isset($form_errors['phone']) ? 'is-invalid' : ''; ?>" 
                                               id="phone" 
                                               name="phone" 
                                               value="<?php echo htmlspecialchars($form_data['phone'] ?? ''); ?>" 
                                               required
                                               placeholder="+49 (0) 89 1234 5678">
                                        <?php if (isset($form_errors['phone'])): ?>
                                        <div class="invalid-feedback"><?php echo $form_errors['phone']; ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <!-- Inquiry Details Section -->
                                <div class="form-section mb-4">
                                    <h5 class="section-title fw-bold mb-3">
                                        <i class="fas fa-question-circle me-2 text-primary"></i>
                                        Inquiry Details
                                    </h5>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="inquiry_type" class="form-label fw-semibold">Inquiry Type <span class="text-danger">*</span></label>
                                            <select class="form-select <?php echo isset($form_errors['inquiry_type']) ? 'is-invalid' : ''; ?>" 
                                                    id="inquiry_type" 
                                                    name="inquiry_type" 
                                                    required>
                                                <option value="">Choose inquiry type...</option>
                                                <option value="general" <?php echo ($form_data['inquiry_type'] ?? $inquiry_type) == 'general' ? 'selected' : ''; ?>>General Inquiry</option>
                                                <option value="buy" <?php echo ($form_data['inquiry_type'] ?? $inquiry_type) == 'buy' ? 'selected' : ''; ?>>Purchase Inquiry</option>
                                                <option value="sell" <?php echo ($form_data['inquiry_type'] ?? $inquiry_type) == 'sell' ? 'selected' : ''; ?>>Selling Inquiry</option>
                                                <option value="rent" <?php echo ($form_data['inquiry_type'] ?? $inquiry_type) == 'rent' ? 'selected' : ''; ?>>Rental Inquiry</option>
                                                <option value="service" <?php echo ($form_data['inquiry_type'] ?? $inquiry_type) == 'service' ? 'selected' : ''; ?>>Service Inquiry</option>
                                                <option value="parts" <?php echo ($form_data['inquiry_type'] ?? $inquiry_type) == 'parts' ? 'selected' : ''; ?>>Parts Inquiry</option>
                                                <option value="warranty" <?php echo ($form_data['inquiry_type'] ?? $inquiry_type) == 'warranty' ? 'selected' : ''; ?>>Warranty Inquiry</option>
                                                <option value="finance" <?php echo ($form_data['inquiry_type'] ?? $inquiry_type) == 'finance' ? 'selected' : ''; ?>>Financing Options</option>
                                            </select>
                                            <?php if (isset($form_errors['inquiry_type'])): ?>
                                            <div class="invalid-feedback"><?php echo $form_errors['inquiry_type']; ?></div>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label for="budget_range" class="form-label fw-semibold">Budget Range (Optional)</label>
                                            <select class="form-select" id="budget_range" name="budget_range">
                                                <option value="">Select budget range...</option>
                                                <option value="under_50k" <?php echo ($form_data['budget_range'] ?? '') == 'under_50k' ? 'selected' : ''; ?>>Under €50,000</option>
                                                <option value="50k_100k" <?php echo ($form_data['budget_range'] ?? '') == '50k_100k' ? 'selected' : ''; ?>>€50,000 - €100,000</option>
                                                <option value="100k_200k" <?php echo ($form_data['budget_range'] ?? '') == '100k_200k' ? 'selected' : ''; ?>>€100,000 - €200,000</option>
                                                <option value="200k_500k" <?php echo ($form_data['budget_range'] ?? '') == '200k_500k' ? 'selected' : ''; ?>>€200,000 - €500,000</option>
                                                <option value="over_500k" <?php echo ($form_data['budget_range'] ?? '') == 'over_500k' ? 'selected' : ''; ?>>Over €500,000</option>
                                                <option value="flexible" <?php echo ($form_data['budget_range'] ?? '') == 'flexible' ? 'selected' : ''; ?>>Flexible</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <?php if ($car_id): ?>
                                    <input type="hidden" name="car_id" value="<?php echo $car_id; ?>">
                                    <div class="alert alert-info">
                                        <i class="fas fa-car me-2"></i>
                                        This inquiry is related to a specific vehicle (ID: <?php echo $car_id; ?>)
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Contact Preferences Section -->
                                <div class="form-section mb-4">
                                    <h5 class="section-title fw-bold mb-3">
                                        <i class="fas fa-cog me-2 text-primary"></i>
                                        Contact Preferences
                                    </h5>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="preferred_contact" class="form-label fw-semibold">Preferred Contact Method</label>
                                            <select class="form-select" id="preferred_contact" name="preferred_contact">
                                                <option value="email" <?php echo ($form_data['preferred_contact'] ?? 'email') == 'email' ? 'selected' : ''; ?>>Email</option>
                                                <option value="phone" <?php echo ($form_data['preferred_contact'] ?? '') == 'phone' ? 'selected' : ''; ?>>Phone</option>
                                                <option value="both" <?php echo ($form_data['preferred_contact'] ?? '') == 'both' ? 'selected' : ''; ?>>Both Email & Phone</option>
                                            </select>
                                        </div>
                                        
                                     
                                    </div>
                                </div>
                                
                                <!-- Message Section -->
                                <div class="form-section mb-4">
                                    <h5 class="section-title fw-bold mb-3">
                                        <i class="fas fa-comment me-2 text-primary"></i>
                                        Your Message
                                    </h5>
                                    <div class="mb-3">
                                        <label for="message" class="form-label fw-semibold">Detailed Message <span class="text-danger">*</span></label>
                                        <textarea class="form-control <?php echo isset($form_errors['message']) ? 'is-invalid' : ''; ?>" 
                                                  id="message" 
                                                  name="message" 
                                                  rows="6" 
                                                  required
                                                  minlength="10"
                                                  maxlength="2000"
                                                  placeholder="Please provide detailed information about your inquiry. The more specific you are, the better we can assist you."><?php echo htmlspecialchars($form_data['message'] ?? ''); ?></textarea>
                                        <div class="form-text">
                                            <span id="char-count">0</span>/2000 characters
                                        </div>
                                        <?php if (isset($form_errors['message'])): ?>
                                        <div class="invalid-feedback"><?php echo $form_errors['message']; ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <!-- Submit Section -->
                                <div class="form-section">
                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-primary btn-lg">
                                            <i class="fas fa-paper-plane me-2"></i>
                                            Send Message
                                        </button>
                                        <small class="text-muted text-center">
                                            By submitting this form, you agree to our privacy policy and terms of service.
                                        </small>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Contact Information Sidebar -->
                <div class="col-lg-4">
                    <div class="contact-info-sidebar">
                        <!-- Quick Contact Card -->
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-primary text-white">
                                <h5 class="fw-bold mb-0">
                                    <i class="fas fa-phone me-2"></i>
                                    Quick Contact
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="contact-item mb-3">
                                    <div class="d-flex align-items-center">
                                        <div class="contact-icon me-3">
                                            <i class="fas fa-phone-alt text-primary"></i>
                                        </div>
                                        <div>
                                            <strong>Sales Hotline</strong><br>
                                            <a href="tel:+4989123456789" class="text-decoration-none">+49 (0) 89 1234 5678</a>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="contact-item mb-3">
                                    <div class="d-flex align-items-center">
                                        <div class="contact-icon me-3">
                                            <i class="fas fa-tools text-primary"></i>
                                        </div>
                                        <div>
                                            <strong>Service Department</strong><br>
                                            <a href="tel:+4989123456790" class="text-decoration-none">+49 (0) 89 1234 5679</a>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="contact-item">
                                    <div class="d-flex align-items-center">
                                        <div class="contact-icon me-3">
                                            <i class="fas fa-envelope text-primary"></i>
                                        </div>
                                        <div>
                                            <strong>Email Support</strong><br>
                                            <a href="mailto:info@porschedealership.com" class="text-decoration-none">info@porschedealership.com</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Location Card -->
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-secondary text-white">
                                <h5 class="fw-bold mb-0">
                                    <i class="fas fa-map-marker-alt me-2"></i>
                                    Visit Our Showroom
                                </h5>
                            </div>
                            <div class="card-body">
                                <address class="mb-3">
                                    <strong>Porsche Center Munich</strong><br>
                                    123 Performance Drive<br>
                                    Stuttgart Business Park<br>
                                    Munich, Germany 80335
                                </address>
                                
                                <div class="opening-hours">
                                    <h6 class="fw-bold mb-2">Opening Hours</h6>
                                    <div class="hours-list">
                                        <div class="d-flex justify-content-between">
                                            <span>Monday - Friday:</span>
                                            <span>9:00 AM - 7:00 PM</span>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <span>Saturday:</span>
                                            <span>10:00 AM - 6:00 PM</span>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <span>Sunday:</span>
                                            <span class="text-danger">Closed</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mt-3">
                                    <a href="#" class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-directions me-1"></i>
                                        Get Directions
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Emergency Contact Card -->
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-warning text-dark">
                                <h5 class="fw-bold mb-0">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    Emergency Service
                                </h5>
								</div>
                            <div class="card-body">
                                <p class="mb-3">Need immediate roadside assistance or emergency service?</p>
                                
                                <div class="emergency-contact mb-3">
                                    <div class="d-flex align-items-center">
                                        <div class="contact-icon me-3">
                                            <i class="fas fa-phone text-danger"></i>
                                        </div>
                                        <div>
                                            <strong class="text-danger">24/7 Emergency</strong><br>
                                            <a href="tel:+49800123456" class="text-decoration-none fw-bold">+49 800 123 456</a>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="alert alert-warning alert-sm">
                                    <i class="fas fa-info-circle me-2"></i>
                                    <small>Available 24/7 for genuine emergencies and roadside assistance</small>
                                </div>
                            </div>
                        </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Additional Information Section -->
    <section class="additional-info py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center mb-5">
                    <h2 class="fw-bold mb-3">Why Choose Our Service?</h2>
                    <p class="lead text-muted">Experience the difference with our premium customer service</p>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="service-feature card border-0 shadow-sm h-100">
                        <div class="card-body text-center p-4">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-clock text-primary" style="font-size: 2.5rem;"></i>
                            </div>
                            <h5 class="fw-bold mb-3">Quick Response</h5>
                            <p class="text-muted">We respond to all inquiries within 2 business hours, ensuring you get the information you need quickly.</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="service-feature card border-0 shadow-sm h-100">
                        <div class="card-body text-center p-4">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-user-tie text-primary" style="font-size: 2.5rem;"></i>
                            </div>
                            <h5 class="fw-bold mb-3">Expert Advisors</h5>
                            <p class="text-muted">Our certified Porsche specialists have years of experience and can answer any question about our vehicles and services.</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="service-feature card border-0 shadow-sm h-100">
                        <div class="card-body text-center p-4">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-shield-alt text-primary" style="font-size: 2.5rem;"></i>
                            </div>
                            <h5 class="fw-bold mb-3">Secure & Private</h5>
                            <p class="text-muted">Your personal information is protected with industry-standard security measures and strict privacy policies.</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="service-feature card border-0 shadow-sm h-100">
                        <div class="card-body text-center p-4">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-handshake text-primary" style="font-size: 2.5rem;"></i>
                            </div>
                            <h5 class="fw-bold mb-3">Personalized Service</h5>
                            <p class="text-muted">Every interaction is tailored to your specific needs, ensuring you receive the most relevant and helpful assistance.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<script>
// Character counter for message textarea
document.addEventListener('DOMContentLoaded', function() {
    const messageTextarea = document.getElementById('message');
    const charCount = document.getElementById('char-count');
    
    if (messageTextarea && charCount) {
        function updateCharCount() {
            const count = messageTextarea.value.length;
            charCount.textContent = count;
            
            // Change color based on character count
            if (count > 1800) {
                charCount.className = 'text-danger fw-bold';
            } else if (count > 1500) {
                charCount.className = 'text-warning fw-bold';
            } else {
                charCount.className = 'text-muted';
            }
        }
        
        messageTextarea.addEventListener('input', updateCharCount);
        updateCharCount(); // Initial count
    }
    
    // Phone number formatting
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 0) {
                if (value.startsWith('49')) {
                    // German format
                    value = value.replace(/(\d{2})(\d{2,4})(\d{4,})/, '+$1 ($2) $3');
                } else if (value.length >= 10) {
                    // General international format
                    value = value.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
                }
            }
            e.target.value = value;
        });
    }
    
    // Form validation enhancement
    const form = document.querySelector('form');
    if (form) {
        form.addEventListener('submit', function(e) {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Sending...';
            }
        });
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert:not(.alert-info)');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s ease-in-out';
            alert.style.opacity = '0';
            setTimeout(() => {
                alert.remove();
            }, 500);
        }, 5000);
    });
});

// Inquiry type change handler
function handleInquiryTypeChange() {
    const inquiryType = document.getElementById('inquiry_type');
    const budgetRange = document.getElementById('budget_range');
    
    if (inquiryType && budgetRange) {
        inquiryType.addEventListener('change', function() {
            const showBudget = ['buy', 'sell', 'finance'].includes(this.value);
            const budgetRow = budgetRange.closest('.col-md-6');
            
            if (budgetRow) {
                budgetRow.style.display = showBudget ? 'block' : 'none';
                if (!showBudget) {
                    budgetRange.value = '';
                }
            }
        });
        
        // Trigger on page load
        inquiryType.dispatchEvent(new Event('change'));
    }
}

// Initialize inquiry type handler
document.addEventListener('DOMContentLoaded', handleInquiryTypeChange);
</script>

<style>
.bg-gradient {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
}

.contact-form-card {
    border-radius: 12px;
    overflow: hidden;
}

.form-section {
    border-bottom: 1px solid #e9ecef;
    padding-bottom: 1.5rem;
}

.form-section:last-child {
    border-bottom: none;
    padding-bottom: 0;
}

.section-title {
    color: #2c3e50;
    font-size: 1.1rem;
}

.service-feature {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    border-radius: 12px;
}

.service-feature:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.1) !important;
}

.contact-item {
    padding: 0.75rem 0;
    border-bottom: 1px solid #f8f9fa;
}

.contact-item:last-child {
    border-bottom: none;
}

.contact-icon {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(0,123,255,0.1);
    border-radius: 50%;
    flex-shrink: 0;
}

.hover-bg-light:hover {
    background-color: #f8f9fa !important;
    transition: background-color 0.2s ease;
}

.hero-stats .stat-item {
    text-align: center;
    min-width: 100px;
}

.success-animation {
    animation: bounceIn 0.8s ease-out;
}

@keyframes bounceIn {
    0% {
        transform: scale(0.3);
        opacity: 0;
    }
    50% {
        transform: scale(1.05);
    }
    70% {
        transform: scale(0.9);
    }
    100% {
        transform: scale(1);
        opacity: 1;
    }
}

.form-control:focus,
.form-select:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
}

.btn-primary {
    background: linear-gradient(45deg, #0d6efd, #0b5ed7);
    border: none;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    background: linear-gradient(45deg, #0b5ed7, #0a58ca);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(13, 110, 253, 0.3);
}

@media (max-width: 768px) {
    .hero-stats {
        justify-content: center;
    }
    
    .stat-item {
        margin-bottom: 1rem;
    }
    
    .service-feature {
        margin-bottom: 1rem;
    }
}

.invalid-feedback {
    display: block;
}

.form-control.is-invalid,
.form-select.is-invalid {
    border-color: #dc3545;
    padding-right: calc(1.5em + 0.75rem);
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23dc3545'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath d='m5.8 3.6.7.7.7-.7'/%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-position: right calc(0.375em + 0.1875rem) center;
    background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
}
</style>

<?php include 'footer.php'; ?>