<?php
// Database connection parameters - using your existing configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test1"; // Using your existing database

/**
 * Establishes database connection
 * @return mysqli|false Returns a mysqli connection object or false on failure
 */
function connectDB() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "test1";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        return false;
    }
    
    return $conn;
}
/**
 * Create contact_submissions table if it doesn't exist
 * @return bool Returns true if table exists or was created successfully, false on failure
 */
function ensureContactTable() {
    $conn = connectDB();
    
    if (!$conn) {
        return false;
    }
    
    // Check if table exists
    $result = $conn->query("SHOW TABLES LIKE 'contact_submissions'");
    if ($result->num_rows > 0) {
        $conn->close();
        return true; // Table already exists
    }
    
    // Create table
    $sql = "CREATE TABLE contact_submissions (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        inquiry_type VARCHAR(50) NOT NULL,
        car_id VARCHAR(50),
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql) === TRUE) {
        $conn->close();
        return true;
    } else {
        $conn->close();
        return false;
    }
}

/**
 * Save contact form submission to database
 * @param array $submission The form submission data
 * @return array Returns an array with success status and message
 */
function saveContactSubmission($submission) {
    $conn = connectDB();
    
    if (!$conn) {
        return [
            'success' => false,
            'message' => 'Database connection failed. Please try again later.'
        ];
    }
    
    // Ensure table exists
    if (!ensureContactTable()) {
        $conn->close();
        return [
            'success' => false,
            'message' => 'Error preparing database. Please try again later.'
        ];
    }
    
    // Prepare and sanitize data
    $name = $conn->real_escape_string($submission['name']);
    $email = $conn->real_escape_string($submission['email']);
    $phone = $conn->real_escape_string($submission['phone']);
    $inquiry_type = $conn->real_escape_string($submission['inquiry_type']);
    $message = $conn->real_escape_string($submission['message']);
    
    // Handle optional car_id
    $car_id = isset($submission['car_id']) ? $conn->real_escape_string($submission['car_id']) : NULL;
    
    // Insert submission
    $sql = "INSERT INTO contact_submissions (name, email, phone, inquiry_type, car_id, message) 
            VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $name, $email, $phone, $inquiry_type, $car_id, $message);
    
    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        return [
            'success' => true,
            'message' => 'Your message has been sent successfully!'
        ];
    } else {
        $error = $stmt->error;
        $stmt->close();
        $conn->close();
        return [
            'success' => false,
            'message' => 'Error saving your message: ' . $error
        ];
    }
}

/**
 * Validates contact form data
 * @param array $data The form data to validate
 * @return array Returns validation result with status and errors if any
 */
function validateContactForm($data) {
    $errors = [];
    
    // Required fields
    $required_fields = ['name', 'email', 'phone', 'message', 'inquiry_type'];
    foreach ($required_fields as $field) {
        if (empty($data[$field])) {
            $errors[] = ucfirst($field) . ' is required.';
        }
    }
    
    // Email validation
    if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    
    // Phone number basic validation (can be enhanced based on format requirements)
    if (!empty($data['phone'])) {
        // Remove common phone formatting characters
        $phone = preg_replace('/[^0-9+]/', '', $data['phone']);
        if (strlen($phone) < 6) {
            $errors[] = 'Please enter a valid phone number.';
        }
    }
    
    return [
        'valid' => empty($errors),
        'errors' => $errors
    ];
}
?>