<?php
// Database connection parameters
$servername = "localhost";
$username = "root";     // Your MySQL admin username
$password = "";         // Your MySQL admin password
$dbname = "test1";      // Your database name

/**
 * Establishes database connection
 * @return mysqli|false Returns a mysqli connection object or false on failure
 */
function connectDB() {
    global $servername, $username, $password, $dbname;
    
    try {
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        // Check connection
        if ($conn->connect_error) {
            error_log("Database connection failed: " . $conn->connect_error);
            return false;
        }
        
        return $conn;
    } catch (Exception $e) {
        error_log("Exception in connectDB: " . $e->getMessage());
        return false;
    }
}

/**
 * Setup necessary tables if they don't exist
 */
function setupDatabase() {
    try {
        global $servername, $username, $password, $dbname;
        
        // Create connection to MySQL server without selecting a database first
        $conn = new mysqli($servername, $username, $password);
        
        // Check connection
        if ($conn->connect_error) {
            error_log("Database connection failed: " . $conn->connect_error);
            return false;
        }
        
        // Create database if it doesn't exist
        $sql = "CREATE DATABASE IF NOT EXISTS `$dbname`";
        if ($conn->query($sql) !== TRUE) {
            error_log("Error creating database: " . $conn->error);
            return false;
        }
        
        // Select the database
        $conn->select_db($dbname);
        
        // Create tables
        setupTables($conn);
        
        $conn->close();
        return true;
    } catch (Exception $e) {
        error_log("Exception in setupDatabase: " . $e->getMessage());
        return false;
    }
}

/**
 * Create the necessary tables if they don't exist
 * @param mysqli $conn Database connection
 */
function setupTables($conn) {
    // SQL to create users table
    $sql = "CREATE TABLE IF NOT EXISTS `users` (
        `id` INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `username` VARCHAR(100) NOT NULL,
        `email` VARCHAR(100) NOT NULL UNIQUE,
        `password` VARCHAR(255) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql) !== TRUE) {
        error_log("Error creating users table: " . $conn->error);
        throw new Exception("Failed to create users table: " . $conn->error);
    }
    
    // SQL to create myguests1 table
    $sql = "CREATE TABLE IF NOT EXISTS `myguests1` (
        `id` INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `firstname` VARCHAR(30) NOT NULL,
        `lastname` VARCHAR(30) NOT NULL,
        `email` VARCHAR(50)
    )";
    
    if ($conn->query($sql) !== TRUE) {
        error_log("Error creating myguests1 table: " . $conn->error);
        throw new Exception("Failed to create myguests1 table: " . $conn->error);
    }
}

/**
 * Registers a new user and saves to both users and myguests1 tables
 * @param string $username The user's full name
 * @param string $email The user's email address
 * @param string $password The user's password
 * @return array Returns an array with success status and message
 */
function register($username, $email, $password) {
    try {
        $conn = connectDB();
        
        if (!$conn) {
            throw new Exception('Database connection failed. Please try again later.');
        }
        
        // Check if email already exists in users table
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        if (!$stmt) {
            throw new Exception('Prepare statement failed: ' . $conn->error);
        }
        
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $stmt->close();
            $conn->close();
            return [
                'success' => false,
                'message' => 'Email address is already registered. Please use a different email.'
            ];
        }
        $stmt->close();
        
        // Hash the password for users table
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Begin transaction
        $conn->begin_transaction();
        $success = true;
        
        // Insert into users table
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, NOW())");
        if (!$stmt) {
            throw new Exception('Prepare statement failed for users table: ' . $conn->error);
        }
        
        $stmt->bind_param("sss", $username, $email, $hashed_password);
        
        if (!$stmt->execute()) {
            $success = false;
            throw new Exception('Registration failed for users table: ' . $stmt->error);
        }
        $stmt->close();
        
        // Split the username into firstname and lastname for myguests1 table
        $name_parts = explode(' ', $username, 2);
        $firstname = $name_parts[0];
        $lastname = isset($name_parts[1]) ? $name_parts[1] : '';
        
        // Insert into myguests1 table
        $stmt = $conn->prepare("INSERT INTO myguests1 (firstname, lastname, email) VALUES (?, ?, ?)");
        if (!$stmt) {
            throw new Exception('Prepare statement failed for myguests1 table: ' . $conn->error);
        }
        
        $stmt->bind_param("sss", $firstname, $lastname, $email);
        
        if (!$stmt->execute()) {
            $success = false;
            throw new Exception('Registration failed for myguests1 table: ' . $stmt->error);
        }
        $stmt->close();
        
        // Commit transaction
        if ($success) {
            $conn->commit();
            $conn->close();
            return [
                'success' => true,
                'message' => 'Registration successful'
            ];
        } else {
            $conn->rollback();
            throw new Exception('Transaction failed');
        }
    } catch (Exception $e) {
        error_log("Error in register function: " . $e->getMessage());
        // Rollback transaction if active
        if (isset($conn) && $conn instanceof mysqli && $conn->ping()) {
            $conn->rollback();
        }
        // Close connections
        if (isset($stmt) && $stmt instanceof mysqli_stmt) $stmt->close();
        if (isset($conn) && $conn instanceof mysqli) $conn->close();
        return [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
}

/**
 * Authenticates a user
 * @param string $email The user's email address
 * @param string $password The user's password
 * @return array Returns an array with user data and success status
 */
function login($email, $password) {
    try {
        $conn = connectDB();
        
        if (!$conn) {
            throw new Exception('Database connection failed. Please try again later.');
        }
        
        // Get user by email
        $stmt = $conn->prepare("SELECT id, username, email, password FROM users WHERE email = ?");
        if (!$stmt) {
            throw new Exception('Prepare statement failed: ' . $conn->error);
        }
        
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            $stmt->close();
            $conn->close();
            return [
                'success' => false,
                'message' => 'Invalid email or password'
            ];
        }
        
        $user = $result->fetch_assoc();
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            $stmt->close();
            $conn->close();
            
            // Remove password from the returned user data
            unset($user['password']);
            
            return [
                'success' => true,
                'user' => $user,
                'message' => 'Login successful'
            ];
        } else {
            $stmt->close();
            $conn->close();
            return [
                'success' => false,
                'message' => 'Invalid email or password'
            ];
        }
    } catch (Exception $e) {
        error_log("Error in login function: " . $e->getMessage());
        // Close connections
        if (isset($stmt) && $stmt instanceof mysqli_stmt) $stmt->close();
        if (isset($conn) && $conn instanceof mysqli) $conn->close();
        return [
            'success' => false,
            'message' => 'Login error: ' . $e->getMessage()
        ];
    }
}
?>