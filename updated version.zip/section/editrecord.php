<?php
// edit_record.php - Add/Edit/Delete Record
session_start();
include 'config.php';
include 'functions.php';

// Check if logged in
if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php");
    exit;
}

// Get parameters
$table = isset($_GET['table']) ? $_GET['table'] : '';
$action = isset($_GET['action']) ? $_GET['action'] : '';
$id = isset($_GET['id']) ? $_GET['id'] : '';
$key = isset($_GET['key']) ? $_GET['key'] : '';

// Verify table exists
$tables = getTables();
if(!in_array($table, $tables)) {
    header("Location: admin_panel.php");
    exit;
}

// Get table columns
$columns = getTableColumns($table);

// Process DELETE action
if($action == 'delete' && !empty($id) && !empty($key)) {
    $conn = connectDB();
    $stmt = $conn->prepare("DELETE FROM $table WHERE $key = ?");
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    
    header("Location: admin_panel.php?table=$table");
    exit;
}

// Process form submission (ADD or EDIT)
$message = '';
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = connectDB();
    
    // Prepare data for insertion/update
    $data = array();
    $types = '';
    
    foreach($columns as $column) {
        $field = $column['Field'];
        
        // Skip auto-increment field on insert
        if($action == 'add' && $column['Extra'] == 'auto_increment') {
            continue;
        }
        
        // Handle field based on its type
        if(isset($_POST[$field])) {
            $data[$field] = $_POST[$field];
            
            // Determine type for binding parameters
            if(strpos($column['Type'], 'int') !== false) {
                $types .= 'i'; // integer
            } elseif(strpos($column['Type'], 'float') !== false || 
                     strpos($column['Type'], 'double') !== false || 
                     strpos($column['Type'], 'decimal') !== false) {
                $types .= 'd'; // double
            } else {
                $types .= 's'; // string
            }
        }
    }
    
    // Execute query based on action
    if($action == 'add') {
        // Build INSERT query
        $fields = implode(', ', array_keys($data));
        $placeholders = str_repeat('?, ', count($data) - 1) . '?';
        
        $sql = "INSERT INTO $table ($fields) VALUES ($placeholders)";
        $stmt = $conn->prepare($sql);
        
        // Bind parameters
        $params = array_values($data);
        $bind_params = array($types);
        foreach($params as $key => $value) {
            $bind_params[] = &$params[$key];
        }
        call_user_func_array(array($stmt, 'bind_param'), $bind_params);
        
    } else { // EDIT
        // Build UPDATE query
        $set_clause = '';
        foreach($data as $field => $value) {
            if($field != $key) { // Skip the primary key in SET clause
                $set_clause .= "$field = ?, ";
            }
        }
        $set_clause = rtrim($set_clause, ', ');
        
        $sql = "UPDATE $table SET $set_clause WHERE $key = ?";
        $stmt = $conn->prepare($sql);
        
        // Bind parameters (all fields + primary key at the end)
        $params = array();
        foreach($data as $field => $value) {
            if($field != $key) {
                $params[] = $value;
            }
        }
        $params[] = $id; // Add primary key value at the end
        $types .= 's'; // Add type for primary key
        
        $bind_params = array($types);
        foreach($params as $key => $value) {
            $bind_params[] = &$params[$key];
        }
        call_user_func_array(array($stmt, 'bind_param'), $bind_params);
    }
    
    // Execute and check result
    if($stmt->execute()) {
        header("Location: admin_panel.php?table=$table");
        exit;
    } else {
        $message = "Error: " . $stmt->error;
    }
    
    $stmt->close();
    $conn->close();
}

// Get current record data for EDIT
$record = array();
if($action == 'edit' && !empty($id) && !empty($key)) {
    $conn = connectDB();
    $stmt = $conn->prepare("SELECT * FROM $table WHERE $key = ? LIMIT 1");
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows > 0) {
        $record = $result->fetch_assoc();
    } else {
        header("Location: admin_panel.php?table=$table");
        exit;
    }
    
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucfirst($action); ?> Record - Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            width: 80%;
            max-width: 800px;
            margin: 30px auto;
            background-color: white;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            margin-top: 0;
        }
        form {
            margin-top: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], input[type="number"], input[type="email"], 
        input[type="password"], textarea, select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 3px;
            box-sizing: border-box;
        }
        textarea {
            height: 100px;
        }
        .buttons {
            margin-top: 20px;
        }
        .btn {
            padding: 10px 15px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
        }
        .save-btn {
            background-color: #4CAF50;
            color: white;
        }
        .cancel-btn {
            background-color: #f44336;
            color: white;
        }
        .back-btn {
            background-color: #2196F3;
            color: white;
            text-decoration: none;
            display: inline-block;
        }
        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 3px;
        }
        .error {
            background-color: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1><?php echo ucfirst($action); ?> Record</h1>
        <h3>Table: <?php echo $table; ?></h3>
        
        <?php if(!empty($message)): ?>
            <div class="message error"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <form method="post" action="">
            <?php foreach($columns as $column): ?>
                <div class="form-group">
                    <label for="<?php echo $column['Field']; ?>"><?php echo $column['Field']; ?></label>
                    
                    <?php
                    // Skip auto-increment field on add
                    $readonly = '';
                    $value = '';
                    
                    // Set value for edit mode
                    if($action == 'edit') {
                        $value = isset($record[$column['Field']]) ? $record[$column['Field']] : '';
                        
                        // Make primary key read-only
                        if($column['Field'] == $key) {
                            $readonly = 'readonly';
                        }
                    }
                    
                    // Skip auto-increment field on add
                    if($action == 'add' && $column['Extra'] == 'auto_increment') {
                        echo "<input type='text' id='{$column['Field']}' name='{$column['Field']}' value='Auto Generated' readonly>";
                        continue;
                    }
                    
                    // Determine input type based on column type
                    if(strpos($column['Type'], 'text') !== false) {
                        echo "<textarea id='{$column['Field']}' name='{$column['Field']}' $readonly>$value</textarea>";
                    } elseif(strpos($column['Type'], 'int') !== false || 
                              strpos($column['Type'], 'float') !== false || 
                              strpos($column['Type'], 'double') !== false || 
                              strpos($column['Type'], 'decimal') !== false) {
                        echo "<input type='number' id='{$column['Field']}' name='{$column['Field']}' value='$value' $readonly>";
                    } elseif($column['Field'] == 'email') {
                        echo "<input type='email' id='{$column['Field']}' name='{$column['Field']}' value='$value' $readonly>";
                    } elseif($column['Field'] == 'password' && $action == 'add') {
                        echo "<input type='password' id='{$column['Field']}' name='{$column['Field']}' $readonly>";
                    } elseif(strpos($column['Type'], 'enum') !== false) {
                        // Extract enum values
                        preg_match("/enum\(\'(.*)\'\)/", $column['Type'], $matches);
                        $enum_values = explode("','", $matches[1]);
                        
                        echo "<select id='{$column['Field']}' name='{$column['Field']}' $readonly>";
                        foreach($enum_values as $enum_value) {
                            $selected = ($value == $enum_value) ? 'selected' : '';
                            echo "<option value='$enum_value' $selected>$enum_value</option>";
                        }
                        echo "</select>";
                    } else {
                        echo "<input type='text' id='{$column['Field']}' name='{$column['Field']}' value='$value' $readonly>";
                    }
                    ?>
                </div>
            <?php endforeach; ?>
            
            <div class="buttons">
                <button type="submit" class="btn save-btn">Save</button>
                <a href="admin_panel.php?table=<?php echo $table; ?>" class="btn back-btn">Back to Table</a>
            </div>
        </form>
    </div>
</body>
</html>