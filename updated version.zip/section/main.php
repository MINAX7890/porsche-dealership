/**
 * Porsche Dealership - Main JavaScript
 * 
 * This file contains the client-side functionality for the Porsche dealership website.
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize active navigation
    highlightActiveNavLink();
    
    // Initialize date pickers with min dates
    initDatePickers();
    
    // Add event listeners for rent form if it exists
    initRentalForm();
});

/**
 * Highlights the active navigation link based on current page
 */
function highlightActiveNavLink() {
    // Get current page path
    const currentPath = window.location.pathname;
    const filename = currentPath.substring(currentPath.lastIndexOf('/') + 1);
    
    // Get all nav links
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    
    // Loop through nav links and check if href matches current page
    navLinks.forEach(link => {
        const linkHref = link.getAttribute('href');
        
        // If linkHref is home.php and filename is empty, it's the home page
        if (linkHref === 'home.php' && (filename === '' || filename === 'home.php')) {
            link.classList.add('active');
            link.style.color = 'var(--primary-color)';
        } 
        // For other pages, check if the filename matches
        else if (linkHref === filename) {
            link.classList.add('active');
            link.style.color = 'var(--primary-color)';
        }
    });
}

/**
 * Initializes date pickers with min dates for rental forms
 */
function initDatePickers() {
    // Get pickup and return date inputs if they exist
    const pickupDateInput = document.getElementById('pickup_date');
    const returnDateInput = document.getElementById('return_date');
    
    if (pickupDateInput && returnDateInput) {
        // Set min date for pickup date (today)
        const today = new Date().toISOString().split('T')[0];
        pickupDateInput.min = today;
        
        // Set min date for return date (tomorrow)
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        returnDateInput.min = tomorrow.toISOString().split('T')[0];
        
        // Add event listener to update return date min when pickup date changes
        pickupDateInput.addEventListener('change', function() {
            if (pickupDateInput.value) {
                const pickupDate = new Date(pickupDateInput.value);
                const minReturnDate = new Date(pickupDate);
                minReturnDate.setDate(minReturnDate.getDate() + 1);
                returnDateInput.min = minReturnDate.toISOString().split('T')[0];
                
                // If current return date is before new min date, update it
                if (returnDateInput.value && new Date(returnDateInput.value) <= pickupDate) {
                    returnDateInput.value = minReturnDate.toISOString().split('T')[0];
                }
            }
        });
    }
}

/**
 * Initializes the rental form if it exists
 */
function initRentalForm() {
    const rentalForm = document.querySelector('form[action^="rent.php"]');
    
    if (rentalForm) {
        rentalForm.addEventListener('submit', function(event) {
            const pickupDate = document.getElementById('pickup_date');
            const returnDate = document.getElementById('return_date');
            const termsAgreement = document.getElementById('terms_agreement');
            
            let isValid = true;
            
            // Validate pickup date
            if (!pickupDate.value) {
                isValid = false;
                showFieldError(pickupDate, 'Please select a pickup date');
            } else {
                hideFieldError(pickupDate);
            }
            
            // Validate return date
            if (!returnDate.value) {
                isValid = false;
                showFieldError(returnDate, 'Please select a return date');
            } else if (new Date(returnDate.value) <= new Date(pickupDate.value)) {
                isValid = false;
                showFieldError(returnDate, 'Return date must be after pickup date');
            } else {
                hideFieldError(returnDate);
            }
            
            // Validate terms agreement
            if (!termsAgreement.checked) {
                isValid = false;
                showFieldError(termsAgreement, 'You must agree to the rental terms');
            } else {
                hideFieldError(termsAgreement);
            }
            
            // Prevent form submission if validation fails
            if (!isValid) {
                event.preventDefault();
            }
        });
    }
}

/**
 * Shows an error message for a form field
 */
function showFieldError(field, message) {
    // Remove any existing error message
    hideFieldError(field);
    
    // Create error message element
    const errorElement = document.createElement('div');
    errorElement.className = 'invalid-feedback';
    errorElement.textContent = message;
    errorElement.style.display = 'block';
    
    // Add error class to field
    field.classList.add('is-invalid');
    
    // Insert error message after the field
    field.parentNode.appendChild(errorElement);
}

/**
 * Hides the error message for a form field
 */
function hideFieldError(field) {
    field.classList.remove('is-invalid');
    
    // Find and remove any existing error message
    const errorElement = field.parentNode.querySelector('.invalid-feedback');
    if (errorElement) {
        errorElement.remove();
    }
}

/**
 * Calculate rental duration and total price
 * This function would be used on the rental page
 */
function calculateRentalPrice() {
    const pickupDateInput = document.getElementById('pickup_date');
    const returnDateInput = document.getElementById('return_date');
    const dailyRateElement = document.querySelector('.rental-rate .fw-bold');
    const totalPriceElement = document.getElementById('total_price');
    
    if (pickupDateInput && returnDateInput && dailyRateElement && totalPriceElement) {
        if (pickupDateInput.value && returnDateInput.value) {
            const pickupDate = new Date(pickupDateInput.value);
            const returnDate = new Date(returnDateInput.value);
            
            // Calculate duration in days
            const durationMs = returnDate - pickupDate;
            const durationDays = Math.ceil(durationMs / (1000 * 60 * 60 * 24));
            
            if (durationDays > 0) {
                // Extract daily rate from the element text (€500 per day -> 500)
                const dailyRateText = dailyRateElement.textContent;
                const dailyRate = parseInt(dailyRateText.replace(/[^0-9]/g, ''));
                
                // Calculate total price
                const totalPrice = dailyRate * durationDays;
                
                // Update the total price element
                totalPriceElement.textContent = `€${totalPrice.toLocaleString()}`;
                
                // Show the total price container
                document.getElementById('total_price_container').style.display = 'block';
            }
        }
    }
}
